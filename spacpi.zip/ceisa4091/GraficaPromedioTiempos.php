<?php
include('includes/session.php');
include('Classes/ClassGraficaPromedioTiempos.php');
include('includes/phplot/phplot.php');
$Title=_('Grafica de promedio de tiempos de envío');
include('includes/header.php');
    
    echo '<div class="page_help_text">' .
    			_('Grafica los tiempos en promedio de los articulos desde la facturacion hasta el envio') . '<br /></div>' ;
    $FechaHoy=date("Y/m/d");
    $FechaSemanaPasada = date("Y/m/d",strtotime($FechaHoy."- 7 days"));
    echo '<form method="post" action="' . htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
    echo "<table>";
    if(isset($_POST['FechaInicio'])!='' && isset($_POST['FechaFin'])!='')
    {
    echo '<th><label>Fecha inicio</label><input type="text" class="date" name="FechaInicio" size =10 value = "'.$_POST['FechaInicio'].'"  required /></th><th><label>Fecha fin</label><input type="text" size="10" class="date" name="FechaFin" value="'.$_POST['FechaFin'].'" required /></th>';
    }else{
        echo '<th><label>Fecha inicio</label><input type="text" class="date" name="FechaInicio" size =10 value='.$FechaSemanaPasada.' required /></th><th><label>Fecha fin</label><input type="text" size="10" class="date" value='.$FechaHoy.' name="FechaFin"  required /></th>';
    } 
        switch($_POST['radioSelect'])
        {
            case 1:
                echo '<th><input type="radio" name="radioSelect" value=1 checked required> Agrupar por día</th>';
                echo '<th><input type="radio" name="radioSelect" value=2 required> Agrupar por mes</th>';

            break;
            case 2:

                echo '<th><input type="radio" name="radioSelect" value=1 required> Agrupar por día</th>';
                echo '<th><input type="radio" name="radioSelect" value=2 checked required> Agrupar por mes</th>';
                
            break;
                default:
                echo '<th><input type="radio" name="radioSelect" value=1 required> Agrupar por día</th>';
                echo '<th><input type="radio" name="radioSelect" value=2 required> Agrupar por mes</th>';
            break;
        }
   
        echo '
			<td>' . _('Tipo de grafica') . '</td>
      <td><select name="GraphType">';
      if($_POST['GraphType']=="bars")
      {
        echo '<option value="bars" selected>' . _('Bar Graph') . '</option>';
      }else {
        echo '<option value="bars">' . _('Bar Graph') . '</option>';
      }if($_POST['GraphType']=="stackedbars"){
      echo '<option value="stackedbars" selected>' . _('Stacked Bar Graph') . '</option>';
      }else {
        echo '<option value="stackedbars">' . _('Stacked Bar Graph') . '</option>';
      }if($_POST['GraphType']=="lines"){
        echo '<option value="lines" selected>' . _('Line Graph') . '</option>';
      }else {
      echo '  <option value="lines">' . _('Line Graph') . '</option>';
      }if($_POST['GraphType']=="linepoints"){
        echo '<option value="linepoints" selected>' . _('Line Point Graph') . '</option>';
      }else{
        echo '<option value="linepoints">' . _('Line Point Graph') . '</option>';
      }if($_POST['GraphType']=="area"){
        echo '<option value="area" selected>' . _('Area Graph') . '</option>';
      }else
      {
        echo '<option value="area">' . _('Area Graph') . '</option>';
      }if($_POST['GraphType']=="points"){
        echo '<option value="points" selected>' . _('Points Graph') . '</option>';
      }else {
        echo '<option value="points">' . _('Points Graph') . '</option>';
      }
      if($_POST['GraphType']=="pie"){
        echo '<option value="pie" selected>' . _('Pie Graph') . '</option>';
       }else{
        echo '<option value="pie">' . _('Pie Graph') . '</option>';
       } if($_POST['GraphType']=="thinbarline"){
        echo '<option value="thinbarline" selected>' . _('Thin Bar Line Graph') . '</option>';
      }else {
        echo '<option value="thinbarline">' . _('Thin Bar Line Graph') . '</option>';
      }if($_POST['GraphType']=="squared"){
         echo '<option value="squared" selected>' . _('Squared Graph') . '</option>';
        }else{
         echo '<option value="squared">' . _('Squared Graph') . '</option>';

        } if($_POST['GraphType']=="stackedarea"){
        echo '<option value="stackedarea" selected>' . _('Stacked Area Graph') . '</option>';
      }else {
        echo '<option value="stackedarea" >' . _('Stacked Area Graph') . '</option>';

      }
				echo '</select></td>';
    echo '<th><input type=submit value="Ver Grafica" name = Submit1><th>
    </form>';
    echo "</table>";
    if($_POST['Submit1'])
    {
        $promedioTiempo = new PromedioTiempos();
        $promedioTiempo->Graficar($_POST['FechaInicio'],$_POST['FechaFin'],$_POST['radioSelect'],$_POST['GraphType']);
    }
     





include('includes/footer.php');
?>