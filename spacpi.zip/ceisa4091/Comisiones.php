<?php
/* $Id: Comisiones.php 6892 2014-09-16 07:27:40Z vcv $*/
/*	Script to print debtor's deposits per salesman*/
/*	Output column sizes:
		* stockmaster.stockid, varchar(20), len = 20chr
		* stockmaster.description, varchar(50), len = 50chr
		* prices.startdate, date, len = 10chr
		* prices.enddate, date/'No End Date', len = 12chr
		* custbranch.brname, varchar(40), len = 40chr
		* Gross Profit, calculated, len = 8chr
		* prices.price, decimal(20,4), len = 20chr + 4spaces */

/*	Please note that addTextWrap() YPos is a font-size-height further down than
	addText() and other functions. Use addText() instead of addTextWrap() to
	print left aligned elements.*/
	
	
	
	
	

include('includes/session.php');




  

if (isset($_POST['CSV']) or isset($_POST['Table'])) {
	

$criterio="WHERE DIF <5 and (comdate='0000-00-00' OR comdate BETWEEN ";

if ($_POST['Period'] == "All"){

	$desde="0000-00-00";
$hasta="9999-12-12";
$criterio.="'".$desde."' AND '".$hasta."' )";
	}
	if ($_POST['Period'] != "All"){
	$desde=$_POST['Period'];
	$desde.='-01';
	$segundos=strtotime($desde);
	$hasta=Date('Y-m-d',Mktime(0,0,0,Date('m',$segundos)+1,Date('d',$segundos)-1,Date('Y',$segundos)));
		$criterio.="'".$desde."' AND '".$hasta."' )";
	}
	if ($_POST['Salesman'] != "All"){
		$criterio.= " AND facturas.salesperson = '" . 	$_POST['Salesman'] ."' ";
	}

	

	/*Ahora obtenga los pagos de los clientes*/
$SQL = "SELECT facturas.comdate,facturas.debtorno, facturas.transno, facturas.ultasign, facturas.branchcode, facturas.salesperson, facturas.transid_allocto, reales.depositos, (reales.depositos/(1+facturas.factorIVA)) as comisionable
FROM (

SELECT debtortrans.debtorno, debtortrans.transno, debtortrans.ovamount, (
debtortrans.ovgst / debtortrans.ovamount
) AS factorIVA, (
debtortrans.ovamount + debtortrans.ovgst
) AS facturado, debtortrans.alloc, ultasign.transid_allocto, TRUNCATE( (
debtortrans.ovamount + debtortrans.ovgst - debtortrans.alloc
), 0 ) AS DIF, debtortrans.type, ultasign.ultasign, debtortrans.salesperson, debtortrans.branchcode, debtortrans.comdate
FROM debtortrans
INNER JOIN (

SELECT custallocns.id, MAX( custallocns.datealloc ) AS ultasign, transid_allocto
FROM custallocns
GROUP BY transid_allocto
) AS ultasign ON ultasign.transid_allocto = debtortrans.id
WHERE debtortrans.type =10
AND ultasign.ultasign
BETWEEN  '".$desde."'
AND  '".$hasta."'
) AS facturas INNER JOIN (SELECT custallocns.transid_allocto, custallocns.transid_allocfrom, custallocns.amt, debtortrans.type, debtortrans.trandate, - debtortrans.ovamount, debtortrans.ovdiscount, (
debtortrans.ovdiscount / - debtortrans.ovamount
) AS factordesc, SUM( (
custallocns.amt / ( 1 + ( debtortrans.ovdiscount / debtortrans.ovamount ) ) )
) AS depositos
FROM custallocns
INNER JOIN debtortrans ON debtortrans.id = custallocns.transid_allocfrom
WHERE debtortrans.type =12
AND debtortrans.trandate >=  '2019-03-01'
GROUP BY custallocns.transid_allocto) AS reales ON reales.transid_allocto=facturas.transid_allocto ".$criterio."  ORDER BY facturas.salesperson, facturas.ultasign DESC";
	}


	if (DB_error_no($db) !=0) {
		$Title = _('Comisiones') . ' - ' . _('Problem Report....');
		include('includes/header.php');
		prnMsg( _('The deposits could not be retrieved by the SQL because'). ' - ' . DB_error_msg($db), 'error');
		echo '<br /><a href="' .$RootPath .'/index.php">' .   _('Back to the menu'). '</a>';
		if ($debug==1) {
			prnMsg(_('For debugging purposes the SQL used was:') . $SQL,'error');
		}
		include('includes/footer.php');
		exit;
	}



/*Crear Excel*/
if (isset($_POST['CSV'])) {
	$CSVListing = _('Agente') .','. _('Número') .','. _('Fecha') .','. _('NumSpacpi') .','. _('Depositos') .','. _('Efectivo') .','. _('CodSuc') .','. _('NomSucursal') .','. _('Poblacion') . "\n";
$Agente="-";
$Depositos=0;
$Efectivo=0;
$Dtot=0;
$Etot=0;
While ($IngresosN = DB_fetch_row($PagosResult,$db)) {
	if ($Agente<>$IngresosN[0]) {
	if ($Agente<>"-") {
$Suma=$Depositos+$Efectivo;
$Dtot=$Dtot+$Depositos;
$Etot=$Etot+$Efectivo;
$CSVListing .= 'TOTAL' .','. $Agente .','. '' .','. '' .','. $Depositos .','. $Efectivo . ','.'SUMA' . ','.$Suma.','. "\n\n";
	}
$Depositos=0;
$Efectivo=0;
	}
$Ingresos=$IngresosN;

$CSVListing .= implode(',', $Ingresos ) . "\n";
$Agente=$Ingresos[0];
$Depositos=$Depositos+$Ingresos[4];
$Efectivo=$Efectivo+$Ingresos[5];
}
$Suma=$Depositos+$Efectivo;
$CSVListing .= 'TOTAL' .','. $Agente .','. '' .','. '' .','. $Depositos .','. $Efectivo . ','.'SUMA' . ','.$Suma.','. "\n\n";
$Dtot=$Dtot+$Depositos;
$Etot=$Etot+$Efectivo;
$Suma=$Dtot+$Etot;
$CSVListing .= 'TOTAL' .','. 'GLOBAL' .',' .','.','. $Dtot .','. $Etot .','.'SUMA' .','. $Suma .',' .','. "\n\n";

	header('Content-Encoding: UTF-8');
    header('Content-type: text/csv; charset=UTF-8');
    header("Content-disposition: attachment; filename=Pagos de Clientes por Agente Sin IVA" .'.csv');
    header("Pragma: public");
    header("Expires: 0");
    echo "\xEF\xBB\xBF"; // UTF-8 BOM
	echo $CSVListing;
	exit;

}


else { /*The option to print PDF nor to create the CSV was not hit */
	$Title = _('Comisiones');
	$ViewTopic = 'Comisiones';// Filename in ManualContents.php's TOC.
	$BookMark = 'PDFComisiones';// Anchor's id in the manual's html document.
	include('includes/header.php');
	echo '<p class="page_title_text"><img alt="" src="' . $RootPath . '/css/' . $Theme . '/images/customer.png" title="' .
		_('Comisiones') . '" />' . ' ' . _('Reporte de comisiones') . '</p>';
	if (!isset($_POST['FromCriteria']) or !isset($_POST['ToCriteria'])) {
		/*if $FromCriteria is not set then show a form to allow input */
		echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8') . '" method="post">';
        echo '<div>';
		echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
        echo '<table class="selection">';


				echo '<tr><td>' . _('Agente').':</td>
                  <td><select name="Salesman">';
		$sql = "SELECT salesmancode,salesmanname FROM salesman ORDER BY salesmanname";
		$SalemanResult=DB_query($sql,$db);
		if(!isset($_POST['Salesman']) or $_POST['Salesman']=='All' ){
		echo '<option selected="selected" value="All">' . _('All')  . '</option>';
		}
		else{
				echo '<option value="All">' . _('All')  . '</option>';
		}
		while ($myrow=DB_fetch_array($SalemanResult)) {
				if($_POST['Salesman']==$myrow['salesmancode'] ){
		echo '<option value="' . $myrow['salesmancode'] . '" selected="selected">' . $myrow['salesmanname']. '</option>';
		}
		else{
				echo '<option value="' . $myrow['salesmancode'] . '">' . $myrow['salesmanname']. '</option>';
		}
		}
		echo '</select></td></tr>';
		echo '<tr><td>' . _('Mes').':</td>
                  <td><select name="Period">';
		$sql = "SELECT periodno,DATE_FORMAT(lastdate_in_period,'%Y-%m') AS Mes FROM periods ORDER BY periodno DESC";
		$PeriodResult=DB_query($sql,$db);
				if(!isset($_POST['Period']) or $_POST['Period']=='All' ){
		echo '<option selected="selected" value="All">' . _('All')  . '</option>';
		}
		else{
				echo '<option value="All">' . _('All')  . '</option>';
		}
		while ($myrow=DB_fetch_array($PeriodResult)) {
						if($_POST['Period']==$myrow['Mes'] ){
		echo '<option value="' . $myrow['Mes'] . '" selected="selected">' . $myrow['Mes']. '</option>';
	}
	else{
		echo '<option value="' . $myrow['Mes'] . '">' . $myrow['Mes']. '</option>';
	}
		}
		echo '</select></td></tr>';
		echo '<tr>
				
			</tr>

			</table>
			<br />
			<div class="centre">

				<input type="submit" name="CSV" value="' . _('Output to CSV') . '" /><input type="submit" name="Table" value="' . _('Output to Table') . '" />
			</div>
			</div>
		</form>';
//CREAR TABLE
if (isset($_POST['Table'])) {

	$PagosResult = DB_query($SQL,$db);


echo '<table class="selection">';
			echo '<tr>
					<th>' . _('Agente') . '</th>
					<th>' . _('Factura') . '</th>
					<th>' . _('Fecha Asignación') . '</th>
					<th>' . _('Importe cobrado sin IVA') . '</th>
					<th>' . _('CodSuc') . '</th>
					<th>' . _('Nomsuc') . '</th>
					<th>' . _('Población') . '</th>
					<th>' . _('Zona de ventas') . '</th>

	
				</tr>';
$agente='-';
$importe=0;
$total=0;
While ($Comisiones = DB_fetch_row($PagosResult,$db)) {

if($agente!='-' and $agente!=$Comisiones[5]){
$total+=$importe;
echo '<tr class="striped_row"><td colspan="3">TOTAL=</td><td>'.locale_number_format($importe,2).'</td><td colspan="4"></td></tr>';
$importe=0;		
}
$agente=$Comisiones[5];
$importe+=$Comisiones[8];
$sql="SELECT custbranch.braddress3,custbranch.brname,areas.areadescription FROM custbranch INNER JOIN areas ON areas.areacode=custbranch.area WHERE custbranch.branchcode LIKE '".$Comisiones[4]."'";
$zonas = DB_query($sql,$db);
$myrowzon=DB_fetch_row($zonas);

if($Comisiones[0]=='0000-00-00'){
$sqlo="Update debtortrans SET comdate='".$Comisiones[3]."' WHERE transno='".$Comisiones[2]."' and type='10'";
$ponmes = DB_query($sqlo,$db);
$Comisiones[0]=$Comisiones[3];
}

	echo '<tr class="striped_row">
					<td>' . $Comisiones[5] . '</td>
					<td>' . $Comisiones[2] . '</td>
					<td>' . $Comisiones[0] . '</td>
					<td>' . locale_number_format($Comisiones[8],2) . '</td>
					<td>' . $Comisiones[4] . '</td>
					<td>' . $myrowzon[1] . '</td>
					<td>' . $myrowzon[0] . '</td>
					<td>' . $myrowzon[2] . '</td>
				
						
				</tr>';
}
echo '<tr class="striped_row"><td colspan="3">TOTAL=</td><td>'.locale_number_format($importe,2).'</td><td colspan="4"></td></tr>';
$total+=$importe;
echo '<tr class="striped_row"><td colspan="3">TOTAL GLOBAL=</td><td>'.locale_number_format($total,2).'</td><td colspan="4"></td></tr>';
	echo '</table>';

} 		
		
		
		
	}
	include('includes/footer.php');
}
?>
