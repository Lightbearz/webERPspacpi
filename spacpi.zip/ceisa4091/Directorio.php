<?php
include('includes/session.php');
$Title = 'Directorio';
echo '<link href="', $RootPath, '/css/menu.css" rel="stylesheet" type="text/css" />
			<link href="', $RootPath, '/css/print.css" rel="stylesheet" type="text/css" media="print" />
			<link href="', $RootPath, '/css/', $_SESSION['Theme'], '/default.css" rel="stylesheet" type="text/css" media="screen"/>';
			echo		'<div id="BodyWrapDiv" >';
echo '<table class="selection">
			<tr>
				<th> Ext </th>
				<th> Area </th>
				<th> Nombre </th>
				<th> Correo </th>
				<th> Celular </th>
			</tr>';

$sql="SELECT * FROM directorio ORDER by ext ASC";
$result=DB_query($sql);

while($myrow=DB_fetch_array($result)){
echo '<tr class="striped_row">
				<td style="text-align:center" > ' .$myrow[0]. ' </td>
				<td> ' .$myrow[1]. ' </td>
				<td> '.$myrow[2].' </td>
				<td> '.$myrow[3].' </td>
				<td> '.$myrow[4].' </td>
			</tr>';
}			
			
	echo '</table></div>';
					
		
	
?>
