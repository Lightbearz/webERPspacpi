<?php


include('includes/session.php');

$Title=_('Asistencia Colaboradores');
$ViewTopic = 'GLInquiries';
$BookMark = 'Asistencia';
include('includes/header.php');
   
  //esta funcion se utiliza para dar las instrucciones al usuario para cada pantalla
  echo '<div class="page_help_text">' .
			_('Seleccione el rango de las fechas de las que se desea graficar') . '<br />' .
            _('Agrupe por día o por mes') ;
            echo '</div><br /><form method="post" action="' . htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . '">';
  echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
  echo '<table><tr>';
  //si el campo de la fecha esta vacio se coloca la fecha de hoy menos 7 dias
  if($_POST['FechaInicio']=='')
  {
         
    $_POST['FechaInicio']= date("Y-m-d",strtotime("- 7 days"));
  }
  if($_POST['FechaFin']=='')
  {
         
    $_POST['FechaFin']= date("Y-m-d");
  }
 
  echo '<th><label>Fecha inicio: </label><input type="text" class="date" name="FechaInicio" size =10 value = "'.$_POST['FechaInicio'].'" required /></th>
  <th><label>Fecha fin: </label><input type="text" size="10" class="date" name="FechaFin" value="'.$_POST['FechaFin'].'" required /></th>';
   
  echo '<th><select name = "Colaborador">';
  $sqlin="SELECT * FROM colaboradores ORDER BY id ASC";
  $resultin=DB_query($sqlin);
if($_POST['Colaborador']==''){
  echo '<option value="" selected="selected"> - Mostrar todos - </option>';
}
else {
  echo '<option value="" selected="selected" > - Mostrar todos - </option>';
}
  while($myrowin=DB_fetch_array($resultin)){
    if($_POST['Colaborador']==$myrowin['id']){
      echo '<option value="'.$myrowin['id'].'" selected>|'.$myrowin['id'].'| '.$myrowin['colaborador'].'</option>';
    }else{
echo '<option value="'.$myrowin['id'].'">|'.$myrowin['id'].'| '.$myrowin['colaborador'].'</option>';
    }

  }
  echo '</select></th>';

  echo '<td><input type=submit name="submit" value="Ver en pantalla"/></td>';
  echo '</table></form>';
  if(isset($_POST['submit']))
  {
    $whereclause='';
    if(isset($_POST['FechaInicio'])){
      $_POST['FechaInicio']=date('Y-m-d',strtotime($_POST['FechaInicio']));
      $whereclause.=" and checadas.date>'".$_POST['FechaInicio']."' ";
     }
     if(isset($_POST['FechaFin'])){
      $_POST['FechaFin']=date('Y-m-d',strtotime($_POST['FechaFin']));
      $whereclause.=" and checadas.date<'".$_POST['FechaFin']." 23:59:59' ";
         }
         if(isset($_POST['Colaborador']) and $_POST['Colaborador']!='' ){
          $whereclause.=" and checadas.id='".$_POST['Colaborador']."' ";
             }
   $sql="SELECT checadas.id,colaboradores.colaborador,colaboradores.horaentrada,colaboradores.horasalida,checadas.date,checadas.reloj,checadas2.maximo,checadas2.minimo,cuenta.dias FROM (SELECT id,date,'CEISA' as reloj FROM ceisa UNION SELECT id,date,'CISSA' as reloj FROM cissa) as checadas 
   LEFT JOIN colaboradores ON colaboradores.id=checadas.id
   LEFT JOIN (SELECT MAX(checadas.date) as maximo,id,MIN(checadas.date) as minimo FROM (SELECT id,date,'CEISA' as reloj FROM ceisa UNION SELECT id,date,'CISSA' as reloj FROM cissa) as checadas 
  WHERE 1 ".$whereclause." GROUP by checadas.id, date_format(date,'%y-%m-%d')) as checadas2 on (checadas2.maximo=checadas.date or checadas2.minimo=checadas.date)  and checadas2.id=checadas.id
  LEFT JOIN (SELECT COUNT(id) as dias,id FROM (SELECT MAX(checadas.date) as maximo,id FROM (SELECT id,date,'CEISA' as reloj FROM ceisa UNION SELECT id,date,'CISSA' as reloj FROM cissa) as checadas WHERE 1 ".$whereclause." GROUP by checadas.id, date_format(date,'%y-%m-%d')) as conteo GROUP BY id) as cuenta ON cuenta.id=checadas.id
   WHERE 1 ".$whereclause." ORDER BY checadas.id ASC,checadas.date ASC ";
   
      $result=DB_query("SET SQL_BIG_SELECTS=1");
    //  echo $sql;
       $result=DB_query($sql);
       

       echo '<table class="selection">
       <tr>
       <th>No. Empleado</th>
       <th>Colaborador</th>
       <th>Hora</th>
       <th>Lugar</th>
       </tr>';
$fechaanterior='';
$empleado='';
$i=0;
$dias=0;
$descontar=0;
       while($myrow=DB_fetch_array($result)){
$tarde=floor((strtotime(substr($myrow['date'],-8))-strtotime($myrow['horaentrada']))/60);
$salida=ceil((strtotime($myrow['horasalida'])-strtotime(substr($myrow['date'],-8)))/60);
         if($fechaanterior!=substr($myrow['date'],0,10)){
          $inicial=$myrow['date'];
         }

         $style='';
                         if($myrow['maximo']==$myrow['date']){
                          $style.='font-weight:bold;text-decoration:underline;';
         }
         if($tarde>=4 and $myrow['minimo']==$myrow['date']){
          $style.='background-color:lightcoral;';
         }
         if($tarde<4 and $myrow['minimo']==$myrow['date']){
          $style.='background-color:limegreen;';
         }
         if($salida>=1 and $myrow['maximo']==$myrow['date']){
          $style.='background-color:orange;';
         }
        //  if($salida<1 and $myrow['maximo']==$myrow['date']){
        //   $style.='background-color:lightblue;';
        //  }
          
        echo '
        <tr class="striped_row" style="'.$style.'" >
        <td>'.$myrow['id'].'</td>
        <td>'.$myrow['colaborador'].'</td>
        <td '.$max.'>'.$myrow['date'].'</td>
        <td>'.$myrow['reloj'].'</td>';
        if($tarde>=4 and $myrow['minimo']==$myrow['date']){
          echo '<td> Minutos tarde llegada : '.$tarde.'</td>';
          $descontar+=$tarde*2;
         }
         if($salida>=1and $myrow['maximo']==$myrow['date']){
          echo '<td> Minutos salida temprano : '.$salida.'</td>';
          $descontar+=$salida;
         }
         if($salida<0and $myrow['maximo']==$myrow['date']){
                    $descontar+=$salida;
         }
        if($myrow['maximo']==$myrow['date']){      
          $dias=$dias+1;
          if($dias==$myrow['dias']){
            echo '<td>Días: '.$myrow['dias'].' días </td>';
            if($descontar>0){
              echo '<td style="background-color:lightcoral">Debe: '.$descontar.' minutos </td>';
            }
            else{
              echo '<td style="background-color:limegreen">A favor: '.-$descontar.' minutos </td>';

            }
            $dias=0;
            $descontar=0;
                    }
          $inicial='';
               }
         
        echo '</tr>';
        $fechaanterior=substr($myrow['date'],0,10);
        $i=$i+1;
       }
       echo '</table> '.$i.'';
  }

  include('includes/footer.php');



?>
