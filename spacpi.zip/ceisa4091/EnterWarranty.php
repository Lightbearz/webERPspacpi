<?php

include('includes/session.php');
$Title = _('Ingreso de material a servicio');
if(!isset($_GET['Print'])){
include('includes/header.php');
}

if(isset($_GET['New']) AND $_GET['New']=='Yes'){
unset($_SESSION['WCliente']);
unset($_SESSION['WDireccion']);
unset($_SESSION['Wphone']);
unset($_SESSION['Wemail']);
unset($_SESSION['WRefcompra']);
unset($_SESSION['WPackin']);
unset($_SESSION['WArea']);
unset($_SESSION['WDebtorno']);
$_SESSION['Counterwarr']=1;


echo '<p class="page_title_text">Selección de tipo de garantía</p>';
echo '<div class="page_help_text">' .
			_('En esta página se debe dar ingreso al material para reparaciones y garantías.') . '<br />' .
			_('Elija el tipo de garantía de acuerdo al cliente').'<br />'.
			_('Seleccione "DIRECTO" si el cliente no está registra en SPACPI o desconoce el nombre de su distribuidor  ') .  '<br />' .
			_('Seleccine "DISTRIBUIDOR" si viene por parte de un cliente o vendedor registrado en SPACPI') . '</div>';

	echo '<form method="get" >';
    echo '<div>';

	echo '<table class="selection"><td class="centre"><input type="submit"  style="width:100px;height:50px;font-size:medium" name="Directo" value="Directo"></input></td><td class="centre"><input type="submit" style="width:100px;height:50px;font-size:medium" name="Distribuidor" value="Distribuidor"></input></td></table>';
echo '</form>';
}


///////////////////////////////////////////////////////////////SEGUNDA PANTALLA DIRECTO
if(isset($_GET['Directo'])){
$_SESSION['tiposervicio']='DIR';
$i=1;
while($_SESSION['StockCode'.$i.'']!=''){
$_SESSION['StockCode'.$i.'']='';
$_SESSION['CustInvNo'.$i.'']='';
$_SESSION['Elect'.$i.'']='';
$_SESSION['Boughtdate'.$i.'']='';
$_SESSION['Packdate'.$i.'']='';
$_SESSION['Falla'.$i.'']='';
$_SESSION['Condicion'.$i.'']='';
$_SESSION['Accesorios'.$i.'']='';
$_SESSION['Error404']=0;
$_SESSION['Error405']=0;
$i=$i+1;
}

echo '<p class="page_title_text">Ingrese información del cliente</p>';
echo '<form method="get"  >';
    echo '<div>';
	echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
	echo '</br><table class="selection"><tr><td> Nombre completo del cliente: </td><td class="centre"><input type="text" required="required" size="45" maxlengthsize="100" name="Cliente" value=""></input></td></tr>';
echo '<tr><td> Dirección: </td><td><input type="text" required="required" size="45" maxlengthsize="100" name="Direccion" value=""></input></td></tr>';
echo '<tr><td>' . _('Zona de Ventas').':</td>
                  <td colspan="3"><select name="Area" required="required">';
		$sql = "SELECT areas.areadescription,areas.areacode FROM (areas INNER JOIN custbranch ON areas.areacode LIKE custbranch.area) GROUP BY areacode ORDER BY areas.areacode";
		$AreasResult=DB_query($sql);
		echo '<option selected="selected"  value=""></option>';
		while ($myrow=DB_fetch_array($AreasResult)) {
		echo '<option value="' . $myrow['areacode'] . '">'. $myrow['areacode'].' '. $myrow['areadescription']. '</option>';
		}
		echo '</select></td></tr>';
echo '<tr><td> No. de teléfono: </td><td><input type="tel" required="required" size="20" maxlengthsize="20" name="phone" value=""></input></td></tr>';
echo '<tr><td> Email: </td><td><input type="email" size="20" maxlengthsize="20" name="Email" value=""></input></td></tr>';
echo '<tr><td>(Opcional)Referencia: </td><td><input type="text" size="45" maxlengthsize="50" name="Refcompra" value=""></input></td></tr>';
echo '<tr><td>(Nombre y Guía)Paquetería: </td><td><input type="text" size="45" maxlengthsize="50" name="Packin" value=""></input></td></tr></table></br>';
echo ' <span class="centre" colspan="2"><input type="submit"  name="Avanzar" value="Ingresar Cliente"></span>';

echo '</form>';



}
///////////////////////////////////////////////////////////////////////////////////////////////////////SEGUNDA PANTALLA DISTRIBUIDOR
if(isset($_GET['Distribuidor'])){
$_SESSION['tiposervicio']='DIS';
$i=1;
while($_SESSION['StockCode'.$i.'']!=''){
$_SESSION['StockCode'.$i.'']='';
$_SESSION['CustInvNo'.$i.'']='';
$_SESSION['Elect'.$i.'']='';
$_SESSION['Boughtdate'.$i.'']='';
$_SESSION['Packdate'.$i.'']='';
$_SESSION['Falla'.$i.'']='';
$_SESSION['Condicion'.$i.'']='';
$_SESSION['Accesorios'.$i.'']='';
$_SESSION['Error404']=0;
$_SESSION['Error405']=0;
$i=$i+1;
}

echo '<p class="page_title_text">Búsqueda por sucursal</p>';
echo '<form action="', htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8'), '?Distribuidor=Distribuidor" method="post">',
	'<input type="hidden" name="FormID" value="', $_SESSION['FormID'], '" />';
if(mb_strlen($msg) > 1) {
	prnMsg($msg, 'info');
}
echo '<p class="page_title_text"><img alt="" src="', $RootPath, '/css/', $Theme,
	'/images/magnifier.png" title="',// Icon image.
	_('Search'), '" /> ',// Icon title.
	_('Search for Customers'), '</p>';// Page title.

echo '<table cellpadding="3" class="selection">';

echo '<tr>
		<td colspan="2">', _('Enter a partial Name'), ':</td>
		<td><input type="text" maxlength="25" name="Keywords" title="', _('If there is an entry in this field then customers with the text entered in their name will be returned') , '"  size="20" ',
			( isset($_POST['Keywords']) ? 'value="' . $_POST['Keywords'] . '" ' : '' ), '/></td>';

echo '<td><b>', _('OR'), '</b></td><td>', _('Enter a partial Code'), ':</td>
		<td><input maxlength="18" name="CustCode" pattern="[\w-]*" size="15" type="text" title="', _('If there is an entry in this field then customers with the text entered in their customer code will be returned') , '" ', (isset($_POST['CustCode']) ? 'value="' . $_POST['CustCode'] . '" ' : '' ), '/></td>
	</tr></table>';
	
	echo '<div class="centre">
		<input name="Search" type="submit" value="', _('Search Now'), '" /></div>';
		if(isset($_POST['Search'])){
if(mb_strlen($_POST['Keywords'])==0 AND mb_strlen($_POST['CustCode'])==0){
	prnMsg('No ingresó ninguna información, ingrese código de Cliente o Parte del nombre para continuar', 'error');
}	
else{
if(mb_strlen($_POST['Keywords'])!=0 AND mb_strlen($_POST['CustCode'])!=0){$sql="SELECT * FROM custbranch WHERE brname LIKE '%".$_POST['Keywords']."%' OR branchcode LIKE '".$_POST['CustCode']."'";}
if(mb_strlen($_POST['Keywords'])!=0 AND mb_strlen($_POST['CustCode'])==0){$sql="SELECT * FROM custbranch WHERE brname LIKE '%".$_POST['Keywords']."%'";}
if(mb_strlen($_POST['Keywords'])==0 AND mb_strlen($_POST['CustCode'])!=0){$sql="SELECT * FROM custbranch WHERE branchcode LIKE '".$_POST['CustCode']."'";}

	$result=DB_query($sql);
	if(DB_num_rows($result) == 0) {
	prnMsg('No se encontraron coincidencias', 'warn');
	}
	echo '<table cellpadding="2" class="selection">
				<thead>
					<tr>
						<th class="ascending">' . _('Code') . '</th>
						<th class="ascending">' . _('Branch') . '</th>
						<th class="ascending">' . _('Contact') . '</th>
						<th class="ascending">' . _('Phone') . '</th>
						<th class="ascending">' . _('Area') . '</th>
					</tr>
				</thead>';
	while($myrow=DB_fetch_array($result)){
		echo '<tr class="striped_row">
				<td><button type="submit" name="CustomerSelection" value="'.$myrow['branchcode'].'" >', $myrow['branchcode'], '</button></td>
				<td class="text">', htmlspecialchars($myrow['brname'], ENT_QUOTES, 'UTF-8', false), '</td>
				<td class="text">', $myrow['contactname'], '</td>
				<td class="text">', $myrow['phoneno'], '</td>
				<td>' . $myrow['area']. '</td>
			</tr>';
	
	}
	echo '</table>';

}		
		}
//echo ' <span class="centre" colspan="2"><input type="submit"  name="Avanzar" value="Ingresar Cliente"></span>';

echo '</form>';
if(isset($_POST['CustomerSelection'])) {
$sql="SELECT * FROM custbranch WHERE branchcode LIKE '".$_POST['CustomerSelection']."'";
$result=DB_query($sql);
$myrow=DB_fetch_array($result);

echo '<p class="page_title_text">Ingrese información de entrega</p>';
echo '<form method="get"  >';
    echo '<div>';
	echo '<input type="hidden" name="Debtorno" value="' . $myrow['debtorno'] . '" />';
	echo '</br><table class="selection"><tr><td> Nombre completo del cliente: </td><td class="centre"><input type="text" required="required" size="45" maxlengthsize="100" name="Cliente" value="'.$myrow['brname'].'"></input></td></tr>';
echo '<tr><td> Dirección: </td><td><input type="text" required="required" size="45" maxlengthsize="100" name="Direccion" value="'.$myrow['braddress1'].' '.$myrow['braddress2'].' '.$myrow['braddress3'].' '.$myrow['braddress4'].' '.$myrow['braddress5'].' '.$myrow['braddress6'].'"></input></td></tr>';
echo '<tr><td>' . _('Zona de Ventas').':</td>
                  <td colspan="3"><select name="Area" required="required">';
		$sql = "SELECT areas.areadescription,areas.areacode FROM (areas INNER JOIN custbranch ON areas.areacode LIKE custbranch.area) GROUP BY areacode ORDER BY areas.areacode";
		$AreasResult=DB_query($sql);

		while ($myrowa=DB_fetch_array($AreasResult)) {
		echo '<option value="' . $myrowa['areacode'] . '"';
		if($myrowa['areacode']==$myrow['area']){ echo ' selected="selected" ';}
		echo'>'. $myrowa['areacode'].' '. $myrowa['areadescription']. '</option>';
		}
		echo '</select></td></tr>';
echo '<tr><td> No. de teléfono: </td><td><input type="tel" required="required" size="20" maxlengthsize="20" name="phone" value="'.$myrow['phoneno'].'"></input></td></tr>';
echo '<tr><td> Email: </td><td><input type="email" size="20" maxlengthsize="20" name="Email" value="'.$myrow['email'].'"></input></td></tr>';
echo '<tr><td>(Opcional)Referencia: </td><td><input type="text" size="45" maxlengthsize="50" name="Refcompra" value=""></input></td></tr>';
echo '<tr><td>(Nombre y Guía)Paquetería: </td><td><input type="text" size="45" maxlengthsize="50" name="Packin" value=""></input></td></tr></table></br>';
echo ' <span class="centre" colspan="2"><input type="submit"  name="Avanzar" value="Ingresar Cliente"></span>';

echo '</form>';




	}


}



/////////////////////////////////////////////////////////////BOTÓN DELETE
if(isset($_GET['Delete'])){
$i=$_GET['Delete'];
$_SESSION['StockCode'.$i.'']='';
$_SESSION['StockCode'.$i.'']='';
$_SESSION['CustInvNo'.$i.'']='';
$_SESSION['Elect'.$i.'']='';
$_SESSION['Boughtdate'.$i.'']='';
$_SESSION['Packdate'.$i.'']='';
$_SESSION['Falla'.$i.'']='';
$_SESSION['Condicion'.$i.'']='';
$_SESSION['Accesorios'.$i.'']='';

$u=$i+1;
while($_SESSION['StockCode'.$u.'']!=''){
$_SESSION['StockCode'.$i.'']=$_SESSION['StockCode'.$u.''];
$_SESSION['CustInvNo'.$i.'']=$_SESSION['CustInvNo'.$u.''];
$_SESSION['Elect'.$i.'']=$_SESSION['Elect'.$u.''];
$_SESSION['Boughtdate'.$i.'']=$_SESSION['Boughtdate'.$u.''];
$_SESSION['Packdate'.$i.'']=$_SESSION['Packdate'.$u.''];
$_SESSION['Falla'.$i.'']=$_SESSION['Falla'.$u.''];
$_SESSION['Condicion'.$i.'']=$_SESSION['Condicion'.$u.''];
$_SESSION['Accesorios'.$i.'']=$_SESSION['Accesorios'.$u.''];
$i=$i+1;
$u=$u+1;
}
$u=$u-1;
$_SESSION['StockCode'.$u.'']='';
$_SESSION['CustInvNo'.$u.'']='';
$_SESSION['Elect'.$u.'']='';
$_SESSION['Boughtdate'.$u.'']='';
$_SESSION['Packdate'.$u.'']='';
$_SESSION['Falla'.$u.'']='';
$_SESSION['Condicion'.$u.'']='';
$_SESSION['Accesorios'.$u.'']='';
$_SESSION['Counterwarr']=$_SESSION['Counterwarr']-1;
unset($_GET['Delete']);
echo '<script>
window.location.href = "https://www.spacpi.com/ceisa4091/EnterWarranty.php?Avanzar=1"
</script>';



}


//////////////////////////////////////////////////////////TERCERA PANTALLA

if(isset($_GET['Avanzar']) or $_SESSION['Counterwarr']!=1 AND !isset($_GET['Finalizar']) AND !isset($_GET['Print'])){
if($_GET['Avanzar']=='Ingresar Cliente'){
$_SESSION['WCliente']=$_GET['Cliente'];
$_SESSION['WDireccion']=$_GET['Direccion'];
$_SESSION['Wphone']=$_GET['phone'];
$_SESSION['Wemail']=$_GET['Email'];
$_SESSION['WRefcompra']=$_GET['Refcompra'];
$_SESSION['WPackin']=$_GET['Packin'];
$_SESSION['WArea']=$_GET['Area'];
$_SESSION['WDebtorno']=$_GET['Debtorno'];
unset($_GET['Cliente']);
unset($_GET['Direccion']);
unset($_GET['phone']);
unset($_GET['Email']);
unset($_GET['Refcompra']);
unset($_GET['FormID']);
unset($_GET['Area']);
}
echo '<p class="page_title_text">
		<img src="'.$RootPath.'/css/'.$Theme.'/images/customer.png" title="' . _('Customer') .
	'" alt="" /> Garantía de ' . $_SESSION['WCliente'] . '</p>';
echo '<p class="page_title_text">Ingrese la información del material recibido</p>';

echo '</br><table class="selection">';
echo '<tr>
<th> No. </th>
<th> Código artículo </th>
<th> Remisión # </th>
<th> Factura Electrónica </th>
<th> Fecha compra </th>
<th> Fecha de grabado </th>
<th> Falla reportada </th>
<th> Condición producto </th>
<th> Accesorios </th></tr>';
echo '<form  method="post" >';
echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
if($_SESSION['Error404']==1){
	prnMsg('Este código de artículo no existe', 'warn');
}
if($_SESSION['Error405']==1){
	prnMsg('Este No de transacción no existe', 'warn');
}
$_SESSION['Error404']=0;
$_SESSION['Error405']=0;


echo '<tr class="striped_row">
<td>'.$_SESSION['Counterwarr'].'</td>

<td><input tabindex="1" type="text" name="StockCode'.$_SESSION['Counterwarr'].'" required="required" value="' . $_SESSION['StockCode'.$_SESSION['Counterwarr'].''] . '" title="' . _('Enter text that you wish to search for in the item code') . '" size="20" maxlength="20" /> </td>
<td><input tabindex="2" type="tel" name="CustInvNo'.$_SESSION['Counterwarr'].'" value="' . $_SESSION['CustInvNo'.$_SESSION['Counterwarr'].''] . '" class="integer" size="8" maxlength="8" /></td>
<td><input tabindex="2" type="text" name="Elect'.$_SESSION['Counterwarr'].'" value="' . $_SESSION['Elect'.$_SESSION['Counterwarr'].''] . '" size="10" maxlength="10" /></td>
<td><input tabindex="3" type="text" required="required" class="date" name="Boughtdate'.$_SESSION['Counterwarr'].'" maxlength="10" size="11" onchange="isDate(this, this.value, '."'".$_SESSION['DefaultDateFormat']."'".')" value="' . $_SESSION['Boughtdate'.$_SESSION['Counterwarr'].''] . '" /></td>
<td><input tabindex="4" type="text" required="required" class="date" name="Packdate'.$_SESSION['Counterwarr'].'" maxlength="10" size="11" onchange="isDate(this, this.value, '."'".$_SESSION['DefaultDateFormat']."'".')" value="' . $_SESSION['Packdate'.$_SESSION['Counterwarr'].''] . '" /></td>
<td><input tabindex="5" type="text" required="required" size="45" maxlengthsize="50" name="Falla'.$_SESSION['Counterwarr'].'" value="'.$_SESSION['Falla'.$_SESSION['Counterwarr'].''].'"/></td>
<td><input tabindex="6" type="text" required="required" size="45" maxlengthsize="50" name="Condicion'.$_SESSION['Counterwarr'].'" value="'.$_SESSION['Condicion'.$_SESSION['Counterwarr'].''].'"/></td>
<td><input tabindex="7" type="text" size="45" maxlengthsize="50" name="Accesorios'.$_SESSION['Counterwarr'].'" value="'.$_SESSION['Accesorios'.$_SESSION['Counterwarr'].''].'"/></td>
<td><input tabindex="8" type="submit" style="background-color:lightblue;width:100px;height:40px;font-size:medium" name="EnterItem" value="Añadir"/></td>';
echo '</form>';
if($_SESSION['Counterwarr']>1){
echo '<form action="', htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8'), '?Finalizar=1" method="post" >';
echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
echo '<td ><input style="background-color:limegreen;width:100px;height:40px;font-size:medium" type="submit"  name="Finalizar" onclick="return confirm(\'¿Quieres finalizar?\');" value="Finalizar"></input></td>';
echo '</form>';
}
echo '</tr>';
if(isset($_POST['EnterItem'])){
$_SESSION['StockCode'.$_SESSION['Counterwarr'].'']=strtoupper($_POST['StockCode'.$_SESSION['Counterwarr'].'']);
$_SESSION['CustInvNo'.$_SESSION['Counterwarr'].'']=$_POST['CustInvNo'.$_SESSION['Counterwarr'].''];
$_SESSION['Elect'.$_SESSION['Counterwarr'].'']=$_POST['Elect'.$_SESSION['Counterwarr'].''];
$_SESSION['Boughtdate'.$_SESSION['Counterwarr'].'']=$_POST['Boughtdate'.$_SESSION['Counterwarr'].''];
$_SESSION['Packdate'.$_SESSION['Counterwarr'].'']=$_POST['Packdate'.$_SESSION['Counterwarr'].''];
$_SESSION['Falla'.$_SESSION['Counterwarr'].'']=ucfirst(strtolower($_POST['Falla'.$_SESSION['Counterwarr'].'']));
$_SESSION['Condicion'.$_SESSION['Counterwarr'].'']=ucfirst(strtolower($_POST['Condicion'.$_SESSION['Counterwarr'].'']));
$_SESSION['Accesorios'.$_SESSION['Counterwarr'].'']=ucfirst(strtolower($_POST['Accesorios'.$_SESSION['Counterwarr'].'']));

$sql="SELECT stockid FROM stockmaster WHERE stockid='".$_POST['StockCode'.$_SESSION['Counterwarr'].'']."'";
$result=DB_query($sql);
$verif=DB_fetch_array($result);
if(!isset($verif[0])){
$_SESSION['Error404']=1;
}
if($_POST['CustInvNo'.$_SESSION['Counterwarr'].'']!=''){
$sqlon="SELECT transno FROM debtortrans WHERE transno='".$_POST['CustInvNo'.$_SESSION['Counterwarr'].'']."' AND type='10'";
$resulton=DB_query($sqlon);
$verifon=DB_fetch_array($resulton);
}
if($_POST['CustInvNo'.$_SESSION['Counterwarr'].'']==''){
$verifon[0]=1;
}
if(!isset($verifon[0])){
$_SESSION['Error405']=1;
}
if(isset($verif[0]) and isset($verifon[0])){
$_SESSION['Counterwarr']=$_SESSION['Counterwarr']+1;
}
unset($_POST['EnterItem']);
echo '<script>
window.location.href = "https://www.spacpi.com/ceisa4091/EnterWarranty.php?Avanzar=1"
</script>';
}



/////////////////////////////////////////IMPRESIÓN DE ARTICULOS

if($_SESSION['Counterwarr']>1){
$i=1;
while($_SESSION['Counterwarr']>$i){
echo '<tr class="striped_row">
<td>'.$i.'</td>
<td>'.$_SESSION['StockCode'.$i.''].'</td>
<td>'.$_SESSION['CustInvNo'.$i.''].'</td>
<td>'.$_SESSION['Elect'.$i.''].'</td>
<td>'.$_SESSION['Boughtdate'.$i.''].'</td>
<td>'.$_SESSION['Packdate'.$i.''].'</td>
<td>'.$_SESSION['Falla'.$i.''].'</td>
<td>'.$_SESSION['Condicion'.$i.''].'</td>
<td>'.$_SESSION['Accesorios'.$i.''].'</td>
<td style="text-align:center"><a href="', htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8'), '?Delete='.$i.'" onclick="return confirm(\'¿Estas seguro de borrar este artículo?\');">', _('Delete'), '</a></td>
</tr>';
$i=$i+1;
}

}
echo '</table>';

}
///////////////////////////////////////////////INGRESAR A BASE DE DATOS
if(isset($_GET['Finalizar'])){

$sql="SELECT lote FROM ordenesservicio ORDER BY lote DESC LIMIT 1";
$nexttrans=DB_query($sql);
$loterow=DB_fetch_array($nexttrans);
if(!isset($loterow[0])){
$lote=1;
}
if(isset($loterow[0]) and $loterow[0]!=''){
$lote=$loterow[0]+1;
}
$i=1;
$fechaing=date('Y-m-d H:i:s');
		$ErrMsg =_('CRITICAL ERROR') . '! ' . _('NOTE DOWN THIS ERROR AND SEEK ASSISTANCE') . ': ' . _('The request header record could not be inserted because');
		$DbgMsg = _('The following SQL to insert the request header record was used');

while($_SESSION['StockCode'.$i.'']!=''){
$SQL="INSERT INTO ordenesservicio (stockid,
											debtorno,
											contacto,
											phoneno,
											email,
											direccion,
											areacode,
											fechacaptura,
											fechagrabado,
											fechacompra,
											falla,
											condicion,
											transno,
											felectronica,
											accesorios,
											useriding,
											lote,
											estatus,
											tipo,
											referencia,
											paqueteriain)
										VALUES(
											'" . $_SESSION['StockCode'.$i.''] . "',
											'" . $_SESSION['WDebtorno'] . "',
											'" . $_SESSION['WCliente'] . "',
											'" . $_SESSION['Wphone'] . "',
											'" . $_SESSION['Wemail'] . "',
											'" . $_SESSION['WDireccion'] . "',
											'" . $_SESSION['WArea'] . "',
											'" . $fechaing . "',
											'" . ConvertSQLDate($_SESSION['Packdate'.$i.'']) . "',
											'" . ConvertSQLDate($_SESSION['Boughtdate'.$i.'']) . "',
											'" . $_SESSION['Falla'.$i.''] . "',
											'" . $_SESSION['Condicion'.$i.''] . "',
											'" . $_SESSION['CustInvNo'.$i.''] . "',
											'" . $_SESSION['Elect'.$i.''] . "',
											'" . $_SESSION['Accesorios'.$i.''] . "',
											'" . $_SESSION['UserID'] . "',
											'" . $lote . "',
											'sinorden',
											'" . $_SESSION['tiposervicio'] . "',
											'" .$_SESSION['WRefcompra']. "',
											'".$_SESSION['WPackin']."')";

		$Result = DB_query($SQL,$ErrMsg,$DbgMsg,true);
		$i+=1;
}

prnMsg('Se guardó su información, imprima el formato de vale para poder finalizar', 'success');
echo '<h2><a href="', htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8'), '?Print='.$lote.'" target="_blank">Imprimir formato</a></h2>';
echo '<h3><a href="', htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8'), '?New=Yes">Realizar un nuevo ingreso</a></h3>';
echo '<h3><a href="GeneracionOrdServicio.php?OrdLote='.$lote.'"> Continuar a Ordenes de Servicio </a></h3>';

}


///////////////////////////////////////////////IMPRESION VALE
if(isset($_GET['Print'])){
echo '<div style="size:8.5in 11in">';
$sql = "SELECT coyname,
					gstno,
					companynumber,
					regoffice1,
					regoffice2,
					regoffice3,
					regoffice4,
					regoffice5,
					regoffice6,
					telephone,
					fax,
					email,
					currencydefault,
					debtorsact,
					pytdiscountact,
					creditorsact,
					payrollact,
					grnact,
					exchangediffact,
					purchasesexchangediffact,
					retainedearnings,
					gllink_debtors,
					gllink_creditors,
					gllink_stock,
					freightact
				FROM companies
				WHERE coycode=1";
				$resultcomp=DB_query($sql);
				$myrowcomp=DB_fetch_array($resultcomp);
				$sql="SELECT * FROM ordenesservicio WHERE lote='".$_GET['Print']."' ORDER by stockid ASC";
		$result=DB_query($sql);
		$myrow=DB_fetch_array($result);
		if($myrow['Vale']==''){
		$impresion=$_SESSION['UserID'].' '.date('Y-m-d H:i:s');
		$sql="UPDATE ordenesservicio SET Vale='".$impresion."' WHERE lote='".$_GET['Print']."'" ;
		$update=DB_query($sql);
		}
		$sql="SELECT COUNT(lote) as cantidad FROM ordenesservicio WHERE lote='".$_GET['Print']."' ORDER by stockid ASC";
		$result2=DB_query($sql);
		$myrow2=DB_fetch_array($result2);
echo '<table width="95%" style="border: solid black 1px;border-collapse:collapse;" class="centre"><thead>';
	echo '<tr style="border-style:hidden">
			<th colspan="3" style="text-align:center"  ></br><img src="'. $RootPath . '/' . $_SESSION['LogoFile'] . '" width="240" style="float:left" alt="webERP" title="webERP ' . _('Copyright') . ' &copy; weberp.org - ' . date('Y') . '" />
			<span style="text-align:center;font-size:15px">'.$myrowcomp[0].'</br>'.$myrowcomp['regoffice1'].' '.$myrowcomp['regoffice2'].' '.$myrowcomp['regoffice4'].'</br>'.$myrowcomp['regoffice6'].' TEL. '.$myrowcomp['telephone'].'</br> www.ceisa.com.mx '.$myrowcomp['email'].'</span></th>
		</tr>
		<tr style="border-style:hidden">
			<th colspan="3" style="font-size:30px;text-align:center;color:blue"> VALE DE INGRESO A GARANTÍA </th>


		</tr>
<tr style="border-style:hidden"><th colspan="3" style="font-size:15px;text-align:center;color:blue">Fecha y hora: <span  style="font-size:15px;text-align:center;color:black">'.$myrow['fechacaptura'].' </span></th></tr>
		<tr style="border-style:hidden"><th colspan="3" style="font-size:15px;text-align:center;color:blue;border-bottom:solid black 1px;border-collapse:collapse;">Lote: <span  style="font-size:15px;text-align:center;color:black">'.$_GET['Print'].' </span> | No. artículos:  <span  style="font-size:15px;text-align:center;color:black">'.$myrow2['cantidad'].'</span></th></tr>';
	echo	'<tr style="border-bottom:solid black 1px;border-collapse:collapse;border-left:hidden;border-right:hidden;"><th colspan="3" style="font-size:15px;text-align:center;color:blue;border-bottom:solid black 1px;border-collapse:collapse;"></br></th></tr>';

		echo '<tr style="border: solid black 1px">
			<th  style="border: solid black 1px;border-collapse:collapse;width:21%">Código</th>
			<th  style="border: solid black 1px;border-collapse:collapse;width:40%">Condición</th>
			<th  style="border: solid black 1px;border-collapse:collapse;width:34%">Accesorios</th>
		</tr></thead><tbody>';	
		echo '<tr style="border: solid black 1px;border-collapse:collapse;">
			<td style="border: solid black 1px;border-collapse:collapse;text-align:center;%" >'.$myrow['stockid'].'</td>
			<td style="border: solid black 1px;border-collapse:collapse;">'.$myrow['condicion'].'</td>
			<td style="border: solid black 1px;border-collapse:collapse;">'.$myrow['accesorios'].'</td>

		</tr>';

while($myrow=DB_fetch_array($result)){	
	echo '<tr style="border: solid black 1px;border-collapse:collapse;">
	<td style="border: solid black 1px;border-collapse:collapse;text-align:center;width:21%" >'.$myrow['stockid'].'</td>
			<td style="border: solid black 1px;border-collapse:collapse;width:40%">'.$myrow['condicion'].'</td>
			<td style="border: solid black 1px;border-collapse:collapse;width:34%">'.$myrow['accesorios'].'</td>
		</tr>';	

		
	}	
	

echo '</tbody></table></br></br>';
echo '</br></br>';
echo '<div style="page-break-inside: avoid" ><div class="centre" style="text-align:center;" >Recibe: _____________________________________Entrega:_____________________________________</div>';
echo '</br></br>';
echo '<div class="centre" style="color:blue" >Consideraciones Importantes:</div>';
echo '<ul style="color:blue;text-align:justify">';
echo '<li>CEISA no se hace responsable por los materiales que no sean reclamados dentro de los 30 días naturales después de la reparación.</li>';
echo '<li>El equipo será revisado por el área técnica CEISA de acuerdo a las políticas establecidas en la póliza de garantía contenida en el empaque del producto.</li>';
echo '<li>El apartado "Condiciones del producto" describe el estado físico del artículo observable al momento del ingreso. </li>';
echo '<li>En caso de que el periodo de garantía de los materiales haya expirado, si así lo desea el usuario, éstos podrían ser reparados con costo, la cotización para la reparación se hará llegar a su vendedor correspondiente. </li>';
echo '<li>La reparación o cambio de material será de acuerdo a las políticas de garantías y estará sujeto a la existencia de refacciones.</li>';
echo '</ul>';
echo '</div><div>';
}

if(!isset($_GET['Print'])){
include('includes/footer.php');
}
?>