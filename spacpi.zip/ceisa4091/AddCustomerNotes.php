<?php


include('includes/session.php');
$Title = _('Customer Notes');
include('includes/header.php');
include('includes/SQL_CommonFunctions.inc');

if(isset($_POST['Branch']) and $_POST['Branch']!='' ){
$_SESSION['RecogBranch']=$_POST['Branch'];
}
echo '<form method="post" action="', $RootPath, '/AddCustomerNotes.php?Id='.$_SESSION['VisitLast'].'&DebtorNo='.$_SESSION['VisitDebtorno'].'">';

if($_SESSION['VisitaActiva']==1){

	echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
		
		if(isset($_POST['Cancelar']) or isset($_POST['Finalizar']) ){
		if(isset($_POST['Cancelar'])){
$sql="DELETE FROM custnotes WHERE noteid='".$_SESSION['VisitLast']."'	";	
}
	if(isset($_POST['Finalizar'])){
$sql="UPDATE custnotes SET finaldate='".date('Y-m-d H:i:s')."',note='".$_POST['Note']."',href='".$_POST['Href']."' WHERE noteid='".$_SESSION['VisitLast']."'	";	
}
$result=DB_query($sql);
if(isset($_POST['Finalizar'])){
$sqlzero="SELECT * FROM custnotes WHERE debtorno='".$_SESSION['VisitDebtorno']."' AND priority LIKE 'Visita' and userid='".$_SESSION['UserID']."' ORDER BY noteid ASC";
if($_SESSION['UserID']=='JTAG'){
$sqlzero="SELECT * FROM custnotes WHERE debtorno='".$_SESSION['VisitDebtorno']."' AND priority LIKE 'Visita' and userid='".$_SESSION['UserID']."' and date>='2019-10-01' ORDER BY noteid ASC";
}
$resultzero=DB_query($sqlzero);
$rowzero=DB_fetch_array($resultzero);
$sqlone="SELECT * FROM debtorsmaster WHERE debtorno='".$_SESSION['VisitDebtorno']."'";
$resultone=DB_query($sqlone);
$rowone=DB_fetch_array($resultone);
$sqltwo="SELECT * FROM custnotes WHERE noteid='".$_SESSION['VisitLast']."'";
$resulttwo=DB_query($sqltwo);
$rowtwo=DB_fetch_array($resulttwo);
$last=strtotime($rowtwo['finaldate'])-strtotime($rowtwo['date']);
$quince=strtotime(date('Y-m-d'));
$quince=$quince-1296000;
$antiguedad=date('Y-m-d',$quince);
$sqlthree="SELECT * FROM custnotes WHERE branch='".$rowtwo['branch']."' AND priority LIKE 'Visita' AND date>='".$antiguedad."' and valida=1 ORDER BY noteid DESC";
$resultthree=DB_query($sqlthree);
$rowthree=DB_fetch_array($resultthree);
$noventa=strtotime(date('Y-m-d'));
$antiguedad=strtotime($rowzero['date']);
$sqlsalesman="SELECT salesman.salesmanname FROM custbranch LEFT JOIN salesman ON salesman.salesmancode=custbranch.salesman WHERE branchcode='".$rowtwo['branch']."'";
$resultsalesman=DB_query($sqlsalesman);
$rowsalesman=DB_fetch_array($resultsalesman);

$path='companies/ceisa4091/part_pics/exhibitors/';
$count=0;
$fecha_actual = date("Y-m-d");
$fechaDif=date("Y-m-d",strtotime($fecha_actual."- 90 days")); 


	
$files = scandir($path,1);
$files = array_diff(scandir($path), array('.', '..'));
    
    foreach($files as $file)
    {
        if (strpos($file,$rowtwo['branch'].'0')!==false)
        {
        $save0=$path.$file;
        $save0time=date("Y-m-d", filectime($save0));
            if($fechaDif>$save0time)
		    {
                $count++;
            
		    }
        }
        if (strpos($file,$rowtwo['branch'].'1')!==false)
        {
        $save1=$path.$file;
        $save1time=date("Y-m-d", filectime($save1));
            if($fechaDif>$save1time)
		    {
                $count++;
            
		    }
            
        }
        if (strpos($file,$rowtwo['branch'].'2')!==false)
        {
        $save2=$path.$file;
        $save2time=date("Y-m-d", filectime($save2));
            if($fechaDif>$save2time)
		    {
             $count++;
            
		    } 
        }
    
    
    }
if(($noventa-$antiguedad)>=7776000){
$hoy=strtotime(date('Y-m-d'));
		$hoy=$hoy-7776000;
		$fechaa=date('Y-m-d',$hoy);
		$sqlfour="SELECT SUM(

				(debtortrans.ovamount + debtortrans.ovdiscount)) AS facturado


			FROM debtortrans

			WHERE debtortrans.trandate >= '".$fechaa."' AND debtortrans.debtorno LIKE '".$_SESSION['VisitDebtorno']."' and (debtortrans.type='10' or debtortrans.type='11') GROUP BY debtortrans.debtorno";
		
$resultfour=DB_query($sqlfour);
$rowfour=DB_fetch_array($resultfour);

if(date('m')>=1){
$from=(date('Y')-1).'-10-01';
$to=(date('Y')-1).'-12-31';
}
if(date('m')>=4){
$from=date('Y').'-01-01';
$to=date('Y').'-03-31';
}
if(date('m')>=7){
$from=date('Y').'-04-01';
$to=date('Y').'-06-31';
}
if(date('m')>=10){
$from=date('Y').'-07-01';
$to=date('Y').'-09-31';
}




		$sqltri="SELECT SUM(

				(debtortrans.ovamount + debtortrans.ovdiscount)) AS facturado
			FROM debtortrans
			WHERE debtortrans.trandate >= '".$from."' AND debtortrans.trandate <= '".$to."' AND debtortrans.debtorno LIKE '".$_SESSION['VisitDebtorno']."' and (debtortrans.type='10' or debtortrans.type='11') GROUP BY debtortrans.debtorno";
		
$resulttri=DB_query($sqltri);
$rowtri=DB_fetch_array($resulttri);

if(($rowone['typeid']=='2' or $rowone['typeid']=='4' or $rowone['typeid']=='14') AND $last>=900 AND !isset($rowthree[0]) AND ($rowfour['facturado']>=5000 OR $rowtri['facturado']>=5000) AND $rowsalesman[0]==$_SESSION['UserID']  and $count==0 ){
$sql="UPDATE custnotes SET valida=1  WHERE noteid='".$_SESSION['VisitLast']."'	";	
$update=DB_query($sql);
}
}
if(($noventa-$antiguedad)<7776000){
if(($rowone['typeid']=='2' or $rowone['typeid']=='4' or $rowone['typeid']=='14') AND $last>=900 AND !isset($rowthree[0]) AND $rowsalesman[0]==$_SESSION['UserID'] and $count==0){
$sql="UPDATE custnotes SET valida=1  WHERE noteid='".$_SESSION['VisitLast']."'	";	
$update=DB_query($sql);
}
}
}
	unset($_SESSION['VisitaActiva']);
	unset($_SESSION['VisitLat']);
	unset($_SESSION['VisitLong']);
	unset($_SESSION['VisitLast']);
	unset($_SESSION['VisitStart']);
	unset($_SESSION['VisitDebtorno']);
	if(isset($_POST['Cancelar'])){	
	echo '<script>
window.location.href = "AddCustomerNotes.php?DebtorNo='.$_GET['DebtorNo'].'"
</script>';
	}
		}
	if($_SESSION['VisitaActiva']==1){	
	prnMsg('Visita aún en proceso, terminará automáticamente al salir de la sucursal','success');
$sql="SELECT *,custcontacts.contactname as contacto FROM custnotes INNER JOIN custcontacts ON custcontacts.contid=custnotes.contact INNER JOIN custbranch on custbranch.branchcode=custnotes.branch WHERE noteid='".$_SESSION['VisitLast']."'";		
$result=DB_query($sql);
$rowmean=DB_fetch_array($result);
		echo '<table class="selection">';

echo '<tr class="striped_row">
			<td>Sucursal:</td><td>'.$rowmean['branch'].' - '.$rowmean['brname'].' - '.$rowmean['braddress1'].' </td><tr>';
echo '<tr class="striped_row">
			<td>Contacto:</td><td>'.$rowmean['contacto'].' - '.$rowmean['role'].'</td><tr>';
echo '<tr class="striped_row">
			<td>Resultado:</td><td><textarea name="Note"  autofocus="autofocus" rows="3" cols="80">' .$rowmean['note'] . '</textarea></td><tr>';
			echo '<tr class="striped_row">
			<td>Observaciones:</td><td><input type="text" name="Href" value="'.$rowmean['href'].'" size="35" maxlength="100" /></td><tr></table>';
			
	
	
		echo '<button type="submit" name="Cancelar" onclick="return confirm(\'Está por CANCELAR la visita, esto es irreversible ¿Desea continuar? \');" style="background-color:lightcoral" >Cancelar Visita</button><button type="submit" name="Finalizar" onclick="return confirm(\'¿Desea FINALIZAR esta visita? \');" style="background-color:limegreen" >Terminar Visita</button></br>';
		echo '</form>';
		include('includes/footer.php');
		exit;
		}
}
echo '</form>';
if (isset($_GET['Id'])){
	$Id = (int)$_GET['Id'];
} else if (isset($_POST['Id'])){
	$Id = (int)$_POST['Id'];
}
if (isset($_POST['DebtorNo'])){
	$DebtorNo = $_POST['DebtorNo'];
} elseif (isset($_GET['DebtorNo'])){
	$DebtorNo = $_GET['DebtorNo'];
}

$sql="SELECT * FROM debtorsmaster where debtorno='".$DebtorNo."'";
$resultif=DB_query($sql);
$rowif=DB_fetch_array($resultif);

if($rowif['typeid']=='19'){
prnMsg('Este prospecto de cliente aún está pendiente por autorizarse, aún se requiere de autorización para poder generar visitas válidas a sus sucursales
y comisionar sus pedidos','warn');
/*
echo '<a href="' . $RootPath . '/SelectCustomer.php?DebtorNo=' . $DebtorNo . '">' . _('Back to Select Customer') . '</a>
	<br />';
include('includes/footer.php');
exit;
*/
}



echo '<a href="' . $RootPath . '/SelectCustomer.php?DebtorNo=' . $DebtorNo . '">' . _('Back to Select Customer') . '</a>
	<br />';

if ( isset($_POST['Locate']) and $_POST['Branch']!=''  ) {
$sql="SELECT latitud, longitud FROM custbranch WHERE branchcode='".$_POST['Branch']."'";
$result=DB_query($sql);
$myrow=DB_fetch_array($result);
if ($myrow['latitud']!='' and $myrow['longitud']!='' and $myrow['latitud']!=0 and $myrow['longitud']!=0 and $_SESSION['UserID']!='flopezv') {
		prnMsg('Esa sucursal ya tiene una ubicación determinada, si requiere actualizarla comuníquese con su superior','error');
}
elseif ((($myrow['latitud']==0 or $myrow['latitud']=='') or ( $_SESSION['UserID']=='flopezv'))  and $_SESSION['RTLong']!='' and $_SESSION['RTLat']!='') {
	$sql="UPDATE custbranch SET latitud='".$_SESSION['RTLat']."', longitud='".$_SESSION['RTLong']."' WHERE branchcode='".$_POST['Branch']."'";
	$result=DB_query($sql);
	prnMsg('Se ha asignado la ubicación de esa sucursal correctamente','success');
}
elseif ($myrow['latitud']=='' and $myrow['longitud']=='' and $_SESSION['RTLong']=='' and $_SESSION['RTLat']=='') {
	prnMsg('Necesita activar la ubicación manualmente ya que no ha aceptado el permiso','error');
}
}

if ( isset($_POST['Locate']) and $_POST['Branch']==''  ) {
	prnMsg('No seleccionó una sucursal','error');
}

if ( isset($_POST['enter']) ) {


$InputError = 0;
$_POST['NoteDate']=date("Y-m-d H:i:s");

$sqlfirst="SELECT clientsince FROM debtorsmaster WHERE debtorno='".$_GET['DebtorNo']."'";
$resultfirst=DB_query($sqlfirst);
$rowfirst=DB_fetch_array($resultfirst);

if(strtotime($rowfirst[0])==strtotime(date('Y-m-d')) and $_POST['Priority']=='Visita'){
$_POST['NoteDate']=Date('Y-m-d H:i:s',Mktime(Date('H'),Date('i')-15,Date('s'),Date('m'),Date('d'),Date('Y')));
}

$_POST['Long']=$_SESSION['RTLong'];
$_POST['Lat']=$_SESSION['RTLat'];


if(($_POST['Lat']=='' or $_POST['Long']=='') and $_POST['Priority']=='Visita' ){
		$InputError = 1;
		prnMsg('Es necesario que active el permiso de ubicación manualmente desde configuración debido a que lo denegó','error');
}


	if (mb_strlen($_POST['Href']) >100) {
		$InputError = 1;
		prnMsg( _('The contact\'s Observations  must be one hundred characters or less long'), 'error');
	} elseif (mb_strlen($_POST['Note']) >400) {
		$InputError = 1;
		prnMsg( _('The contact\'s notes must be two hundred characters or less long'), 'error');
	} 
	if ($_POST['Contact']=='') {
		$InputError = 1;
		prnMsg( 'Debe seleccionar un contacto', 'error');
	} 
	if ($_POST['Branch']==''  ) {
	$InputError = 1;
	prnMsg('No seleccionó una sucursal','error');
}
	$sql="SELECT latitud, longitud FROM custbranch WHERE branchcode='".$_POST['Branch']."'";
$result=DB_query($sql);
$myrow=DB_fetch_array($result);
if(($myrow['latitud']=='' or $myrow['longitud']=='' or $myrow['latitud']==0 or $myrow['longitud']==0) and $_POST['Priority']=='Visita' and !isset($Id)){
$InputError = 1;
	prnMsg('La sucursal aún no ha sido ubicada, asignele ubicación primero','error');
}
$difLAT=ABS($myrow['latitud']-$_SESSION['RTLat']);
$difLONG=ABS($myrow['longitud']-$_SESSION['RTLong']);

if(($difLAT>0.0005 or $difLONG>0.0005) and $_POST['Priority']=='Visita' and $myrow['latitud']!=0 and $myrow['longitud']!='' and !isset($Id)){
$InputError = 1;
	prnMsg('No se encuentra en la ubicación correcta para esta sucursal, debe encontrarse dentro de ella','error');
}


	if (isset($Id) and $InputError !=1) {


		$sql = "UPDATE custnotes SET note='" . $_POST['Note'] . "',
										href='" . $_POST['Href'] . "',
									branch='" . $_POST['Branch'] . "',
									contact='" . $_POST['Contact'] . "',
									priority='" . $_POST['Priority'] . "'
				WHERE debtorno ='".$DebtorNo."'
				AND noteid='".$Id."'";
		$msg = _('Customer Notes') . ' ' . $DebtorNo  . ' ' . _('has been updated');
	} elseif ($InputError !=1) {
if($_POST['Priority']=='Visita' ){	
	$_SESSION['VisitaActiva']=1;
	$_SESSION['VisitLat']=$myrow['latitud'];
	$_SESSION['VisitLong']=$myrow['longitud'];
	

	}
	
	if($_POST['Priority']=='Visita' OR $_POST['Priority']=='Llamada'){
	$SQLupdate="SELECT salesman,(SELECT salesmancode FROM salesman WHERE salesmanname='".$_SESSION['UserID']."') from custbranch where branchcode='".$_POST['Branch']."'";
	$updateresult=DB_query($SQLupdate);
	$updaterow=DB_fetch_array($updateresult);
	if($updaterow[0]=='CEI' and $updaterow[1]!='' ){
$SQLreal="UPDATE custbranch SET salesman='".$updaterow[1]."' WHERE branchcode='".$_POST['Branch']."'";
$realupdate=DB_query($SQLreal);	
	}
	}

		$sql = "INSERT INTO custnotes (debtorno,
										href,
										note,
										date,
										userid,
										branch,
										contact,
										priority,
										latitud,
										longitud)
				VALUES ('" . $DebtorNo. "',
						'" . $_POST['Href'] . "',
						'" . $_POST['Note'] . "',
						'" . $_POST['NoteDate'] . "',
						'" . $_SESSION['UserID'] . "',
						'" . $_POST['Branch'] . "',
						'" . $_POST['Contact'] . "',
						'" . $_POST['Priority'] . "',
						'" . $_POST['Lat'] . "',
						'" . $_POST['Long'] . "')";
		$msg = _('The contact notes record has been added');
	}

	if ($InputError !=1) {
		$result = DB_query($sql);
				//echo '<br />' . $sql;

		echo '<br />';
		prnMsg($msg, 'success');
	if($_POST['Priority']=='Visita')	{
	$sql="SELECT noteid,debtorno FROM custnotes WHERE userid='".$_SESSION['UserID']."' ORDER BY noteid DESC LIMIT 1";
		$result=DB_query($sql);
		$todelete=DB_fetch_array($result);
		$_SESSION['VisitLast']=$todelete[0];
		$_SESSION['VisitDebtorno']=$todelete['debtorno'];
		$_SESSION['VisitStart']=strtotime($_POST['NoteDate']);
		echo '<script>
window.location.href = "AddCustomerNotes.php?DebtorNo='.$_GET['DebtorNo'].'"
</script>';
exit;
}

		unset($Id);
		unset($_POST['Note']);
		unset($_POST['Noteid']);
		unset($_POST['Branch']);
		unset($_POST['Contact']);
		unset($_POST['Href']);
		unset($_POST['Priority']);
		unset($_POST['NoteDate']);
		
	}
} elseif (isset($_GET['delete'])) {
//the link to delete a selected record was clicked instead of the submit button

// PREVENT DELETES IF DEPENDENT RECORDS IN 'SalesOrders'

	$sql="DELETE FROM custnotes
			WHERE noteid='".$Id."'
			AND debtorno='".$DebtorNo."'";
	$result = DB_query($sql);

	echo '<br />';
	prnMsg( _('The contact note record has been deleted'), 'success');
	unset($Id);
	unset($_GET['delete']);
}

if (!isset($Id)) {
	$SQLname="SELECT * FROM debtorsmaster
				WHERE debtorno='".$DebtorNo."'";
	$Result = DB_query($SQLname);
	$row = DB_fetch_array($Result);
	echo '<p class="page_title_text"><img src="'.$RootPath.'/css/'.$Theme.'/images/maintenance.png" title="' . _('Search') . '" alt="" />' . _('Notes for Customer').': <b>' .$row['name'] . '</b></p>
		<br />';

	$sql = "SELECT custnotes.noteid,
					custnotes.debtorno,
					custnotes.href,
					custnotes.note,
					custnotes.date,
					custnotes.userid,
					custnotes.branch,
					custnotes.priority,
					custcontacts.contactname,
					custcontacts.role,
					custnotes.latitud,
					custnotes.longitud,
					custnotes.finaldate,
					custnotes.valida
				FROM custnotes LEFT JOIN custcontacts ON custcontacts.contid=custnotes.contact
				WHERE custnotes.debtorno='".$DebtorNo."'
				ORDER BY date DESC LIMIT 5";
	$result = DB_query($sql);

	echo '<table class="selection" style="width:85%;">
		<tr>
			<th> Fecha </th>
			<th> Duración </th>
			<th>Agente</th>
			<th>Sucursal</th>
			<th>Contacto</th>
			<th>Resultado</th>
			<th>Observaciones</th>
			<th>Tipo</th>
			<th>Ubicación</th>
			<th>Válida</th>
			<th>Explicación</th>
			</tr>';
			
	while ($myrow = DB_fetch_array($result)) {
		$ciclo=0;
	if($myrow['finaldate']!=''){
	$time=strtotime($myrow['finaldate'])-strtotime($myrow['date']);
$minutos=intval($time/60);
$segundos=$time-$minutos*60;
}
else{
$minutos=0;
$segundos=0;
}
	$ubic='Ubicar en el mapa';
if($myrow['latitud']=='' OR $myrow['longitud']==''){
$ubic='';
}
$validez='No';
$color='lightcoral';
if($myrow['valida']==1){
$validez='Sí';
$color='limegreen';

}
$tosam=date("Y-m-d",strtotime($myrow['date']."- 90 days"));
$date=date("Y-m-d",strtotime($myrow['date']));
$hoy=strtotime($myrow['date']);
if(date('m',$hoy)>=1){
	$from=(date('Y',$hoy)-1).'-10-01';
	$to=(date('Y',$hoy)-1).'-12-31';
	}
	if(date('m',$hoy)>=4){
	$from=date('Y',$hoy).'-01-01';
	$to=date('Y',$hoy).'-03-31';
	}
	if(date('m',$hoy)>=7){
	$from=date('Y',$hoy).'-04-01';
	$to=date('Y',$hoy).'-06-31';
	}
	if(date('m',$hoy)>=10){
	$from=date('Y',$hoy).'-07-01';
	$to=date('Y',$hoy).'-09-31';
	}

$sqltri="SELECT SUM(

	(debtortrans.ovamount + debtortrans.ovdiscount)) AS facturado
FROM debtortrans
WHERE debtortrans.trandate >= '".$from."' AND debtortrans.trandate <= '".$to."' AND debtortrans.debtorno LIKE '".$myrow['debtorno']."' and (debtortrans.type='10' or debtortrans.type='11') GROUP BY debtortrans.debtorno";

$resulttri=DB_query($sqltri);
$rowtri=DB_fetch_array($resulttri);
$sqlfour="SELECT SUM(

	(debtortrans.ovamount + debtortrans.ovdiscount)) AS facturado


FROM debtortrans

WHERE debtortrans.trandate >= '".$tosam."' AND debtortrans.trandate <= '".$myrow['date']."' AND debtortrans.debtorno LIKE '".$myrow['debtorno']."' and (debtortrans.type='10' or debtortrans.type='11') GROUP BY debtortrans.debtorno";

$resultfour=DB_query($sqlfour);
$rowfour=DB_fetch_array($resultfour);
if($validez=="No" and $myrow['priority']=="Visita"){
$explicacion.= CheckPhoto($myrow['branch'],$date);
$explicacion.= CheckTime($minutos);
$explicacion.= CheckVisits($myrow['date'],$myrow['branch'],$myrow['userid'],$myrow['debtorno']);

/////parche por omisión de sorea
$sqlzero="SELECT * FROM custnotes WHERE debtorno='".$myrow['debtorno']."' AND priority LIKE 'Visita' and userid='".$myrow['userid']."' ORDER BY noteid ASC";
$resultzero=DB_query($sqlzero);
$rowzero=DB_fetch_array($resultzero);
$antiguedad=strtotime($rowzero['date']);
$noventa=strtotime($myrow['date']);
$quince=$noventa-1296000;
/////termina parche
/////parche por omisión de sorea
if(($noventa-$antiguedad)>=7776000){
	/////termina parche
	
$explicacion.= CheckSales($rowtri['facturado'],$rowfour['facturado']);
/////parche por omisión de sorea
}
/////termina parche
$explicacion.= CheckSucursal($myrow['branch'],$myrow['userid'],$myrow['debtorno']);
}

//esta funcion de checkphoto se encuentra programada en la parte de abajo del script 

		printf('<tr class="striped_row">
				<td>%s </td>
				<td style="text-align:center">%s mins %s segs</td>
				<td>%s</td>
				<td>%s</td>
				<td>%s %s</td>
				<td>%s</td>
				<td>%s</td>
				<td>%s</td>
				<td><a href="https://www.google.com/maps/search/%s,%s/@%s,%s,17z" target="_blank">%s</a></td>
				<td style="background-color:%s;text-align:center">%s</td>
				<td>%s</td>
				<td><a href="%sId=%s&DebtorNo=%s">' .  _('Edit').' </a></td>
				</tr>',
				$myrow['date'],
				$minutos,
				$segundos,
				$myrow['userid'],
				$myrow['branch'],
				$myrow['role'],
				$myrow['contactname'],
				$myrow['note'],
				$myrow['href'],
				$myrow['priority'],
				$myrow['latitud'],
				$myrow['longitud'],
				$myrow['latitud'],
				$myrow['longitud'],
				$ubic,
				$color,
				$validez,
				$explicacion,
				htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . '?',
				$myrow['noteid'],
				$myrow['debtorno']);

	$explicacion="";
	}
	//END WHILE LIST LOOP
	//	<td><a href="%sId=%s&DebtorNo=%s&delete=1" onclick="return confirm(\'' . _('Are you sure you wish to delete this customer note?') . '\');">' .  _('Delete'). '</td>
				//	htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . '?',
			//	$myrow['noteid'],
			//	$myrow['debtorno']);
			//estructura para borrar notas boton y ultimas 3 lineas
	echo '</table>';
}
if (isset($Id)) {
	echo '<div class="centre">
			<a href="'.htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . '?DebtorNo='.$DebtorNo.'">' . _('Review all notes for this Customer') . '</a>
		</div>';
}
echo '<br />';

if (!isset($_GET['delete'])) {

	echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . '?DebtorNo=' . $DebtorNo . '" method="post">';

	echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
echo '<input type="hidden" name="Lat" id="Lat" value="" />';
echo '<input type="hidden" name="Long" id="Long" value="" /> ';
		

	

	if (isset($Id)) {
		//editing an existing

		$sql = "SELECT noteid,
						debtorno,
						href,
						note,
						branch,
						contact,
						priority,
						userid,
						latitud,
						longitud,
						date
					FROM custnotes
					WHERE noteid='".$Id."'
						AND debtorno='".$DebtorNo."'";

		$result = DB_query($sql);

		$myrow = DB_fetch_array($result);

		$_POST['Noteid'] = $myrow['noteid'];
		$_POST['Note']	= $myrow['note'];
		$_POST['Href']  = $myrow['href'];
		$_POST['Branch']  = $myrow['branch'];
		$_POST['Contact']  = $myrow['contact'];
		$_POST['Priority']  = $myrow['priority'];
		$_POST['debtorno']  = $myrow['debtorno'];
		echo '<input type="hidden" name="Id" value="'. $Id .'" />';
		echo '<input type="hidden" name="Con_ID" value="' . $_POST['Noteid'] . '" />';
		echo '<input type="hidden" name="DebtorNo" value="' . $_POST['debtorno'] . '" />';
		echo '<table class="selection">
			<tr>
				<td>' .  _('Note ID').':</td>
				<td>' . $_POST['Noteid'] . '</td>
				</tr>
				<tr>
				<td >' .  _('Agente').':</td><td style="background-color:lightblue">' . $myrow['userid'] . '</td>
			</tr>';
	} else {
		echo '<table class="selection">';
	}
	$sql = "SELECT custbranch.branchcode,custbranch.brname,custbranch.braddress1, areas.areadescription, salesman.salesmanname,custbranch.latitud,custbranch.longitud FROM (custbranch LEFT JOIN areas ON custbranch.area LIKE areas.areacode) LEFT JOIN salesman on salesman.salesmancode=custbranch.salesman WHERE debtorno='".$DebtorNo."'";
$result = DB_query($sql);
//$myrow = DB_fetch_array($result);

echo '<tr>
			<td>Sucursal:</td><td colspan="4">';
		if (isset($Id)) {
			$sqlo = "SELECT custbranch.branchcode,custbranch.brname,custbranch.braddress1,areas.areadescription,custbranch.latitud, custbranch.longitud FROM ((custbranch INNER JOIN custnotes ON custbranch.branchcode=custnotes.branch) INNER JOIN areas ON areas.areacode LIKE custbranch.area)  WHERE custnotes.noteid='".$Id."'"  ;
$resulto = DB_query($sqlo); 
$myrowu = DB_fetch_array($resulto);
		echo '<input type="hidden" name="Branch" value="' . $myrowu['branchcode'].'" /> '.$myrowu['branchcode']." | ".$myrowu['brname'] ." | ". $myrowu['braddress1'] . " | ". $myrowu['areadescription'] . '</td>';
		echo '</td></tr>';
	}
				else{
						echo '<select name="Branch" onchange="this.form.submit()" ><option value="" style="text-align:center">- Seleccione la sucursal correspondiente -</option>';
						$_SESSION['RecogBranch']='';
		while ($myrow = DB_fetch_array($result))
{



		if(isset($_POST['Branch']) and $_POST['Branch']==$myrow['branchcode'] OR (isset($_SESSION['BranchCode']) and !isset($_POST['Branch']) and $_SESSION['BranchCode']==$myrow['branchcode'] ) ){
		echo '<option selected="selected" value="'.$myrow['branchcode'] . '">'.$myrow['branchcode']." | ".$myrow['brname'] ." | ". $myrow['braddress1'] ." | ". $myrow['areadescription'] . '</option>';
		$elegida=$myrow['branchcode'];
		$latelegida=$myrow['latitud'];
		$longelegida=$myrow['longitud'];
		$vendedorelegida=$myrow['salesmanname'];
$_SESSION['RecogBranch']=$myrow['branchcode'];
$_SESSION['RecogLat']=$myrow['latitud'];
$_SESSION['RecogLong']=$myrow['longitud'];
$path    = 'companies/ceisa4091/part_pics/exhibitors/';
$files = scandir($path,1);
$files = array_diff(scandir($path), array('.', '..'));
rsort($files);
foreach($files as $file){
if (strpos($file,$myrow['branchcode'].'0')!==false){
$save0=$path.$file;
$save0time=date('Y-m-d',filemtime ($save0));
}
if (strpos($file,$myrow['branchcode'].'1')!==false){
$save1=$path.$file;
$save1time=date('Y-m-d',filemtime($save1));
}
if (strpos($file,$myrow['branchcode'].'2')!==false){
$save2=$path.$file;
$save2time=date('Y-m-d',filemtime($save2));
}
}

		}
		else{
				echo '<option value="'.$myrow['branchcode'] . '">'.$myrow['branchcode']." | ".$myrow['brname'] ." | ". $myrow['braddress1'] ." | ". $myrow['areadescription'] . '</option>';
		}
		}
		echo '</select>';
		
		
		if($latelegida!='' and $longelegida!='' and $latelegida!='0' and $longelegida!='0' ){		
		echo '<span style="background-color:limegreen"><a href="https://www.google.com/maps/search/'.$latelegida.','.$longelegida.'/@'.$latelegida.','.$longelegida.',17z" target="_blank"> Ver en Mapa </a></span>';
		}
		else{
		echo '<span style="background-color:orange"> Sucursal pendiente de ubicar </span>';
		}
	
				if($vendedorelegida==$_SESSION['UserID']){		
		echo '<span style="background-color:limegreen"> Asignada a usted </span>';
		}
		elseif($vendedorelegida=='CEISA'){
		echo '<span style="background-color:lightblue"> Asignada a '.$vendedorelegida.'</span>';
		}
		else{
		echo '<span style="background-color:lightcoral"> Asignada a '.$vendedorelegida.'</span>';
		}
		/*
				echo '<span> <a href="'.$save0.'?t='.time().'" target="_blank"><img id="sucursal" style="margin:10px 30px;" src="'.$save0.'?t='.time().'" width="40px" height="50px" alt="Aún no se tiene fotografía de la entrada"></a> </span>';
		echo '<span> <a href="'.$save1.'?t='.time().'" target="_blank"><img id="sucursal" style="margin:10px 30px;" src="'.$save1.'?t='.time().'" width="40px" height="50px" alt="Aún no se tiene fotografía del exhibidor"></a> </span>';
				echo '<span> <a href="'.$save2.'?t='.time().'" target="_blank"><img id="sucursal" style="margin:10px 30px;" src="'.$save2.'?t='.time().'" width="40px" height="50px" alt="Aún no se tiene fotografía del mostrador"></a> </span>';
		*/
				echo '<span> Entrada: '.$save0time.' Exhibidor: '.$save1time.' Mostrador: '.$save2time.' </span>';
		echo '</td></tr>';
$difo=strtotime(date('Y-m-d'))-strtotime($save0time);
$dif1=strtotime(date('Y-m-d'))-strtotime($save1time);
$dif2=strtotime(date('Y-m-d'))-strtotime($save2time);

$talk='';
if(($save0time=='' OR $difo>7776000) AND ($save1time=='' OR $dif1>7776000) AND ($save2time=='' OR $dif2>7776000) ){
$talk='<span style="background-color:yellow">¡ Es NECESARIO renovar fotografías de la sucursal para validar visitas !</span>';
}

}

		
		
		$sql = "SELECT custcontacts.contid,custcontacts.contactname, custcontacts.role FROM custcontacts WHERE debtorno='".$DebtorNo."' and activo='SI'";
$result = DB_query($sql);
	
echo '<td>Contact:</td><td><select name="Contact" >';
if (isset($Id)) {
			$sqlo = "SELECT custnotes.contact,custcontacts.contactname, custcontacts.role FROM custnotes LEFT JOIN custcontacts ON custnotes.contact=custcontacts.contid WHERE custnotes.noteid='".$Id."'";
$resulto = DB_query($sqlo); 
$myrowu = DB_fetch_array($resulto);
		echo '<option selected="selected" value="' . $_POST['Contact'].'" >'.$myrowu['role']." | ".$myrowu['contactname'].'</option>';
		while ($myrow = DB_fetch_array($result))
{
		echo '<option value="'.$myrow['contid'] . '">'.$myrowu['role']." | ".$myrow['contactname'].'</option>';
		}
	}
				else{
				echo '<option value="">- Seleccione la persona con quien contactó -</option>';
		while ($myrow = DB_fetch_array($result))
{
if(isset($_POST['Contact']) and $_POST['Contact']==$myrow['contid']){
		echo '<option value="'.$myrow['contid'] . '" selected="selected">'.$myrow['role']." | ".$myrow['contactname'] .'</option>';
}
else{
		echo '<option value="'.$myrow['contid'] . '">'.$myrow['role']." | ".$myrow['contactname'] .'</option>';
		}
		}
}		
echo '</select></td>';
echo '<td><a onclick="myFunction()" style="cursor:pointer;"} >'.$talk.' ' .  _('Actualizar CONTACTOS o FOTO de sucursal').' <a></td></tr>';
	echo '<tr>
			<td><b>Resultado:</b></td>';
	if (isset($_POST['Note']) and !isset($_POST['Locate']) ) {
		echo '<td colspan="5"><textarea name="Note"  autofocus="autofocus" rows="3" cols="80">' .$_POST['Note'] . '</textarea></td>
			</tr>';
	} else {
		echo '<td colspan="5"><textarea name="Note" placeholder="Resultado o Cuerpo de la nota" autofocus="autofocus" rows="3" cols="80"></textarea></td>
			</tr>';
	}
	echo '<tr>
			<td>Observaciones:</td>';
	if (isset($_POST['Href'])) {
		echo '<td colspan="4"><input type="text" name="Href" value="'.$_POST['Href'].'" size="35" maxlength="100" /></td>
			</tr>';
	} else {
		echo '<td colspan="4"><input type="text" placeholder="Información adicional" name="Href" size="35" maxlength="100" /></td>
			</tr>';
	}
		echo '<tr>
			<td>Tipo:</td>
			<td><select name="Priority">';
	if (isset($_POST['Priority']) and isset($Id)) {
		echo '<option selected="selected" value="' . $_POST['Priority']. '" > ' . $_POST['Priority']. '</option>
</select></td>';
	} else {
		echo '<option  selected="selected" value="Visita">Visita</option>';
		echo '<option value="Llamada">Llamada Ventas</option>';
		echo '<option value="Embarque">Embarque</option>';
		echo '<option value="Cobranza">Cobranza</option>';
		echo '<option value="Otros">Otros</option></select></td>';

	}


echo '</tr>';

if (!isset($Id)) {
	echo '<tr>
			<td colspan="5">
			<div class="centre">
				<input type="submit" name="enter" style="background-color:lightblue"  value="Iniciar VISITA/ Introducir NOTA" /><input type="submit" disabled name="submitend" style="background-color:limegreen"  value="Terminar VISITA" /><input type="submit" name="Locate" style="background-color:orange" onclick="return confirm(\'Asegúrese de encontrarse DENTRO de la sucursal ¿Desea Continuar? \');"  value="Asignar Ubicación" />
			</div>
			</td>
		</tr>
		</table>
       
		</form>';
}

if (isset($Id)) {
	echo '<tr>
			<td colspan="5">
			<div class="centre">
				<input type="submit" name="enter" style="background-color:lightblue"  value="Guardar Cambios" />
			</div>
			</td>
		</tr>
		</table>
        </div>
		</form>';
}

} //end if record deleted no point displaying form to add record


include('includes/footer.php');
echo '<script>
function myFunction() {
  window.open("UpdateCustomerContacts.php?DebtorNo='.$DebtorNo.'","_blank","width=700,height=400,scrollbars=yes,top=200,left=1000,resizable=no");
}
</script>';

function CheckPhoto($branch,$fechaVisita)
{
	
	$path='companies/ceisa4091/part_pics/exhibitors/';
	$ResultPhoto="";
	$count=0;


	$fileNotFound=0;
	$files = scandir($path,1);
	$files = array_diff(scandir($path), array('.','..'));
      foreach($files as $file)
    {
        if (strpos($file,$branch.'0')!==false)
        {
        $save0=$path.$file;
        $save0time=date("Y-m-d", filemtime($save0));
		

			$diferencia=strtotime($fechaVisita)-strtotime($save0time);
			
            if($diferencia>7776000)
		    {
                $count++;
            
		    }
        }else{$fileNotFound++;}
        if (strpos($file,$branch.'1')!==false)
        {
        $save1=$path.$file;
		$save1time=date("Y-m-d", filemtime($save1));
		$diferencia=strtotime($fechaVisita)-strtotime($save1time);

            if($diferencia>7776000)
		    {
                $count++;
            
		    }
        }else{$fileNotFound++;}
        if (strpos($file,$branch.'2')!==false)
        {
        $save2=$path.$file;
        $save2time=date("Y-m-d", filemtime($save2));
		$diferencia=strtotime($fechaVisita)-strtotime($save2time);

            if($diferencia>7776000)
		    {
                $count++;
            
		    }
			
        }else{$fileNotFound++;}
    
	}
	if(($count!=null and $count!="" and $count!=0) or ($save0time=='' and $save1time==''  and $save2time==''))
	{
		$ResultPhoto.='| Sin Foto Vigente |</br> ';
	}
	

	return $ResultPhoto;
}
function CheckTime($minutos)
{
	if($minutos<=14)
	{
		$ResultTime='| No se cumplio el tiempo minimo |</br> ';
	}

	
	return $ResultTime;
}
function CheckVisits($date,$branch,$userid,$debtorno)
{	
	$v=0;
	$visita="";
		$date = date("Y-m-d",strtotime($date));
		$to=date("Y-m-d",strtotime($date."+ 15 days"));
		
		$rowzero=DB_fetch_array($resultzero);
		$sql="SELECT branch,date_format(date,'%Y-%m-%d') from custnotes where branch LIKE '%".$branch."%' and date_format(custnotes.date,'%Y-%m-%d') between '".$date."' and '".$to."' and valida= 1";
		$result= DB_query($sql);
		// $diferencia=strtotime(date($fechaVisita))-strtotime($save2time);
		// echo $sql;
		$i=0;
		while (DB_fetch_array($result)){
			$i++;
		}
		if($i>1)
		{
			$visita="| Realizo más de una visita en un lapso menor a 15 días |</br>";
		}
	
	
	return $visita;
}
function CheckSales($facturado,$facturado2)
{
echo $facturado.' '.$facturado2;
	if($facturado<5000 and $facturado2<5000)
	{
		$sales="| Ventas menores a 5000 pesos trimestrales |</br>";
	}
	return $sales;
}
function CheckSucursal($branch,$userid,$debtorno)
{
	$sqlsales="SELECT salesman.salesmanname as nombre1 FROM custbranch INNER JOIN salesman ON custbranch.salesman=salesman.salesmancode WHERE custbranch.branchcode='".$branch."'";
	$r=DB_query($sqlsales);
	while($row=DB_fetch_array($r)){
		$nombre1=$row['nombre1'];
	}
	
	if($nombre1 != $userid)
	{
		$Sucursal= "| Sucursal de Agente ".$nombre1."|</br>";
	}
	return $Sucursal;

}
?>			