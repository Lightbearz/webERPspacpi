<?php
 include('../includes/session.php');
 include('../includes/phplot/phplot.php');
class GraphRequeriments
{
    public function DataRequerimentsGraph($fechaInicio,$fechaFin,$tipoGrafica,$agrupacion)
    {
        $condiciones.=' where 1 ';
        if($fechaInicio!="")
        {
            $fechaInicio=date('Y-m-d',strtotime($fechaInicio));
             $condiciones.=" and date_format(stockrequest.despatchdate,'%Y-%m-%d')>='".$fechaInicio."'";

        }
        if($fechaFin!="")
        {
            $fechaFin=date('Y-m-d',strtotime($fechaFin));
            $condiciones.=" and date_format(stockrequest.despatchdate,'%Y-%m-%d')<='".$fechaFin."' ";
        }
           
           
            
            $sql="SET SQL_BIG_SELECTS=1";
            DB_query($sql);    
           if($agrupacion=="dia") {
            $condiciones.=" and  (purchorders.requisitionno!=null or stockrequest.departmentid=17) GROUP BY date_format(stockrequest.despatchdate,'%Y-%m-%d') order by despatchdate desc";
            $sql="SELECT a.Date as fecha, consulta.terminados as terminados, consulta.sin_terminar as sin_terminar, consulta.prom as prom 
            from (select curdate() - INTERVAL (a.a + (10 * b.a) + (100 * c.a) + (1000 * d.a) ) DAY as Date 
            from (select 0 as a union all select 1 union all select 2 union all select 3 union all select 4 union all select 5 union all select 
            6 union all select 7 union all select 8 union all select 9) as a cross join (select 0 as a union all select 1 union all select 2 
            union all select 3 union all select 4 union all select 5 union all select 6 union all select 7 union all select 8 union all select 9) 
            as b cross join (select 0 as a union all select 1 union all select 2 union all select 3 union all select 4 union all select 5 union all 
            select 6 union all select 7 union all select 8 union all select 9) as c cross join (select 0 as a union all select 1 union all select 2 
            union all select 3 union all select 4 union all select 5 union all select 6 union all select 7 union all select 8 union all select 9) as 
            d ) a left join ( SELECT date_format(stockrequest.despatchdate,'%Y-%m-%d') as fecha,COUNT(case when completed=1 or completed=-1 or 
            completed=-2 then 1 else null end) as terminados, count(case when completed=0 then 1 else null end)as sin_terminar, 
            avg(DATEDIFF((CASE WHEN stockrequestitems.completed=1 or stockrequestitems.completed=-2 then substr(stockrequestitems.userid3,-20) 
            WHEN stockrequestitems.completed=-1 then substr(stockrequestitems.userid1,-20) END),stockrequest.despatchdate)) as prom 
            from stockrequestitems INNER JOIN stockrequest on stockrequest.dispatchid=stockrequestitems.dispatchid 
            LEFT JOIN locstock ON locstock.stockid=stockrequestitems.stockid AND locstock.loccode=stockrequest.loccode 
            INNER JOIN stockmaster on stockmaster.stockid=stockrequestitems.stockid left join purchorders on 
            purchorders.requisitionno=stockrequest.dispatchid ".$condiciones." ) as consulta on consulta.fecha = a.Date 
             where a.Date between '".$fechaInicio."' and '".$fechaFin."' and DAYOFWEEK(a.Date) IN ('2','3','4','5','6') group by date_format(a.Date,'%y-%m-%d') ORDER BY a.Date ASC ";
             $SetYTitle="Numero de pedidos por dia";
            }else{
                $condiciones.=" and  (purchorders.requisitionno!=null or stockrequest.departmentid=17) GROUP BY date_format(stockrequest.despatchdate,'%Y-%m') order by despatchdate desc";

            $sql="SELECT date_format(a.Date,'%Y-%m') as fecha, sum(consulta.terminados) as terminados, sum(consulta.sin_terminar) as sin_terminar, avg(consulta.prom) as prom 
            from (select curdate() - INTERVAL (a.a + (10 * b.a) + (100 * c.a) + (1000 * d.a) ) DAY as Date 
            from (select 0 as a union all select 1 union all select 2 union all select 3 union all select 4 union all select 5 union all select 
            6 union all select 7 union all select 8 union all select 9) as a cross join (select 0 as a union all select 1 union all select 2 
            union all select 3 union all select 4 union all select 5 union all select 6 union all select 7 union all select 8 union all select 9) 
            as b cross join (select 0 as a union all select 1 union all select 2 union all select 3 union all select 4 union all select 5 union all 
            select 6 union all select 7 union all select 8 union all select 9) as c cross join (select 0 as a union all select 1 union all select 2 
            union all select 3 union all select 4 union all select 5 union all select 6 union all select 7 union all select 8 union all select 9) as 
            d ) a left join ( SELECT date_format(stockrequest.despatchdate,'%Y-%m-%d') as fecha,COUNT(case when completed=1 or completed=-1 or 
            completed=-2 then 1 else null end) as terminados, count(case when completed=0 then 1 else null end)as sin_terminar, 
            avg(DATEDIFF((CASE WHEN stockrequestitems.completed=1 or stockrequestitems.completed=-2 then substr(stockrequestitems.userid3,-20) 
            WHEN stockrequestitems.completed=-1 then substr(stockrequestitems.userid1,-20) END),stockrequest.despatchdate)) as prom 
            from stockrequestitems INNER JOIN stockrequest on stockrequest.dispatchid=stockrequestitems.dispatchid 
            LEFT JOIN locstock ON locstock.stockid=stockrequestitems.stockid AND locstock.loccode=stockrequest.loccode 
            INNER JOIN stockmaster on stockmaster.stockid=stockrequestitems.stockid left join purchorders on 
            purchorders.requisitionno=stockrequest.dispatchid ".$condiciones." ) as consulta on consulta.fecha = a.Date 
             where a.Date between '".$fechaInicio."' and '".$fechaFin."' and DAYOFWEEK(a.Date) IN ('2','3','4','5','6') group by date_format(a.Date,'%Y-%m') ORDER BY a.Date ASC ";
             $SetYTitle="Numero de pedidos por mes";
            }
            //    echo $sql;
            $NombreGrafica="Grafico de requerimientos de compras";
            $this->Graph($sql,$tipoGrafica,$NombreGrafica,$SetYTitle);
    }
        
    private function Graph($sql,$tipoGrafica,$NombreGrafica,$SetYTitle)
    {
        $titulo='Periodos';
        $result=DB_query($sql);
        $graph = new PHPlot(950,450);
        $GraphTitle=$NombreGrafica;
        $graph->SetTitle($GraphTitle);
        $graph->SetTitleColor('blue');
        $graph->SetOutputFile('companies/' .$_SESSION['DatabaseName'] .'/reports/countsgraph.png');
        $graph->SetXTitle(_($titulo));
        $graph->SetYTitle(_($SetYTitle));
        $graph->SetXTickPos('none');
        $graph->SetXTickLabelPos('none');
        $graph->SetXLabelAngle(90);
        $graph->SetBackgroundColor('white');
        $graph->SetTitleColor('blue');
        $graph->SetFileFormat('png');
        $graph->SetPlotType($tipoGrafica);
        $graph->SetIsInline('1');
        $graph->SetShading(5);
        $graph->SetDrawYGrid(TRUE);
        $graph->SetDataType('text-data');
        $graph->SetNumberFormat($DecimalPoint, $ThousandsSeparator);
        $graph->SetPrecisionY($_SESSION['CompanyRecord']['decimalplaces']);
        
        $GraphArray = array();
	    $i = 0;
	    while ($myrow = DB_fetch_array($result)){
           
           
	    	$GraphArray[$i] = array($myrow['fecha'],$myrow['terminados'],$myrow['sin_terminar'],$myrow['prom']);
           
            
            $i++;
	    }
        
            $graph->SetDataValues($GraphArray);
            $graph->SetDataColors(
                array('SlateBlue','orange','yellow'),  //Data Colors
                array('black')	//Border Colors
            );
	    //$graph->SetLegend(array(_('Actual'));
	    //if($_POST['fecha']!=''){
	    $graph->SetLegend(array('Terminados','Sin terminar','Promedio de tiempo'));
	    //}
    
    
	    $graph->SetYDataLabelPos('plotin');

	    //Draw it
	    $graph->DrawGraph();
	    echo '<table class="selection">
	    		<tr>
	    			<td><p><img src="companies/' .$_SESSION['DatabaseName'] .  '/reports/countsgraph.png?t='.time().'" alt="Sales Report Graph"></img></p></td>
	    		</tr>
	    	  </table>';
    }

}


?>