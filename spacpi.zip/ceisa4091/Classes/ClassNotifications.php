<?php
include('../includes/session.php');
class Notifications
{
    

    
    public function SendNotifications($user,$date,$message,$asunto)
    {
        $identifier=date('U');
        $sql = 'INSERT INTO notificaciones (Id,
                                            user,
                                            date,
                                            asunto,
                                            message) 
                                            VALUES ("'.$identifier.'",
                                            "'.$user.'",
                                            "'.$date.'",
                                            "'.$asunto.'",
                                            "'.$message.'")';
        DB_query($sql);
        $sql1="SELECT userid,realname from www_users where lastvisitdate>'".date('Y-m-d',mktime(0,0,0,date('m'),date('d')-15,date('Y')))."' and blocked=0";
        $result=DB_query($sql1);
        while($myrow=DB_fetch_array($result))
        {
            $fp =fopen('LogFiles/'.$myrow['userid'].'.txt','a');
			$fwrite = fwrite($fp,"\n");
			$fwrite = fwrite($fp,'|A| '.$identifier);
            $insert='INSERT INTO notificaciones_vistas(id_vista,
                                                        id_mensaje,
                                                        usuario,
                                                        visto)  
                                                        VALUES (null,
                                                        "'.$identifier.'",
                                                        "'.$myrow['userid'].'",
                                                        0)';
            DB_query($insert);
    }
          // $notificaciones[] =array(
        //     'Name'=>$myrow['realname'],
        //     'UserId'=>$myrow['userid'],
        //     'Date'=>$date,
        //     'Asunto'=>$asunto,
        //     'From'=>$user,
        //     'Message'=>$message
        // );

        // $Json= json_encode($notificaciones);
        // $fh = fopen('includes/_Notifications.json', 'w');
        // fwrite($fh, $Json);
        // fclose($fh);

    }
    public function ViewNotifications($fecha,$fechaFin)
    {
       
        echo '<table style="width:75%;"><th>Enviado por</th><th>Fecha</th><th>Asunto</th><th>Mensaje</th><th>Usuarios</th>';
        $sql1="SELECT Id,user,date,asunto,message from notificaciones order by notificaciones.date desc";
        $result1=DB_query($sql1);
        
        while($myrow1=DB_fetch_array($result1))
        {
            echo '<tr class="striped_row"><td>'.$myrow1['user'].'</td><td>'.$myrow1['date'].'</td><td>'.$myrow1['asunto'].'</td><td>'.$myrow1['message'].'</td>';
                echo '<td style="background-color:">';
            $idMensaje=$myrow1['Id'];
            $sql="SELECT id_mensaje,usuario, notificaciones.date as ndate, notificaciones.message as messagee,notificaciones.asunto 
            as asunto,notificaciones_vistas.visto as visto
            from notificaciones_vistas 
            INNER join notificaciones on notificaciones.id = notificaciones_vistas.id_mensaje
            where date_format(notificaciones.date,'%Y-%m-%d') between '".$fecha."' and '".$fechaFin."'";
            $result=DB_query($sql);
          while($myrow=DB_fetch_array($result))
            {
                if($idMensaje==$myrow['id_mensaje'])
                {
                     if($myrow['visto'] ==1)
                         {
                             echo ' <spam style="background-color:limegreen;"> '.$myrow['usuario'].' </spam> ';
                         }
                     else 
                         {
                             echo ' <spam style="background-color:lightcoral"> '.$myrow['usuario'].' </spam> ';
                         }
                }
            }    
            echo '</td>';
            
         }
        echo '</table>';
    }
    public function NotificationsIsOpen($usuario,$asunto)
    {
        

    }
    
}


?>