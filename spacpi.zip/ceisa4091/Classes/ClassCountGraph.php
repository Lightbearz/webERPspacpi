<?php
 include('../includes/session.php');
 include('../includes/phplot/phplot.php');
class ClassCountGraph
{
   
   
   public function GraficarPorDia($ubicacion,$tipoGrafica)
    {
        $sql = "SET SQL_BIG_SELECTS=1";
        DB_query($sql);
        $sql="SELECT a.Date as fecha,consulta.CountA as CountA,consulta.CountB as CountB,consulta.CountC as CountC from (select curdate() - INTERVAL (a.a + (10 * b.a) + (100 * c.a) + (1000 * d.a) ) DAY as Date from 
        (select 0 as a union all select 1 union all select 2 union all select 3 union all select 4 union all select 5 union all select 
        6 union all select 7 union all select 8 union all select 9) as a cross join (select 0 as a union all select 1 union all select 2 
        union all select 3 union all select 4 union all select 5 union all select 6 union all select 7 union all select 8 union all select 9)
        as b cross join (select 0 as a union all select 1 union all select 2 union all select 3 union all select 4 union all select 5 union
         all select 6 union all select 7 union all select 8 union all select 9) as c cross join (select 0 as a union all select 1 union all
          select 2 union all select 3 union all select 4 union all select 5 union all select 6 union all select 7 union all select 8 union 
          all select 9) as d ) a left join (SELECT date_format(fecha,'%Y-%m-%d') as fecha ,SUM(case when clasificacion='A' then 1 else null end ) 
          as CountA,SUM(case when clasificacion='B' then 1 else null end ) as CountB ,SUM(case when clasificacion='C' then 1 else null end ) as CountC 
          FROM stockcountsn where 1 ".$ubicacion."  and fecha between '".$_POST['FechaInicio']."' and '".$_POST['FechaFin']." 23:59:59' and estatus!=''  group by 
          date_format(fecha,'%y-%m-%d')) as consulta ON consulta.fecha=a.Date WHERE a.Date between '".$_POST['FechaInicio']."' and '".$_POST['FechaFin']." 23:59:59' and DAYOFWEEK
          (a.Date) IN ('2','3','4','5','6') ORDER BY a.Date ASC";
        
        $resultSQL=DB_query($sql);
        $titulo = "Dias de la semana";
        $NombreGrafica="Grafica por dia";
        if(DB_num_rows($resultSQL)!=0){$this->Graficar($resultSQL,$NombreGrafica,$titulo,$tipoGrafica);}
         else { prnMsg('No se encontraron datos para graficar','error');         }         
        
    }
    public function GraficarPorMes($ubicacion,$tipoGrafica)
    {
        $sql = "SET SQL_BIG_SELECTS=1";
        DB_query($sql);
        //   $sql="SELECT date_format(fecha,'%Y-%m') as fecha ,SUM(case when Lista!='' then 1 else null end ) as total from stockcountsn
        //   where 1 ".$ubicacion." and fecha between '".$_POST['FechaInicio']."' and '".$_POST['FechaFin']."'  group by date_format(fecha,'%m-%d') order by fecha asc";
        
            $sql="SELECT date_format(a.Date,'%y-%m') as fecha,SUM(consulta.CountA) as CountA,SUM(consulta.CountB) as CountB,SUM(consulta.CountC) as CountC from (select curdate() - INTERVAL (a.a + (10 * b.a) + (100 * c.a) + (1000 * d.a) ) DAY as Date 
            from (select 0 as a union all select 1 union all select 2 union all select 3 union all select 4 union all select 5 union all select 6 union all select 7 union 
            all select 8 union all select 9) as a cross join (select 0 as a union all select 1 union all select 2 union all select 3 union all select 4 union all select 5 
            union all select 6 union all select 7 union all select 8 union all select 9) as b cross join (select 0 as a union all select 1 union all select 2 union all select
            3 union all select 4 union all select 5 union all select 6 union all select 7 union all select 8 union all select 9) as c cross join (select 0 as a union all 
            select 1 union all select 2 union all select 3 union all select 4 union all select 5 union all select 6 union all select 7 union all select 8 union all select 9) 
            as d ) a left join (SELECT date_format(fecha,'%Y-%m-%d') as fecha ,SUM(case when clasificacion='A' then 1 else null end ) 
          as CountA,SUM(case when clasificacion='B' then 1 else null end ) as CountB ,SUM(case when clasificacion='C' then 1 else null end ) as CountC from stockcountsn where 1  ".$ubicacion." 
             and fecha between '".$_POST['FechaInicio']."' and '".$_POST['FechaFin']." 23:59:59' and estatus!=''  group by date_format(fecha,'%y-%m-%d')) as consulta ON consulta.fecha=a.Date WHERE a.Date 
             between '".$_POST['FechaInicio']."' and '".$_POST['FechaFin']." 23:59:59' and DAYOFWEEK(a.Date) IN ('2','3','4','5','6') group by date_format(a.Date,'%y-%m')  ORDER BY a.Date ASC";
       
        //   $sql="SELECT date_format(fecha,'%Y-%m') as fecha ,SUM(case when Lista!='' then 1 else null end ) as total from stockcountsn
        //   where 1 ".$ubicacion." and fecha between '".$_POST['FechaInicio']."' and '".$_POST['FechaFin']."'  group by date_format(fecha,'%Y-%m') order by fecha asc";
        $resultSQL = DB_query($sql);
        $NombreGrafica="Grafica por mes";
        $titulo="Meses del año";
        $titulo = utf8_decode($titulo);
        if(DB_num_rows($resultSQL)!=0){$this->Graficar($resultSQL,$NombreGrafica,$titulo,$tipoGrafica);}
        else { prnMsg('No se encontraron datos para graficar','error');}  
        
    }
    public function PersonaFiltros()
    {
        $sql = "SELECT loccode, locationname FROM locations where loccode in(1,2,5)";
        $resultSQL = DB_query($sql);
        return $resultSQL;
    }
    public function Graficar($resultSQL,$NombreGrafica,$titulo,$tipoGrafica)
    {      

     
        $graph = new PHPlot(950,450);
        $GraphTitle=$NombreGrafica;
        $graph->SetTitle($GraphTitle);
        $graph->SetTitleColor('blue');
        $graph->SetOutputFile('companies/' .$_SESSION['DatabaseName'] .  '/reports/countsgraph.png');
        $graph->SetXTitle(_($titulo));
        $graph->SetYTitle(_("Numero de piezas"));
        $graph->SetXTickPos('none');
        $graph->SetXTickLabelPos('none');
        $graph->SetXLabelAngle(90);
        $graph->SetBackgroundColor('white');
        $graph->SetTitleColor('blue');
        $graph->SetFileFormat('png');
        $graph->SetPlotType($tipoGrafica);
        $graph->SetIsInline('1');
        $graph->SetShading(5);
        $graph->SetDrawYGrid(TRUE);
        $graph->SetDataType('text-data');
        $graph->SetNumberFormat($DecimalPoint, $ThousandsSeparator);
        $graph->SetPrecisionY($_SESSION['CompanyRecord']['decimalplaces']);
        
        $GraphArray = array();
	    $i = 0;
	    while ($myrow = DB_fetch_array($resultSQL)){
        
	    	$GraphArray[$i] = array($myrow['fecha'],$myrow['CountA'],$myrow['CountB'],$myrow['CountC']);
	    	$i++;
	    }

            $graph->SetDataValues($GraphArray);
            // $graph->SetDataColors(
            //     array('SlateBlue','orange'),  //Data Colors
            //     array('black')	//Border Colors
            // );
	    //$graph->SetLegend(array(_('Actual'));
	    //if($_POST['fecha']!=''){
	    $graph->SetLegend(array('Conteos Articulos A','Conteos Articulos B','Conteos Articulos C'));
	    //}
    
    
	    $graph->SetYDataLabelPos('plotin');
        $minisql="SELECT (SUM(CASE WHEN stockmaster.clasif='A' THEN 1 ELSE NULL END)) as contA,(SUM(CASE WHEN stockmaster.clasif='B' THEN 1 ELSE NULL END)) as contB,(SUM(CASE WHEN stockmaster.clasif='C' THEN 1 ELSE NULL END)) as contC
        FROM stockmaster WHERE stockmaster.discontinued=0";
        $miniresult=DB_query($minisql);
        $minirow=DB_fetch_array($miniresult);
        $minirow['contA']=ceil(($minirow['contA']*.5)/5);
        $minirow['contB']=ceil(($minirow['contB']*.125)/5);
        $minirow['contC']=ceil(($minirow['contC']*0.038)/5);
        $preresult=DB_query("SET SQL_BIG_SELECTS=1;");
        $maximostiempos="SELECT
        stockmaster.stockid,
        MIN(
            (
                CASE WHEN conteos.ultimoconteo IS NULL THEN '2019-01-01' ELSE conteos.ultimoconteo
            END
        )
    ) AS masviejo,
    stockmaster.clasif
    FROM
        stockmaster
    LEFT JOIN(
        SELECT
            MAX(fecha) AS ultimoconteo,
            stockcountsn.stockid
        FROM
            stockcountsn
        WHERE
            stockcountsn.estatus != ''
        GROUP BY
            stockid
    ) AS conteos
    ON
        conteos.stockid = stockmaster.stockid
    WHERE
        stockmaster.discontinued = 0 AND stockmaster.clasif != '' AND stockmaster.clasif IS NOT NULL
    GROUP BY
        stockmaster.clasif ";
        $maximostiemposresult=DB_query($maximostiempos);
        $hoy=strtotime(date('Y-m-d'));
        while($maximostiemposrow=DB_fetch_array($maximostiemposresult)){
            $ult=strtotime($maximostiemposrow['masviejo']);
            
                $max[$maximostiemposrow['clasif']]=floor((($hoy-$ult)/86400));
            
        }
	    //Draw it
	    $graph->DrawGraph();
	    echo '<table class="selection">
	    		<tr>
	    			<td colspan="3"><p><img src="companies/' .$_SESSION['DatabaseName'] .  '/reports/countsgraph.png?t='.time().'" alt="Sales Report Graph"></img></p></td>
                </tr>
                <tr><th colspan="3">Cuota diaria de conteos vigente</th></tr>
                <tr><th>Clasificación A</th><th>Clasificación B</th><th>Clasificación C</th></tr>
                <tr class="striped_row"><td class="centre" >'.$minirow['contA'].' - Mayor plazo sin contar: '.$max['A'].' días </td><td class="centre" >'.$minirow['contB'].' - Mayor plazo sin contar: '.$max['B'].' días </td><td class="centre" >'.$minirow['contC'].' - Mayor plazo sin contar: '.$max['C'].' días </td></tr>
              </table>';
              
              
	     //include('../includes/footer.php');
        
    }
}


?>