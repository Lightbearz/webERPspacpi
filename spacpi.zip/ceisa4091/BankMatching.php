<?php
/* This script allows payments and receipts to be matched off against bank statements. */

include('includes/session.php');
$Title = _('Bank Matching');// Screen identificator.
$ViewTopic = 'GeneralLedger';// Filename's id in ManualContents.php's TOC.
$BookMark = 'BankMatching';// Filename's id in ManualContents.php's TOC.
include('includes/header.php');

if ((isset($_GET['Type']) AND $_GET['Type']=='Receipts')
		OR (isset($_POST['Type']) AND $_POST['Type']=='Receipts')){

	$Type = 'Receipts';
	$TypeName =_('Receipts');
	echo '<p class="page_title_text"><img alt="" src="'.$RootPath.'/css/'.$Theme.
		'/images/bank.png" title="' .
		_('Bank Matching') . '" /> ' .// Icon title.
		_('Bank Account Matching - Receipts') . '</p>';// Page title.

} elseif ((isset($_GET['Type']) AND $_GET['Type']=='Payments')
			OR (isset($_POST['Type']) AND $_POST['Type']=='Payments')) {

	$Type = 'Payments';
	$TypeName =_('Payments');
	echo '<p class="page_title_text"><img alt="" src="'.$RootPath.'/css/'.$Theme.
		'/images/bank.png" title="' .
		_('Bank Matching') . '" /> ' .// Icon title.
		_('Bank Account Matching - Payments') . '</p>';// Page title.

} else {

	prnMsg(_('This page must be called with a bank transaction type') . '. ' . _('It should not be called directly'),'error');
	include ('includes/footer.php');
	exit;
}

if (isset($_GET['Account'])) {
	$_POST['BankAccount']=$_GET['Account'];
	$_POST['ShowTransactions']=true;
	$_POST['Ostg_or_All']='Ostg';
	$_POST['First20_or_All']='All';
}


echo '<div class="page_help_text">' . _('Use this screen to match webERP Receipts and Payments to your Bank Statement.  Check your bank statement and click the button when you want to assign.') . '</div><br />';

echo '<form action="'. htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . '" method="post">';
echo '<div>';
echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';

echo '<input type="hidden" name="Type" value="' . $Type . '" />';

echo '<table class="selection">
		<tr>
			<td align="left">' . _('Bank Account') . ':</td>
			<td colspan="3"><select tabindex="1" autofocus="autofocus" name="BankAccount">';

$sql = "SELECT bankaccounts.accountcode,
				bankaccounts.bankaccountname
		FROM bankaccounts, bankaccountusers
		WHERE bankaccounts.accountcode=bankaccountusers.accountcode
			AND bankaccountusers.userid = '" . $_SESSION['UserID'] ."'
		ORDER BY bankaccounts.bankaccountname";
$resultBankActs = DB_query($sql);
while ($myrow=DB_fetch_array($resultBankActs)){
	if ($myrow['accountcode']==$_POST['BankAccount'] or $myrow['accountcode']==$_GET['Cuenta'] or (!isset($_POST['BankAccount']) and !isset($_GET['Cuenta'])  and $myrow['accountcode']=='102101-1') ){

		echo '<option selected="selected" value="' . $myrow['accountcode'] . '">' . $myrow['bankaccountname'] . '</option>';
	} else {
		echo '<option value="' . $myrow['accountcode'] . '">' . $myrow['bankaccountname'] . '</option>';
	}
}

echo '</select></td>
	</tr>';

if (!isset($_POST['BeforeDate']) OR !Is_Date($_POST['BeforeDate'])){
	$_POST['BeforeDate'] = Date($_SESSION['DefaultDateFormat']);
}
if (!isset($_POST['AfterDate']) OR !Is_Date($_POST['AfterDate'])){
	$_POST['AfterDate'] = Date($_SESSION['DefaultDateFormat'], Mktime(0,0,0,Date('m')-6,Date('d'),Date('y')));
$_POST['AfterDate']=date('Y').'/01/01';
}

// Change to allow input of FROM DATE and then TO DATE, instead of previous back-to-front method, add datepicker
echo '<tr>
		<td>' . _('Show') . ' ' . $TypeName . ' ' . _('from') . ':</td>
		<td><input tabindex="3" type="text" name="AfterDate" class="date" size="12" maxlength="10" required="required" onchange="isDate(this, this.value, '."'".$_SESSION['DefaultDateFormat']."'".')" value="' . $_POST['AfterDate'] . '" /></td>
	</tr>';

echo '<tr>
        <td>' . _('to') . ':</td>
		<td><input tabindex="2" type="text" name="BeforeDate" class="date" size="12" maxlength="10" required="required" onchange="isDate(this, this.value, '."'".$_SESSION['DefaultDateFormat']."'".')" value="' . $_POST['BeforeDate'] . '" /></td>
	</tr>';
echo '<tr>
		<td colspan="3">' . _('Choose outstanding') . ' ' . $TypeName . ' ' . _('only or all') . ' ' . $TypeName . ' ' . _('in the date range') . ':</td>
		<td><select tabindex="4" name="Ostg_or_All">';

if ($_POST['Ostg_or_All']=='All'){
	echo '<option selected="selected" value="All">' . _('Show all') . ' ' . $TypeName . ' ' . _('in the date range') . '</option>';
	echo '<option value="Ostdg">' . _('Show unmatched') . ' ' . $TypeName . ' ' . _('only') . '</option>';
} else {
	echo '<option value="All">' . _('Show all') . ' ' . $TypeName . ' ' . _('in the date range') . '</option>';
	echo '<option selected="selected" value="Ostdg">' . _('Show unmatched') . ' ' . $TypeName . ' ' . _('only') . '</option>';
}
echo '</select></td>
	</tr>';

echo '<tr>
	<td colspan="3">' . _('Choose to display only the first 20 matching') . ' ' . $TypeName . ' ' . _('or all') . ' ' . $TypeName . ' ' . _('meeting the criteria') . ':</td>
	<td><select tabindex="5" name="First20_or_All">';

	echo '<option selected="selected" value="All">' . _('Show all') . ' ' . $TypeName . ' ' . _('in the date range') . '</option>';
	echo '<option value="First20">' . _('Show only the first 20') . ' ' . $TypeName . '</option>';


echo '</select></td>
	</tr>';

echo '</table>
	<br />
	<div class="centre">
		<input tabindex="6" type="submit" name="ShowTransactions" value="' . _('Show selected') . ' ' . $TypeName . '" />';

echo '</div>';

$InputError=0;
if (!Is_Date($_POST['BeforeDate'])){
	$InputError =1;
	prnMsg(_('The date entered for the field to show') . ' ' . $TypeName . ' ' . _('before') . ', ' .
		_('is not entered in a recognised date format') . '. ' . _('Entry is expected in the format') . ' ' .
		$_SESSION['DefaultDateFormat'],'error');
}
if (!Is_Date($_POST['AfterDate'])){
	$InputError =1;
	prnMsg( _('The date entered for the field to show') . ' ' . $Type . ' ' . _('after') . ', ' .
		_('is not entered in a recognised date format') . '. ' . _('Entry is expected in the format') . ' ' .
		$_SESSION['DefaultDateFormat'],'error');
}

if ($InputError !=1
	AND isset($_POST['BankAccount'])
	AND $_POST['BankAccount']!=''
	AND isset($_POST['ShowTransactions'])){

	$SQLBeforeDate = FormatDateForSQL($_POST['BeforeDate']);
	$SQLAfterDate = FormatDateForSQL($_POST['AfterDate']);
	
	$tipo='cargo';
$que='Pago';
if($Type=='Receipts'){
$tipo='abono';
$que='Recibo';
}

	$BankResult = DB_query("SELECT decimalplaces,
									currcode
							FROM bankaccounts INNER JOIN currencies
							ON bankaccounts.currcode=currencies.currabrev
							WHERE accountcode='" . $_POST['BankAccount'] . "'");
	$BankRow = DB_fetch_array($BankResult);
	$CurrDecimalPlaces = $BankRow['decimalplaces'];
	$CurrCode = $BankRow['currcode'];
	
		$nulo='';	
	if($tipo=='abono'){
$nulo=' OR (abono=0 and cargo=0) ';	
	}

	if ($_POST['Ostg_or_All']=='All'){


			$sql = "SELECT bankedo.*,debtorsmaster.name,suppliers.suppname,chartmaster.accountname
					FROM bankedo
					LEFT JOIN debtorsmaster ON debtorsmaster.debtorno=bankedo.banktransidrel
					LEFT JOIN suppliers ON suppliers.supplierid=bankedo.banktransidrel
					LEFT JOIN chartmaster ON chartmaster.accountcode=bankedo.banktransidrel
					WHERE (".$tipo.">0.01 ".$nulo.")
						AND fecha >= '". $SQLAfterDate . "'
						AND fecha <= '" . $SQLBeforeDate . "'
						AND bankaccount='" . $_POST['BankAccount'] . "'
					ORDER BY fecha";

	
	} else { /*it must be only the outstanding bank trans required */
	
			$sql = "SELECT *
					FROM bankedo
					WHERE (".$tipo.">0.01 ".$nulo.")
						AND fecha >= '". $SQLAfterDate . "'
						AND fecha <= '" . $SQLBeforeDate . "'
						AND bankaccount='" . $_POST['BankAccount'] . "'
						AND (banktransidrel='0' OR banktransidrel='')
					ORDER BY fecha";
		}
	if ($_POST['First20_or_All']!='All'){
		$sql = $sql . " LIMIT 20";
	}

	$ErrMsg = _('The payments with the selected criteria could not be retrieved because');
	$PaymentsResult = DB_query($sql, $ErrMsg);

	echo '<table cellpadding="2" class="selection">
			<thead>
			<tr>
				<th class="ascending">' .  _('Fecha') . '</th>
				<th class="ascending">' . _('Concepto') . '</th>
				<th class="ascending">' . $tipo . '</th>
				<th class="ascending">' . _('Asignación') . '</th>
					</tr>
			</thead>
			<tbody>';

	$i = 1; //no of rows counter
$acumulado=0;
	while ($myrow=DB_fetch_array($PaymentsResult)) {
	$color='lightblue';
	$hacer='Ver';
	if($myrow['name']!=''){
		$identificado='Cliente: '.$myrow['name'].' - ';
	}
	if($myrow['suppname']!=''){
			$identificado='Proveedor: '.$myrow['suppname'].' - ';

	}
if($myrow['accountname']!=''){
			$identificado='Cuenta: '.$myrow['accountname'].' - ';

	}




	if($myrow['banktransidrel']=='0' or $myrow['banktransidrel']==''){
	$myrow['banktransidrel']='sin asignar';
	$color='lightcoral';
	$hacer='Asignar';
$identificado='';
	}
	if($_POST['BankAccount']=='101003'){
	$myrow['concepto']=$myrow['concepto'].' nummov: '.$myrow['nummovml'].' oprel: '.$myrow['oprelml'];
	
	}
echo '<tr class="striped_row">
				<td >' .$myrow['fecha'] . '</td>
				<td >' . $myrow['concepto'] . '</td>
				<td class="number">' .  $myrow[$tipo] . '</td>
				<td   style="background-color:'.$color.'">'.$identificado.  $myrow['banktransidrel'] .'  </td>';
				
				if($myrow['banktransidrel']=='sin asignar'){
			echo	'<td ><a href="BankMatching.php?Type='.$Type.'&Localizar='.$myrow['idregistro'].'&Cuenta='.$_POST['BankAccount'].'">'.$hacer.' '.  $que . '</a></td>';
}
else{
			echo	'<td ><a href="BankMatching.php?Type='.$Type.'&Localizar='.$myrow['idregistro'].'&Cuenta='.$_POST['BankAccount'].'">'.$hacer.' '.  $que . '</a></td>';
}
			 echo		'</tr>';
			 $acumulado+=$myrow[$tipo];
	}

	echo '</tbody>
		</table>';
		echo 'TOTAL: '.$acumulado;
			echo '<br />';
			
}
echo '</div>';
echo '</form>';

if(isset($_GET['Localizar']) and $_GET['Localizar']!=''){
$sql = "SELECT *
					FROM bankedo
					WHERE idregistro='".$_GET['Localizar']."'";
$Movimiento=DB_query($sql);

$myrowput=DB_fetch_array($Movimiento);

	if($_GET['Cuenta']=='101003'){
	$myrowput['concepto']=$myrowput['concepto'].' nummov: '.$myrowput['nummovml'].' oprel: '.$myrowput['oprelml'];
	
	}
if(!isset($myrowput)){
	prnMsg(_('No se encontró el movimiento por favor reintente'),'info');

}
else{
/////////////////////////////////////////PAGOS
if($_GET['Type']=='Payments'){
	echo '<form method="POST" action="' . htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . '?Type='.$_GET['Type'].'&Localizar='.$_GET['Localizar'].'&Cuenta='.$_GET['Cuenta'].'">';
		echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
$tipo='cargo';

if(isset($_POST['Conciliar'])){

$sql="UPDATE bankedo SET banktransidrel='".$_POST['Conciliar']."' WHERE idregistro='".$_GET['Localizar']."'";
$query=DB_query($sql);

prnMsg( 'Su pago fue correctamente conciliado con '.$_POST['Conciliar'], 'success');
include('includes/footer.php');
exit;

}




echo '<table cellpadding="2" class="selection">
			<thead>
			<tr>
				<th>' . _('Fecha') . '</th>
				<th>' . _('Concepto') . '</th>
				<th>' . $tipo . '</th>
					</tr>
			</thead>
			<tbody>';
			echo '<tr class="striped_row">
				<td >' .$myrowput['fecha'] . '</td>
				<td >' .  $myrowput['concepto'] . '</td>
				<td >' .  locale_number_format($myrowput[$tipo],2) . '</td></tr></tbody></table>';
				
					if($myrowput['banktransidrel']!='' and $myrowput['banktransidrel']!='0' ){
echo '<div class="centre" style="background-color:limegreen"> Pago Asignado a '.$myrowput['banktransidrel'].'</div>';
include('includes/footer.php');
exit;				
				}
				if(strpos($myrowput['concepto'],'BANCA') or strpos($myrowput['concepto'],'SERV ')){
				$thisfecha=strtotime($myrowput['fecha']);
				$thisfecha=date('Y/m/d',$thisfecha);
echo '<div class="centre" style="background-color:orange">Posible comisión bancaria de ser correcto genere pago <a href="Payments.php?Cuentauno='.$myrowput['bankaccount'].'&Monto='.$myrowput[$tipo].'&Cuentados=603002&Fecha='.$thisfecha.'&Refe='.$myrowput['concepto'].'" target="_self">Aquí</a></div>';				
				}
				if(strpos($myrowput['concepto'],'Inversion') or strpos($myrowput['concepto'],'Intereses')){
				$thisfecha=strtotime($myrowput['fecha']);
				$thisfecha=date('Y/m/d',$thisfecha);
echo '<div class="centre" style="background-color:orange">Posible retiro por inversión de ser correcto genere pago <a href="Payments.php?Cuentauno='.$myrowput['bankaccount'].'&Monto='.$myrowput[$tipo].'&Cuentados=401000&Fecha='.$thisfecha.'&Refe='.$myrowput['concepto'].'" target="_self">Aquí</a></div>';				
				}
				$sql = "SELECT * from banktrans LEFT JOIN supptrans ON banktrans.transno=supptrans.transno and banktrans.type=supptrans.type LEFT JOIN debtortrans ON banktrans.transno=debtortrans.transno and banktrans.type=debtortrans.type LEFT JOIN gltrans ON gltrans.typeno=banktrans.transno and banktrans.type=gltrans.type and gltrans.account!=banktrans.bankact LEFT JOIN chartmaster on gltrans.account=chartmaster.accountcode  WHERE banktrans.transdate='".$myrowput['fecha']."' and banktrans.amount='-".$myrowput[$tipo]."' and banktrans.bankact='".$myrowput[bankaccount]."'";
			$PosibleSupp=DB_query($sql);
			
			echo '<table cellpadding="2" class="selection">
			<thead>
			<tr>
				<th>' . _('Proveedor/Cuenta') . '</th>
				<th>' . _('Lote/Movimiento') . '</th>
				<th>' . _('Asignar Pago') . '</th>
					</tr>
			</thead>
			<tbody>';

	$truee=0;



	
while($myrowpos=DB_fetch_array($PosibleSupp)){		
if($myrowpos['supplierno']!=''){
$truee=1;
$asign=$myrowpos['supplierno'];
}
if($myrowpos['debtorno']!='' and $myrowpos['supplierno']==''){
$truee=1;
$asign=$myrowpos['debtorno'];
$myrowpos['supplierno']=$myrowpos['debtorno'];
}
if($myrowpos['account']!='' and $myrowpos['supplierno']=='' and $myrowpos['debtorno']==''){
$truee=1;
$asign=$myrowpos['account'];
$myrowpos['supplierno']=$myrowpos['accountname'];
}
	if($myrowpos[1]==1 and $myrowpos['account']==''){
	$sql="SELECT * from banktrans INNER JOIN bankaccounts on bankaccounts.accountcode=banktrans.bankact WHERE (amount='".$myrowput[$tipo]."' or amount=ROUND((functionalexrate*$myrowput[$tipo]),2) or ROUND(amount,2)=ROUND((functionalexrate*$myrowput[$tipo]),2) or TRUNCATE(amount,2)=TRUNCATE((functionalexrate*$myrowput[$tipo]),2) or amount=TRUNCATE((functionalexrate*$myrowput[$tipo]),2))  and transdate='".$myrowput['fecha']."' and (banktrans.type='2' or banktrans.type='12' or banktrans.ref LIKE '@".$myrowpos[2]."%') and banktrans.amount!=0 ";
$inresult=DB_query($sql);
$cuenta=DB_fetch_array($inresult);
$myrowpos['supplierno']='Transferencia intercuenta a '.$cuenta['bankaccountname'];
if($cuenta['bankaccountname']!=''){
$truee=1;
$asign=$cuenta['accountcode'];
}
}
			echo '<tr class="striped_row">
			<td >' .$myrowpos['supplierno'] .'</td>;
			<td >' .$myrowpos[2] .'</td>';
			if($truee==1){

					echo 	'<td style="background-color:limegreen" >Asignable!<button style="background-color:DodgerBlue" onclick="return confirm(\'¿Está seguro de conciliar este pago? \');" type="submit" name="Conciliar" value="'.$asign.'">Conciliar</button></td>';

			}
			else{
			echo 	'<td style="background-color:lightcoral" >NO Asignable!</td>';
			}
			
	echo '</tr>';
				}
echo '</tbody></table>';
if($truee==0){
echo 'No se encontraron coincidencias';
}

//////////////////////////////PAGOS				
				
				
echo '</form>';		
				
				
				
}

//////////////////////////////////////////////////////INGRESOS//////////////////
if($_GET['Type']=='Receipts'){
$tipo='abono';


echo '<table cellpadding="2" class="selection">
			<thead>
			<tr>
				<th>' . _('Fecha') . '</th>
				<th>' . _('Concepto') . '</th>
				<th>' . $tipo . '</th>
					</tr>
			</thead>
			<tbody>';
			echo '<tr class="striped_row">
				<td >' .$myrowput['fecha'] . '</td>
				<td >' .  $myrowput['concepto'] . '</td>
				<td >' .  locale_number_format($myrowput[$tipo],2) . '</td></tr></tbody></table>';
				
			
				
$sql = "SELECT orden.debtorno as VENTA,orden.orderno, facturas.debtorno as INVOICE, facturas.transno,facturas.trandate FROM (SELECT salesorders.orderno, SUM( salesorderdetails.unitprice * ( salesorderdetails.quantity  ) * ( 1 - salesorderdetails.discountpercent ) / currencies.rate ) AS ordervalue, debtorsmaster.debtorno
FROM salesorders
INNER JOIN salesorderdetails ON salesorders.orderno = salesorderdetails.orderno
INNER JOIN debtorsmaster ON salesorders.debtorno = debtorsmaster.debtorno
INNER JOIN custbranch ON debtorsmaster.debtorno = custbranch.debtorno
AND salesorders.branchcode = custbranch.branchcode
INNER JOIN currencies ON debtorsmaster.currcode = currencies.currabrev
LEFT OUTER JOIN pickreq ON pickreq.orderno = salesorders.orderno
AND pickreq.closed =0
WHERE salesorderdetails.completed =0
GROUP BY salesorders.orderno, debtorsmaster.name, custbranch.brname, salesorders.customerref, salesorders.orddate, salesorders.deliverydate, salesorders.deliverto, salesorders.printedpackingslip, salesorders.poplaced
ORDER BY salesorders.orderno) as orden LEFT JOIN (SELECT systypes.typename,

				debtortrans.id,

				debtortrans.type,

				debtortrans.transno,

				debtortrans.debtorno,

				debtortrans.trandate,

				debtortrans.reference,

				debtortrans.invtext,

				debtortrans.order_,

				salesorders.customerref,

				debtortrans.rate,

				(debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount) AS totalamount,

				debtortrans.alloc AS allocated

			FROM debtortrans

			INNER JOIN systypes

				ON debtortrans.type = systypes.typeid

			LEFT JOIN salesorders

				ON salesorders.orderno=debtortrans.order_

			WHERE debtortrans.trandate >= '2019-01-01') as facturas ON facturas.debtorno=orden.debtorno WHERE TRUNCATE(orden.ordervalue,2)='".$myrowput[$tipo]."' OR TRUNCATE((orden.ordervalue*1.16),1)=TRUNCATE('".$myrowput[$tipo]."',1) OR ROUND(orden.ordervalue,2)='".$myrowput[$tipo]."' OR TRUNCATE((orden.ordervalue*1.16),2)='".$myrowput[$tipo]."' OR ROUND((orden.ordervalue*1.16),2)='".$myrowput[$tipo]."' OR (TRUNCATE(facturas.totalamount,2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (ROUND(facturas.totalamount,2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (TRUNCATE((facturas.totalamount*0.95),2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (TRUNCATE((facturas.totalamount*0.95),1)=TRUNCATE('".$myrowput[$tipo]."',1) AND facturas.totalamount>facturas.allocated) OR (ROUND((facturas.totalamount*0.95),2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (ROUND((facturas.totalamount*0.96),2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (TRUNCATE((facturas.totalamount*0.96),2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (TRUNCATE((facturas.totalamount*0.96),1)=TRUNCATE('".$myrowput[$tipo]."',1) AND facturas.totalamount>facturas.allocated) UNION SELECT orden.debtorno as VENTA,orden.orderno, facturas.debtorno as INVOICE, facturas.transno, facturas.trandate FROM (SELECT salesorders.orderno, SUM( salesorderdetails.unitprice * ( salesorderdetails.quantity ) * ( 1 - salesorderdetails.discountpercent ) / currencies.rate ) AS ordervalue, debtorsmaster.debtorno
FROM salesorders
INNER JOIN salesorderdetails ON salesorders.orderno = salesorderdetails.orderno
INNER JOIN debtorsmaster ON salesorders.debtorno = debtorsmaster.debtorno
INNER JOIN custbranch ON debtorsmaster.debtorno = custbranch.debtorno
AND salesorders.branchcode = custbranch.branchcode
INNER JOIN currencies ON debtorsmaster.currcode = currencies.currabrev
LEFT OUTER JOIN pickreq ON pickreq.orderno = salesorders.orderno
AND pickreq.closed =0
WHERE salesorderdetails.completed =0
GROUP BY salesorders.orderno, debtorsmaster.name, custbranch.brname, salesorders.customerref, salesorders.orddate, salesorders.deliverydate, salesorders.deliverto, salesorders.printedpackingslip, salesorders.poplaced
ORDER BY salesorders.orderno) as orden RIGHT JOIN (SELECT systypes.typename,

				debtortrans.id,

				debtortrans.type,

				debtortrans.transno,

				debtortrans.debtorno,

				debtortrans.trandate,

				debtortrans.reference,

				debtortrans.invtext,

				debtortrans.order_,

				salesorders.customerref,

				debtortrans.rate,

				(debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount) AS totalamount,

				debtortrans.alloc AS allocated

			FROM debtortrans

			INNER JOIN systypes

				ON debtortrans.type = systypes.typeid

			LEFT JOIN salesorders

				ON salesorders.orderno=debtortrans.order_

			WHERE debtortrans.trandate >= '2019-01-01') as facturas ON facturas.debtorno=orden.debtorno WHERE TRUNCATE(orden.ordervalue,2)='".$myrowput[$tipo]."' OR TRUNCATE((orden.ordervalue*1.16),2)='".$myrowput[$tipo]."' OR TRUNCATE((orden.ordervalue*1.16),1)=TRUNCATE('".$myrowput[$tipo]."',1) OR ROUND(orden.ordervalue,2)='".$myrowput[$tipo]."' OR ROUND((orden.ordervalue*1.16),2)='".$myrowput[$tipo]."' OR (TRUNCATE(facturas.totalamount,2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (ROUND(facturas.totalamount,2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (TRUNCATE((facturas.totalamount*0.95),2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (TRUNCATE((facturas.totalamount*0.95),1)=TRUNCATE('".$myrowput[$tipo]."',1) AND facturas.totalamount>facturas.allocated) OR (ROUND((facturas.totalamount*0.95),2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (ROUND((facturas.totalamount*0.96),2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (TRUNCATE((facturas.totalamount*0.96),2)='".$myrowput[$tipo]."' AND facturas.totalamount>facturas.allocated) OR (TRUNCATE((facturas.totalamount*0.96),1)=TRUNCATE('".$myrowput[$tipo]."',1) AND facturas.totalamount>facturas.allocated) ORDER BY VENTA";
$PosibleCust=DB_query($sql);

	echo '<form method="POST" action="' . htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . '?Type='.$_GET['Type'].'&Localizar='.$_GET['Localizar'].'&Cuenta='.$_GET['Cuenta'].'">';
		echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
$tipo='cargo';

if(isset($_POST['Transferencia'])){

$sql="UPDATE bankedo SET banktransidrel='".$_POST['Transferencia']."' WHERE idregistro='".$_GET['Localizar']."'";
$query=DB_query($sql);

prnMsg( 'Su pago fue correctamente marcado como transferencia a '.$_POST['Transferencia'], 'success');
include('includes/footer.php');
exit;
}

if(isset($_POST['Cero'])){

$sql="UPDATE bankedo SET banktransidrel='".$_POST['Cero']."' WHERE idregistro='".$_GET['Localizar']."'";
$query=DB_query($sql);

prnMsg( 'Su ingreso fue correctamente marcado como '.$_POST['Cero'], 'success');
include('includes/footer.php');
exit;
}

if(isset($_POST['Previo'])){

$sql="UPDATE bankedo SET banktransidrel='".$_POST['Previo']."' WHERE idregistro='".$_GET['Localizar']."'";
$query=DB_query($sql);

prnMsg( 'Su ingreso fue correctamente asignado como previo de '.$_POST['Previo'], 'success');
include('includes/footer.php');
exit;
}

if(isset($_POST['Devolucion'])){

$sql="UPDATE bankedo SET banktransidrel='".$_POST['Devolucion']."' WHERE idregistro='".$_GET['Localizar']."'";
$query=DB_query($sql);

prnMsg( 'Su pago fue correctamente marcado a '.$_POST['Devolucion'], 'success');
include('includes/footer.php');
exit;
}
	if($myrowput['banktransidrel']!='' and $myrowput['banktransidrel']!='0'  ){
echo '<div class="centre" style="background-color:limegreen"> Recibo Asignado a '.$myrowput['banktransidrel'].'</div>';
include('includes/footer.php');
exit;				
				}
				
					if($myrowput['abono']==0){
echo '<span class="centre" style="background-color:limegreen">Ingreso de valor NULO encontrado</span> <button style="background-color:lightblue" name="Cero" value="Valor0" onclick="return confirm(\'¿Está seguro de marcar como CERO? \');" > Marcar como CERO</button>';
include('includes/footer.php');
exit;	
	}
	
	if($_GET['Cuenta']=='101003'){
	$sql="SELECT debtortrans.* FROM debtortrans INNER JOIN banktrans on banktrans.transno=debtortrans.transno and banktrans.type=debtortrans.type and debtortrans.ovamount=-banktrans.amount WHERE debtortrans.type='12' and banktrans.amount='".$myrowput['abono']."' and debtortrans.trandate='".$myrowput['fecha']."' and banktrans.bankact='101003' OR debtortrans.invtext LIKE '%".$myrowput['nummovml']."%' ";
	$mercadoresult=DB_query($sql);
	$mercadorow=DB_fetch_array($mercadoresult);
	}
	
		if(isset($mercadorow['debtorno'])){
echo '<span class="centre" style="background-color:limegreen">Ingreso previamente ingresado a <a href="CustomerInquiry.php?CustomerID='.$mercadorow['debtorno'].'" target="_blank">'.$mercadorow['debtorno'].'</a></span> <button style="background-color:lightblue" name="Previo" value="'.$mercadorow['debtorno'].'" onclick="return confirm(\'¿Está seguro de marcar como previo? \');" > Marcar previo</button></br>'.$mercadorow['invtext'].' ';
include('includes/footer.php');
exit;	
	}

if(strpos($myrowput['concepto'],'BNET')!=false){
		$pos=strpos($myrowput['concepto'],'BNET');
	$bnet=substr($myrowput['concepto'],$pos,18);
$sql="SELECT banktransidrel FROM bankedo WHERE concepto LIKE '%".$bnet."%' AND banktransidrel!='0' AND banktransidrel!='' ORDER BY fecha DESC LIMIT 1";
$Posiblecuenta=DB_query($sql);
$myrowcuenta=DB_fetch_array($Posiblecuenta);
	}
	
	if(strpos($myrowput['concepto'],'REFBNTC')!=false){
		$pos=strpos($myrowput['concepto'],'REFBNTC');
	$bntc=substr($myrowput['concepto'],$pos,15);
$sql="SELECT banktransidrel FROM bankedo WHERE concepto LIKE '%".$bntc."%' AND banktransidrel!='0' AND banktransidrel!='' ORDER BY fecha DESC LIMIT 1";
$Posiblecuenta=DB_query($sql);
$myrowcuenta=DB_fetch_array($Posiblecuenta);
	}

$sql="SELECT * FROM debtorsmaster WHERE debtorno='".$myrowcuenta[0]."'";
$check=DB_query($sql);
$checkif=DB_fetch_array($check);
			
if(isset($myrowcuenta[0]) ){
echo '<span style="background-color:limegreen">Cuenta '.$bnet.$bntc.' Rastreada a '.$myrowcuenta[0].'</span>' ;
if(isset($checkif[0])){
echo '<a href="ReciboIngreso.php?NewReceipt=Yes&Type=Customer&idregistro='.$myrowput['idregistro'].'&Asign='.$myrowcuenta[0].'"> Generar Recibo</a>';
}
if(!isset($checkif[0])){
echo '<span style="background-color:yellow"> Posible devolución, notificar a pagos para generar movimiento</span>';
}
}
if(strpos($myrowput['concepto'],'DANI')!=false){
echo '</br><span style="background-color:limegreen">Referencia "DANI" encontrada en concepto, verifique para asignar</span>' ;
echo '<a href="ReciboIngreso.php?NewReceipt=Yes&Type=Customer&idregistro='.$myrowput['idregistro'].'&Asign=LDV16R"> Generar Recibo para LDV16R</a>';
	}		
	$truee=0;
	$sql="SELECT * FROM banktrans INNER JOIN bankaccounts ON bankaccounts.accountcode=banktrans.bankact where banktrans.bankact='".$myrowput['bankaccount']."' and banktrans.transdate='".$myrowput['fecha']."' and banktrans.amount='".$myrowput['abono']."' and (type='2' or  type='12') ";
	$resulttrans=DB_query($sql);
	$trans0=DB_fetch_array($resulttrans);
	if(isset($trans0[0])){
	$truee=1;
	$sql="SELECT * FROM banktrans INNER JOIN bankaccounts ON bankaccounts.accountcode=banktrans.bankact where banktrans.transdate='".$myrowput['fecha']."' and (banktrans.amount='-".$myrowput['abono']."' or ROUND(banktrans.amount,2)=-ROUND((".$myrowput['abono']."*banktrans.functionalexrate),2) or ROUND(banktrans.amount,2)=-ROUND((".$myrowput['abono']."/".$trans0['functionalexrate']."),2))   and type='1' ";
	$resulttrans=DB_query($sql);
	$trans=DB_fetch_array($resulttrans);
echo '</br><span style="background-color:limegreen">Posible transferencia intercuenta de '.$trans['bankaccountname'].' encontrada:</span>' ;
if(isset($trans[0])){
echo '<button style="background-color:lightblue" name="Transferencia" value="'.$trans['bankact'].'" onclick="return confirm(\'¿Está seguro de marcar como transferencia? \');" > Marcar como transferencia</button>';
	}
	if(!isset($trans[0])){
echo 'No se puede encontrar la cuenta de procedencia';
	}

	
	}
	$sql = "SELECT * from banktrans LEFT JOIN supptrans ON banktrans.transno=supptrans.transno and banktrans.type=supptrans.type  WHERE banktrans.transdate='".$myrowput['fecha']."' and amount='".$myrowput['abono']."' and banktrans.bankact='".$myrowput[bankaccount]."' and banktrans.type='22'";
	$PosibleSupp=DB_query($sql);
	$devol=DB_fetch_array($PosibleSupp);
	if(isset($devol[0])){
	$truee=1;
echo '</br><span style="background-color:limegreen">Posible devolución de '.$devol['supplierno'].':</span>' ;

echo '<button style="background-color:lightblue" name="Devolucion" value="'.$devol['supplierno'].'" onclick="return confirm(\'¿Está seguro de marcar como devolución? \');" > Marcar como devolución</button>';
	
	}	
	$sql = "SELECT * from banktrans LEFT JOIN gltrans ON gltrans.typeno=banktrans.transno and banktrans.type=gltrans.type and gltrans.account!=banktrans.bankact LEFT JOIN chartmaster on gltrans.account=chartmaster.accountcode  WHERE banktrans.transdate='".$myrowput['fecha']."' and banktrans.amount='".$myrowput['abono']."' and banktrans.bankact='".$myrowput[bankaccount]."'";
	$Posibleinver=DB_query($sql);
	$inver=DB_fetch_array($Posibleinver);
	if(isset($inver['account'])){
	$truee=1;
echo '</br><span style="background-color:limegreen">Posible abono de inversión '.$inver['accountname'].':</span>' ;

echo '<button style="background-color:lightblue" name="Devolucion" value="'.$inver['account'].'" onclick="return confirm(\'¿Está seguro de marcar como inversión? \');" > Marcar como abono inversión</button>';
	}		

echo '</form>';
if((strpos($myrowput['concepto'],'Inversion') or strpos($myrowput['concepto'],'Intereses'))){
				$thisfecha=strtotime($myrowput['fecha']);
				$thisfecha=date('Y/m/d',$thisfecha);
echo '<div class="centre" style="background-color:orange">Posible abono por inversión de ser correcto genere Lote <a href="Payments.php?Cuentauno='.$myrowput['bankaccount'].'&Monto=-'.$myrowput['abono'].'&Cuentados=401000&Fecha='.$thisfecha.'&Refe='.$myrowput['concepto'].'" target="_self">Aquí</a></div>';				
				}

				
				echo '<table cellpadding="2" class="selection">
			<thead>
			<tr>
				<th>' . _('Cliente') . '</th>
				<th>' . _('Orden de venta pendiente') . '</th>
				<th>' . _('Factura sin localizar') . '</th>
				<th>' . _('Cuenta de banco') . '</th>
				<th>' . _('Asignar Pago') . '</th>
					</tr>
			</thead>
			<tbody>';

	


	
while($myrowpos=DB_fetch_array($PosibleCust)){		
	$truee=1;
			echo '<tr class="striped_row">
			<td >' .$myrowpos['VENTA'] .' '. $myrowpos['INVOICE'] .'</td>
				<td >'. $myrowpos['orderno'] .'</td>
				<td >'. $myrowpos['transno'] . ' '. $myrowpos['trandate'] . '</td>';
				
				if(isset($myrowcuenta[0]) AND  ($myrowcuenta[0]==$myrowpos['VENTA'] OR $myrowcuenta[0]==$myrowpos['INVOICE'])){
			echo	'<td style="background-color:limegreen" > Coincidente</td>';
				}
				else{ echo	'<td style="background-color:lightcoral" >No Coincidente o No localizada</td>';}
				if(isset($myrowpos['VENTA'])){
				$you=$myrowpos['VENTA'];
				}
				elseif(isset($myrowpos['INVOICE'])){
				$you=$myrowpos['INVOICE'];
				}
				
			echo	'<td ><a href="ReciboIngreso.php?NewReceipt=Yes&Type=Customer&idregistro='.$myrowput['idregistro'].'&Asign='.$you.'">Generar Recibo</a></td>
				</tr>';
				}
echo '</tbody></table>';
if($truee==0){
echo 'No se encontraron coincidencias';
}
if(strpos($myrowput['concepto'],'DANI')==false){
echo '</br></br><span style="background-color:yellow">Puede asignar seleccionando cliente, VERIFIQUE para asignar</span>' ;
echo '<a href="ReciboIngreso.php?NewReceipt=Yes&Type=Customer&idregistro='.$myrowput['idregistro'].'"> Generar Recibo para un cliente en particular</a>';
}	
	
	
	

}
}
}


include('includes/footer.php');
?>
