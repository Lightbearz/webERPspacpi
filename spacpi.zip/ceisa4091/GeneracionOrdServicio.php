<?php


include('includes/session.php');
include('includes/SQL_CommonFunctions.inc');
$Title = _('Ordenes de servicio');
include('includes/header.php');
if(!isset($_GET['Print'])){
echo '<p class="page_title_text"><img src="'.$RootPath.'/css/'.$Theme.'/images/magnifier.png" title="' . _('Search') . '" alt="" />' . ' ' . $Title . '</p>
	<form action="' . htmlspecialchars($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8') . '" method="get">
	<div>
		<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';


		echo '<table class="selection"><tr><td>';
		echo _('Service Order Number') . ': <input type="text" name="OS" autofocus="autofocus" maxlength="10" size="10" />&nbsp; ' . _(' Lote') . ':<input type="text" name="Lote" maxlength="7" size="7" /></td>';
		
		echo '<td>&nbsp; ' . _(' Status') . ':<select name="estatus" >
		<option value="All" selected="selected" >All</option >
		<option value="sinorden" >Sin iniciar</option >
		<option value="almacen" >En almacen</option >
		<option value="reparando" >En reparación</option >
		<option value="finalizada" >Finalizados</option ></select></td></tr>';


	echo		'</table><div class="centre"><input type="submit" name="SearchOrders" value="' . _('Search') . '" /></div>	
			<br /></div>
          </form>';
	}
if(isset($_GET['SearchOrders'])){

if($_GET['estatus']=='All'  ){
if($_GET['Lote']=='' AND $_GET['OS']==''){
$sql="SELECT *, COUNT(stockid) as num, COUNT(CASE WHEN estatus='sinorden' THEN 1 ELSE NULL END) as sin, COUNT(CASE WHEN estatus='finalizado' THEN 1 ELSE NULL END) as fin  FROM ordenesservicio GROUP BY lote ORDER BY lote ASC";
}
if(!$_GET['Lote']=='' AND $_GET['OS']==''){
$sql="SELECT *, COUNT(stockid) as num, COUNT(CASE WHEN estatus='sinorden' THEN 1 ELSE NULL END) as sin, COUNT(CASE WHEN estatus='finalizado' THEN 1 ELSE NULL END) as fin  FROM ordenesservicio WHERE lote='".$_GET['Lote']."' GROUP BY lote ORDER BY lote ASC";
}
if($_GET['Lote']=='' AND !$_GET['OS']==''){
$sql="SELECT *, COUNT(stockid) as num, COUNT(CASE WHEN estatus='sinorden' THEN 1 ELSE NULL END) as sin, COUNT(CASE WHEN estatus='finalizado' THEN 1 ELSE NULL END) as fin  FROM ordenesservicio WHERE OS='".$_GET['OS']."' GROUP BY lote ORDER BY lote ASC";
}
if(!$_GET['Lote']=='' AND !$_GET['OS']==''){
$sql="SELECT *, COUNT(stockid) as num, COUNT(CASE WHEN estatus='sinorden' THEN 1 ELSE NULL END) as sin, COUNT(CASE WHEN estatus='finalizado' THEN 1 ELSE NULL END) as fin  FROM ordenesservicio WHERE OS='".$_GET['OS']."' AND lote='".$_GET['Lote']."' GROUP BY lote ORDER BY lote ASC";
}
}

if($_GET['estatus']!='All'){
$condicion=" WHERE estatus='".$_GET['estatus']."' ";

if($_GET['Lote']!=''){
$condicion.=" AND lote='".$_GET['Lote']."' ";
}
if($_GET['OS']!=''){
$condicion.=" AND OS='".$_GET['OS']."' ";
}
$sql="SELECT *, COUNT(stockid) as num FROM ordenesservicio ".$condicion." GROUP BY lote ORDER BY lote ASC,OS ASC";
}


$result=DB_query($sql);
echo		'<table ><thead><tr>
<th>Lote</th>
<th>Cod. Cliente</th>
<th>Nombre Cliente </th>
<th>No. Artículos</th>
<th>Fecha captura</th>
<th>estatus</th>
<th>Mercado Libre</th>
<th>Ingreso</th>
<th>Generar Orden</th>
</tr><thead><tbody>';


While($myrow=DB_fetch_array($result)){
$sql="SELECT typeid FROM debtorsmaster WHERE debtorno LIKE '".$myrow['debtorno']."'";
$mercadoresult=DB_query($sql);
$tipocliente=DB_fetch_array($mercadoresult);
$Gen='Ver';
if($myrow['num']==$myrow['sin'] OR $_GET['estatus']=='sinorden'){
$myrow['estatus']='Sin iniciar';
$color='style="background-color:lightcoral"';
$Gen='Generar';
}
if($myrow['num']==$myrow['fin'] OR $_GET['estatus']=='finalizada'){
$myrow['estatus']='Finalizado';
$color='style="background-color:limegreen"';
}
if(($myrow['num']!=$myrow['fin'] AND $myrow['num']!=$myrow['sin'] AND $_GET['estatus']=='All' ) OR $_GET['estatus']=='proceso'){
$myrow['estatus']='En proceso';
$color='style="background-color:yellow"';
$Gen='Continuar';
}

$mercado='';
$colorm='';
if($tipocliente[0]=='18'){
$mercado='Sí';
$colorm='background-color:yellow';
}

echo		'<tr class="striped_row">
<td>'.$myrow['lote'].'</td>
<td>'.$myrow['debtorno'].'</td>
<td>'.$myrow['contacto'].'</td>
<td style="text-align:center">'.$myrow['num'].'</td>
<td>'.$myrow['fechacaptura'].'</td>
<td '.$color.'>'.$myrow['estatus'].'</td>
<td style="text-align:center;'.$colorm.'">'.$mercado.'</td>
<td ><a href="EnterWarranty.php?Print='.$myrow['lote'].'" target="_blank"> Imprimir </a></td>
<td ><a href="GeneracionOrdServicio.php?OrdLote='.$myrow['lote'].'" target="_self"> '.$Gen.' Orden(es) </a></td>
</tr>';
}
echo		'</tbody></table>';
}
if(isset($_GET['OrdLote'])){

echo	'<form action="' . htmlspecialchars($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8') . '?OrdLote='.$_GET['OrdLote'].'" method="post"><input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
if(isset($_POST['Generar'])){
$sql="SELECT OS FROM ordenesservicio ORDER BY OS DESC";
$result=DB_query($sql);
$ultimaord=DB_fetch_array($result);
$OS=$ultimaord[0]+1;
foreach ($_POST as $key => $value) {
		if (mb_strpos($key,'Selec')) {
		if($value!=''){
		$sql="UPDATE ordenesservicio SET OS='".$OS."', estatus='almacen',fechaOS='".date('Y-m-d H:i:s')."' WHERE id='".$value."'";
$result=DB_query($sql);
		$OS=$OS+1;
		}
		}
		}
		prnMsg('Se generaron las ordenes de servicio correctamente', 'success');
		}
		if(isset($_POST['Trasladar'])){
$sql="UPDATE ordenesservicio SET estatus='reparando' WHERE lote='".$_GET['OrdLote']."' ";
$result=DB_query($sql);
}
$sql="SELECT *,COUNT(CASE WHEN OS=0 THEN 1 ELSE NULL END) as faltan,COUNT(CASE WHEN estatus='almacen' THEN 1 ELSE NULL END) as almacen, COUNT(stockid) as todo, COUNT(CASE WHEN (tiporep IS NULL OR tiporep='') THEN NULL WHEN (estatus='reparando' AND tiporep='1') THEN NULL ELSE 1 END) as marcados FROM ordenesservicio WHERE lote='".$_GET['OrdLote']."' ORDER BY id ASC ";
$result=DB_query($sql);
$myrow=DB_fetch_array($result);

if(isset($_POST['Solicitar'])){
	$RequestNo = GetNextTransNo(38);
		$HeaderSQL="INSERT INTO stockrequest (dispatchid,
											loccode,
											departmentid,
											despatchdate,
											narrative,
											initiator)
										VALUES(
											'" . $RequestNo . "',
											'1',
											'15',
											'" . date('Y-m-d H:i:s') . "',
											'Para Lote de Servicio " . $_GET['OrdLote']. "',
											'" . $_SESSION['UserID'] . "')";
		$Result = DB_query($HeaderSQL);
		$sql="SELECT materialOS.stockid,SUM(materialOS.qty) as total,stockmaster.units,stockmaster.description,stockmaster.decimalplaces FROM ordenesservicio
INNER JOIN materialOS ON materialOS.OS=ordenesservicio.OS
INNER JOIN stockmaster ON stockmaster.stockid=materialOS.stockid 
WHERE ordenesservicio.lote='".$_GET['OrdLote']."' and materialOS.dispatchid IS NULL and (ordenesservicio.tiporep=1 or (ordenesservicio.tiporep=2 and remision!=''))  GROUP by materialOS.stockid ORDER BY materialOS.stockid ASC ";
$Resultadd=DB_query($sql);
$i=0;
while($myrowadd=DB_fetch_array($Resultadd)){
$LineSQL="INSERT INTO stockrequestitems (dispatchitemsid,
													dispatchid,
													stockid,
													quantity,
													decimalplaces,
													uom,
													solicitante)
												VALUES(
													'".$i."',
													'".$RequestNo."',
													'".$myrowadd['stockid']."',
													'".$myrowadd['total']."',
													'".$myrowadd['decimalplaces']."',
													'".$myrowadd['units']."',
													'LoteOS".$_GET['OrdLote']."')";
			$Result = DB_query($LineSQL);
			$i=$i+1;
}
$sql="UPDATE materialOS INNER JOIN ordenesservicio ON materialOS.OS=ordenesservicio.OS SET dispatchid='".$RequestNo."' WHERE ordenesservicio.lote='".$_GET['OrdLote']."' and materialOS.dispatchid IS NULL";
$update=DB_query($sql);

	$EmailSQL="SELECT email,userid
					FROM www_users, departments
					WHERE departments.authoriser = www_users.userid
						AND departments.departmentid = '15'";
		$EmailResult = DB_query($EmailSQL);
		
			if ($myEmail=DB_fetch_array($EmailResult)){
			$fp =fopen('LogFiles/'.$myEmail['userid'].'.txt','a');
			$fwrite = fwrite($fp,"\n");
			$fwrite = fwrite($fp,'|0| La requisición '.$RequestNo.' esta esperando tu autorización');
			fclose($fp);
			$ConfirmationText = 'La solicitud de requisición interna '.$RequestNo.' necesita  tu autorización';
			$EmailSubject = 'Esperando autorización para Requisición '.$RequestNo.' ';
			 if($_SESSION['SmtpSetting']==0){
			       mail($myEmail['email'],$EmailSubject,$ConfirmationText,'From:CEISA  <ceisa@spacpi.com>');
			}else{
				include('includes/htmlMimeMail.php');
				$mail = new htmlMimeMail();
				$mail->setSubject($EmailSubject);
				$mail->setText($ConfirmationText);
				$result = SendmailBySmtp($mail,array($myEmail['email'],'From:CEISA  <ceisa@spacpi.com>'));
			}
		}

}


$sql="SELECT materialOS.stockid,SUM(materialOS.qty) as total,stockmaster.units,stockmaster.description FROM ordenesservicio
INNER JOIN materialOS ON materialOS.OS=ordenesservicio.OS
INNER JOIN stockmaster ON stockmaster.stockid=materialOS.stockid 
WHERE ordenesservicio.lote='".$_GET['OrdLote']."' and materialOS.dispatchid IS NULL GROUP by materialOS.stockid ORDER BY materialOS.stockid ASC ";
$Result=DB_query($sql);
if (DB_num_rows($Result)!=0){
echo	'<table><tr>
<th colspan="4"> Material para reparaciones </th>
<th rowspan="2"><input style="background-color:lightblue;height:50px;font-size:medium;font-weight:bold"  type="submit" name="Solicitar" value="Solicitar material" onclick="return confirm(\'¿Está seguro de SOLICITAR el material ahora?, esto generará una Requisición \');" /></th>
</tr><tr>
<th> Componente </th>
<th> Descripción </th>
<th> Cantidad </th>
<th> Unidad </th>
</tr>';
while($myrowrequest=DB_fetch_array($Result)){
echo	'<tr class="striped_row">
<td>'.$myrowrequest['stockid'].' </td>
<td>'.$myrowrequest['description'].' </td>
<td>'.locale_number_format($myrowrequest['total'],2).' </td>
<td>'.$myrowrequest['units'].' </td>
</tr>';
}
echo	'</table></br>';
}




echo	'<table><thead><tr>
<th colspan="9">Contacto: '.$myrow['contacto'].' Código: '.$myrow['debtorno'];
if($myrow['marcados']==$myrow['todo']){
echo '<a href="GeneracionOrdServicio.php?Print=1&LoteOS='.$_GET['OrdLote'].'" target="_blank" >Imprimir Ordenes de Servicio y Cotizaciones</a></th></tr>';
}
if($myrow['marcados']!=$myrow['todo']){
echo '<span style="font-weight:bold;color:blue"> Avance del lote para poder imprimir ('.$myrow['marcados'].' / '.$myrow['todo'].')</span> </th></tr>';
}
echo '<tr><th>ID</th>
<th>Producto</th>
<th>Fecha de Grabado</th>
<th>Fecha de ingreso</th>
<th>Condición</th>
<th>Falla</th>
<th>Procede Garantía</th>
<th>Estatus</th>
<th>Orden</th>';
if($myrow['faltan']!=0){
 echo '<th><input style="background-color:limegreen"  type="submit" name="Generar" value="Generar Orden de Servicio" onclick="return confirm(\'¿Está seguro de GENERAR los consecutivos de OS? \');" /></th>';
}
elseif($myrow['faltan']==0 and $myrow['almacen']!=0 and in_array(23, $_SESSION['AllowedPageSecurityTokens'])){
 echo '<th><input style="background-color:lightsteelblue"  type="submit" name="Trasladar" value="Enviar a Reparación" onclick="return confirm(\'¿Está seguro de TRASLADAR el lote para reparación? \');" /></th>';
}
echo '</tr></thead><tbody>';



$sql="SELECT ordenesservicio.*,stockmaster.garantia,debtortrans.inputdate FROM ordenesservicio INNER JOIN stockmaster on stockmaster.stockid=ordenesservicio.stockid LEFT JOIN debtortrans  ON debtortrans.transno = ordenesservicio.transno WHERE lote='".$_GET['OrdLote']."' ORDER BY id ASC ";
$result=DB_query($sql);
While($myrow=DB_fetch_array($result)){
$garantia=no;
if(isset($myrow['fechagrabado'])){
$tiempo1=strtotime($myrow['fechagrabado']);
$tiempo2=(strtotime($myrow['fechacaptura'])-($tiempo1));
$tiempo3=(($tiempo2)/31536000);
if($tiempo3<=$myrow['garantia']){
$garantia=si;
}
}

if(isset($myrow['transno'])){
$tiempo1=strtotime($myrow['inputdate']);
$tiempo2=strtotime($myrow['fechacaptura'])-$tiempo1;
$tiempo3=(($tiempo2)/31536000);
if($tiempo3<=$myrow['garantia']){
$garantia=si;
}
}
if(isset($myrow['fechacompra'])){
$tiempo1=strtotime($myrow['fechacompra']);
$tiempo2=strtotime($myrow['fechacaptura'])-$tiempo1;
$tiempo3=(($tiempo2)/31536000);
if($tiempo3<=$myrow['garantia']){
$garantia=si;
}
}
if($garantia==si){
$color='limegreen';
}
if($garantia==no){
$color='lightcoral';
}



echo		'<tr class="striped_row">
<td>'.$myrow['id'].'</td>
<td>'.$myrow['stockid'].'</td>
<td>'.$myrow['fechagrabado'].'</td>
<td>'.$myrow['fechacaptura'].'</td>
<td>'.$myrow['condicion'].'</td>
<td>'.$myrow['falla'].'</td>
<td class="centre" style="background-color:'.$color.'">'.$garantia.'</td>
<td>'.$myrow['estatus'].'</td>';
if($myrow['OS']!=0 and $myrow['estatus']=='almacen' ){
echo '<td>'.$myrow['OS'].'</td>';
}
if($myrow['OS']!=0 and $myrow['estatus']!='almacen' ){
$estatus=' PENDIENTE ';
if($myrow['tiporep']==1 and $myrow['estatus']!='almacen' and $myrow['estatus']!='reparando'){
$estatus=' Orden Lista ';
}
if($myrow['tiporep']==2 and $myrow['estatus']=='reparando'){
$estatus=' Cotización Lista ';
}
if($myrow['tiporep']==2 and $myrow['estatus']!='almacen' and $myrow['estatus']!='reparando' ){
$estatus=' Orden Lista ';
}


echo '<td><a href="GeneracionOrdServicio.php?Servicio='.$myrow['OS'].'">'.$myrow['OS'].' '.$estatus.' </a></td>';
}
if($myrow['OS']==0 and $garantia==si){
echo '<td><input type="checkbox" checked="checked" name="'.$myrow['id'].'Selec" value="'.$myrow['id'].'" /></td>';
}
if($myrow['OS']==0 and $garantia==no){
echo '<td><input type="checkbox" name="'.$myrow['id'].'Selec" value="'.$myrow['id'].'" /></td>';
}

echo '</tr>';

}
echo		'</tbody></table>';
echo	'</form>';
}
if(isset($_GET['Servicio'])){
echo	'<form action="' . htmlspecialchars($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8') . '?Servicio='.$_GET['Servicio'].'" method="post"><input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
if(isset($_POST['Actualizar']) or isset($_POST['Reparar'])  ){
$sql="UPDATE ordenesservicio SET diagnostico='".$_POST['Diagnostico']."',reparacion='".$_POST['Reparacion']."',tiporep='".$_POST['Tiporep']."',remision='".$_POST['Remision']."' WHERE OS='".$_GET['Servicio']."'";
$result=DB_query($sql);
}
if(isset($_POST['Reparar'])){
$sql="SELECT * FROM ordenesservicio WHERE OS='".$_GET['Servicio']."'";
$result=DB_query($sql);
$myrow2=DB_fetch_array($result);


$sql="SELECT * FROM debtortrans WHERE transno='".$myrow2['remision']."' and type='10' ";
$resultrem=DB_query($sql);
$minerror=0;
if (DB_num_rows($resultrem)==0 and $myrow2['tiporep']==2){
prnMsg('Ese número de remisión es incorrecto', 'error');
$minerror=1;
}
if($myrow2['reparacion']=='' OR $myrow2['tiporep']=='' ){
prnMsg('Es necesario describir la reparación y su tipo', 'error');
$minerror=1;
}
if($minerror!=1 ){
$sql="UPDATE ordenesservicio SET estatus='reparado', reparador='".$_SESSION['UserID']."' WHERE OS='".$_GET['Servicio']."'";
$result=DB_query($sql);
prnMsg('Se ha marcado como reparado exitosamente, ya puede imprimir la orden de servicio', 'success');
}
}


$sql="SELECT ordenesservicio.*,stockmaster.garantia,debtortrans.inputdate FROM ordenesservicio INNER JOIN stockmaster on stockmaster.stockid=ordenesservicio.stockid LEFT JOIN debtortrans  ON debtortrans.transno = ordenesservicio.transno WHERE OS='".$_GET['Servicio']."'";
$result=DB_query($sql);
$myrow=DB_fetch_array($result);
$_POST['Diagnostico']=$myrow['diagnostico'];
$_POST['Reparacion']=$myrow['reparacion'];
$_POST['Tiporep']=$myrow['tiporep'];
$_POST['Remision']=$myrow['remision'];
echo '<a href="GeneracionOrdServicio.php?OrdLote='.$myrow['lote'].'" style="font-size:15px;">Regresar al lote</a>';
echo '<div class="centre" style="font-size:30px;font-weight:bold">Diagnóstico y Requisición Orden de Servicio No. '.$_GET['Servicio'].'</div>';
echo '<div class="centre" style="font-size:60px;font-weight:bold">'.$myrow['stockid'];

if($myrow['estatus']=='reparado'){
$disabled='disabled';
}

$garantia=No;
$warranty=0;
if(isset($myrow['fechagrabado'])){
$tiempo1=strtotime($myrow['fechagrabado']);
$tiempo2=(strtotime($myrow['fechacaptura'])-($tiempo1));
$tiempo3=(($tiempo2)/31536000);
if($tiempo3<=$myrow['garantia']){
$garantia=Sí;
$warranty=1;
}
}

if(isset($myrow['transno'])){
$tiempo1=strtotime($myrow['inputdate']);
$tiempo2=strtotime($myrow['fechacaptura'])-$tiempo1;
$tiempo3=(($tiempo2)/31536000);
if($tiempo3<=$myrow['garantia']){
$garantia=Sí;
$warranty=1;
}
}
if(isset($myrow['fechacompra'])){
$tiempo1=strtotime($myrow['fechacompra']);
$tiempo2=strtotime($myrow['fechacaptura'])-$tiempo1;
$tiempo3=(($tiempo2)/31536000);
if($tiempo3<=$myrow['garantia']){
$garantia=Sí;
$warranty=1;
}
}
$costado='';
if($_POST['Diagnostico']!=''){
$na='';
$sin='';
$con='';
if($_POST['Tiporep']==''){
$na=' selected="selected" ';
}
if($_POST['Tiporep']=='1'){
$sin=' selected="selected" ';
}
if($_POST['Tiporep']=='2'){
$con=' selected="selected" ';
$costado=' </br> Remisión:<input type="tel" name="Remision" value="'.$_POST['Remision'].'" />';
}
echo '</br><span style="font-size:15px;">&nbsp; Tipo :<select '.$disabled.' name="Tiporep" >
		<option value="" '.$na.' >Sin definir</option >
		<option value="1" '.$sin.' >Sin costo</option >
		<option value="2" '.$con.' >Con costo</option >
		</select> Garantía Válida: '.$garantia.' '.$costado.'</span>';
}

echo '</div>';

if($_POST['Diagnostico']==NULL){
echo 'Diagnóstico: <div class="centre"><textarea tabindex="10" required="required" type="text" name="Diagnostico" placeholder="Plasmar diagnóstico"  rows="4" cols="80"></textarea></br>
<input type="submit" name="Actualizar" value="Actualizar" /></div>';
}
if($_POST['Diagnostico']!=''){
if(isset($_POST['Añadir']) and $_POST['QtyComponente']==0  ){
prnMsg('No ingresó cantidad correcta del componente a añadir', 'error');
}
if(isset($_POST['Añadir']) and $_POST['Componente']=='' ){
prnMsg('No ingresó componente a añadir', 'error');
}
if(isset($_POST['Añadir']) and $_POST['QtyComponente']!=0 and $_POST['Componente']!='' ){
$sql="SELECT * FROM stockmaster WHERE stockid='".$_POST['Componente']."'";
$resultcheck=DB_query($sql);
if (DB_num_rows($resultcheck)==0){
prnMsg('No existe ese componente, verifiquelo ', 'error');
}
else{
$_POST['Componente']=strtoupper($_POST['Componente']);
$sql="SELECT stockid,qty FROM materialOS where OS='".$_GET['Servicio']."' and stockid='".$_POST['Componente']."' and dispatchid IS NULL";
$resultcheck2=DB_query($sql);
$rowcheck2=DB_fetch_array($resultcheck2);
if (!isset($rowcheck2['stockid'])){
if ($_POST['QtyComponente']<0){
prnMsg('No hay material a pedir por descontar', 'error');
}
else{
$sql="INSERT INTO materialOS (OS,
								 		stockid,
								 		qty)
								 		VALUES(
								 		'".$_GET['Servicio']."',
								 		'".$_POST['Componente']."',
								 		'".$_POST['QtyComponente']."')";
$resultupdate=DB_query($sql);
}
}
else{
if (($rowcheck2['qty']+$_POST['QtyComponente'])<0){
prnMsg('Está intentado descontar material de más', 'error');
}
if (($rowcheck2['qty']+$_POST['QtyComponente'])==0){
$sql="DELETE FROM materialOS WHERE OS='".$_GET['Servicio']."' and stockid='".$_POST['Componente']."' and dispatchid IS NULL";
$resultupdate=DB_query($sql);
}
if (($rowcheck2['qty']+$_POST['QtyComponente'])>0){
$sql="UPDATE materialOS SET qty=(qty+".$_POST['QtyComponente'].") WHERE OS='".$_GET['Servicio']."' and stockid='".$_POST['Componente']."' and dispatchid IS NULL";
$resultupdate=DB_query($sql);
}
}
}


unset($_POST['QtyComponente']);
unset($_POST['Componente']);
}

if(!isset($_POST['QtyComponente'])){
$_POST['QtyComponente']=0;
}

echo 'Diagnóstico: <div class="centre"><textarea tabindex="10" required="required" '.$disabled.' type="text" name="Diagnostico" placeholder="Plasmar diagnóstico"  rows="4" cols="80">'.$_POST['Diagnostico'].'</textarea></br>
Reparación:</br><textarea '.$disabled.' tabindex="10" type="text" name="Reparacion" placeholder="Explicar Reparacion"  rows="4" cols="80">'.$_POST['Reparacion'].'</textarea></br>
<input type="submit" name="Actualizar" value="Actualizar" '.$disabled.' />';
if($disabled!='disabled'){
echo '<input type="submit"  style="background-color:lightblue" name="Reparar" value="Marcar como Reparado" onclick="return confirm(\'Esto terminará la orden de servicio, siendo imposible editarla, ¿Desea continuar? \');" />';
}
if($disabled=='disabled'){
echo '<span class="centre" style="background-color:lightblue"> Reparado</span>';
}
echo '<input type="hidden" name="Warranty" value="'.$warranty.'" /></div>';
echo '<table>';
echo '<tr>
<td><input type="text" name="Componente" placeholder="Nuevo Componente" value="'.$_POST['Componente'].'" /></td>
<td><input type="tel" name="QtyComponente" value="'.$_POST['QtyComponente'].'" /><input type="submit" name="Añadir" value="Añadir" '.$disabled.' /></td>
</tr><tr>
<th>Parte</th>
<th>Descripción</th>
<th>Pedidos</th>
<th>Por pedir</th>
<th>Total</th>
<th>Unidad</th>
</tr>';
$sql="SELECT materialOS.stockid, cantidades.suma,cantidades2.pedidos, stockmaster.description, stockmaster.units
FROM ordenesservicio
INNER JOIN materialOS ON materialOS.OS = ordenesservicio.OS
INNER JOIN stockmaster ON materialOS.stockid = stockmaster.stockid
LEFT JOIN (
SELECT SUM( qty ) AS suma, stockid
FROM materialOS
WHERE OS =  '".$_GET['Servicio']."'
GROUP BY stockid
) AS cantidades ON cantidades.stockid = materialOS.stockid
LEFT JOIN (
SELECT SUM( qty ) AS pedidos, stockid
FROM materialOS
WHERE OS =  '".$_GET['Servicio']."'
AND dispatchid IS NOT NULL
GROUP BY stockid
) AS cantidades2 ON cantidades2.stockid = materialOS.stockid
WHERE ordenesservicio.stockid =  '".$myrow['stockid']."'
GROUP BY materialOS.stockid
ORDER BY suma DESC,stockid ASC
";
$result=DB_query($sql);

while($myrow=DB_fetch_array($result)){
echo '<tr class="striped_row">
<td>'.$myrow['stockid'].'</td>
<td>'.$myrow['description'].'</td>
<td>'.locale_number_format($myrow['pedidos'],2).'</td>
<td>'.locale_number_format($myrow['suma']-$myrow['pedidos'],2).'</td>
<td>'.locale_number_format($myrow['suma'],2).'</td>
<td>'.$myrow['units'].'</td>
</tr>';
}

}
echo	'</table></form>';
}
/////////////////////////////////////////////////////////////////IMPRIMIR
if(isset($_GET['Print']) and isset($_GET['LoteOS'])){
echo '<div style="size:8.5in 11in">';
$sql = "SELECT coyname,
					gstno,
					companynumber,
					regoffice1,
					regoffice2,
					regoffice3,
					regoffice4,
					regoffice5,
					regoffice6,
					telephone,
					fax,
					email,
					currencydefault,
					debtorsact,
					pytdiscountact,
					creditorsact,
					payrollact,
					grnact,
					exchangediffact,
					purchasesexchangediffact,
					retainedearnings,
					gllink_debtors,
					gllink_creditors,
					gllink_stock,
					freightact
				FROM companies
				WHERE coycode=1";
				$resultcomp=DB_query($sql);
				$myrowcomp=DB_fetch_array($resultcomp);
$sqlprint="SELECT * FROM ordenesservicio WHERE lote='".$_GET['LoteOS']."' and tiporep IS NOT NULL AND tiporep<>'' GROUP BY lote ORDER BY OS ASC ";
$resultprint=DB_query($sqlprint);
if (DB_num_rows($resultprint)==0){
echo 'Aún no hay órdenes de servicio listas para imprimir en este lote';
}

while($printrow=DB_fetch_array($resultprint)){

$sqlnota="SELECT ordenesservicio.*,stockmaster.garantia, stockmaster.description FROM ordenesservicio INNER JOIN stockmaster on stockmaster.stockid=ordenesservicio.stockid WHERE lote='".$_GET['LoteOS']."' and tiporep='1' and estatus!='reparando' ORDER BY OS ASC";
$resultnota=DB_query($sqlnota);
if (DB_num_rows($resultnota) !=0){

$sqlmaxmin="SELECT max(OS) as max, min(OS) as min, COUNT(stockid) as todos FROM ordenesservicio WHERE lote='".$_GET['LoteOS']."' and tiporep='1' and estatus!='reparando' ORDER BY OS ASC";
$resultmaxmin=DB_query($sqlmaxmin);
$myrowmaxmin=DB_fetch_array($resultmaxmin);
if($myrowmaxmin['min']==$myrowmaxmin['max']){
$myrowmaxmin['max']='';
}
else{
$myrowmaxmin['max']='-'.$myrowmaxmin['max'];
}
echo '<table style="border: solid black 1px;border-collapse:collapse;page-break-after: always;margin-left:1%;width:95%" class="centre" ><thead>';
	echo '
		<tr style="border-style:hidden">

			<th colspan="6" style="font-size:15px;text-align:left;background-image:url('. $RootPath . '/' . $_SESSION['LogoFile'] . ');background-repeat: no-repeat;background-position: left;background-size:240px;" >
			<span style="float:right;"><span style="font-weight:normal;font-size:12px">'.$myrowcomp[0].'</br>'.$myrowcomp['regoffice1'].' '.$myrowcomp['regoffice2'].'</br>'.$myrowcomp['regoffice4'].','.$myrowcomp['regoffice6'].' Tel. '.$myrowcomp['telephone'].'</br> www.ceisa.com.mx '.$myrowcomp['email'].'</span></span>
</th>
		</tr>
		<tr style="border-style:hidden">
			<th colspan="6" style="font-size:20px;text-align:center;color:blue"> Orden de Servicio </th>
		</tr>
<tr style="border-style:hidden"><th colspan="6" style="font-size:10px;text-align:left;color:black"></br>Ciudad de México<span style="float:right;text-align:right">N° Orden: 
<span style="font-weight:normal">'.$myrowmaxmin['min'].''.$myrowmaxmin['max'].'</span></span></br> Fecha y hora :  <span style="font-weight:normal">'.$printrow['fechaOS'].'</span>
<span style="float:right;text-align:right">N°Artículos : <span style="font-weight:normal">'.$myrowmaxmin['todos'].' Pz</span></span>
 </br> Código: <span style="font-weight:normal">'.$printrow['debtorno'].'</span></br> Nombre o Razón Social: <span style="font-weight:normal">'.$printrow['contacto'].'</span> </br>
Domicilio: <span style="font-weight:normal">'.$printrow['direccion'].'</span></br>
Tel: <span style="font-weight:normal">'.$printrow['phoneno'].'</span> Correo: <span style="font-weight:normal">'.$printrow['email'].'</span></th></tr>';



	echo	'<tr style="border-bottom:solid black 1px;border-collapse:collapse;border-left:hidden;border-right:hidden;"><th colspan="4" style="font-size:15px;text-align:center;color:blue;border-bottom:solid black 1px;border-collapse:collapse;"></br></th></tr>';

		echo '<tr style="border: solid black 1px">
		<th  style="border: solid black 1px;border-collapse:collapse;text-align:center">N° Orden</th>
			<th  style="border: solid black 1px;border-collapse:collapse;text-align:center">Código</th>
			<th  style="border: solid black 1px;border-collapse:collapse;text-align:center">Descripción</th>
						<th  style="border: solid black 1px;border-collapse:collapse;text-align:center;padding:8px">Grabado</th>
						<th  style="border: solid black 1px;border-collapse:collapse;text-align:center;padding:2px">Años</br>Garantía</th>
<th  style="border: solid black 1px;border-collapse:collapse;text-align:center;padding:8px">Garantía</th>
		</tr></thead><tbody>';
		
while($notarow=DB_fetch_array($resultnota)){
echo '<tr style="border: solid black 1px;border-collapse:collapse;font-size:10px">
	<td style="border: solid black 1px;border-collapse:collapse;text-align:center;padding-left:8px;padding-right:8px" >'.$notarow['OS'].'</td>
	<td style="border: solid black 1px;border-collapse:collapse;text-align:center;padding-left:8px;padding-right:8px" >'.$notarow['stockid'].'</td>
	<td style="border: solid black 1px;border-collapse:collapse;text-align:justify;padding-left:8px;padding-right:8px">'.$notarow['description'].'</td>
		<td style="border: solid black 1px;border-collapse:collapse;text-align:center">'.$notarow['fechagrabado'].'</td>
				<td style="border: solid black 1px;border-collapse:collapse;text-align:center">'.$notarow['garantia'].'</td>
<td style="border: solid black 1px;border-collapse:collapse;text-align:center">Sí</td>
		</tr>
		<tr style="border: solid black 1px;border-collapse:collapse;font-size:10px">
	<td colspan="6" style="border: solid black 1px;border-collapse:collapse;text-align:left;padding-left:8px;padding-right:8px" >
	<span style="font-weight:bold">Condición:</span>'.$notarow['condicion'].'</br>
	<span style="font-weight:bold">Diagnóstico:</span>'.$notarow['diagnostico'].'</br>
	<span style="font-weight:bold">Reparación:</span>'.$notarow['reparacion'].'</br>
	<span style="font-weight:bold">Reparado por :</span> '.$notarow['reparador'].'</td>
		</tr>';	
}
 echo '</tbody> <tfoot>
<tr style="border: solid black 1px;border-collapse:collapse;">
<td style="border: solid black 1px;border-collapse:collapse;text-align:justify;color:blue;font-size:11px" colspan="6" >
	</br><div style="font-size:15px;color:black;margin-left:20%">Recibido por</div>
	<div style="font-size:15px;color:black;text-align:center">Firma:__________________________________ </br>'.$printrow['brname'].'</div></td>
		</tr></tfoot></table>';
}
$sqlvale="SELECT ordenesservicio.*,stockmaster.garantia, stockmaster.description FROM ordenesservicio INNER JOIN stockmaster on stockmaster.stockid=ordenesservicio.stockid WHERE lote='".$_GET['LoteOS']."' and tiporep='2' and lote and estatus!='reparando' ORDER BY OS ASC";
$resultvale=DB_query($sqlvale);
if (DB_num_rows($resultvale) !=0){
$sqlmaxmin="SELECT max(OS) as max, min(OS) as min FROM ordenesservicio WHERE lote='".$_GET['LoteOS']."' and tiporep='2' and estatus!='reparando' ORDER BY OS ASC";
$resultmaxmin=DB_query($sqlmaxmin);
$myrowmaxmin=DB_fetch_array($resultmaxmin);
if($myrowmaxmin['min']==$myrowmaxmin['max']){
$myrowmaxmin['max']='';
}
else{
$myrowmaxmin['max']='-'.$myrowmaxmin['max'];
}
echo '<table style="border: solid black 1px;border-collapse:collapse;page-break-after: always;margin-left:1%;width:95%" class="centre" ><thead>';
	echo '
		<tr style="border-style:hidden">

			<th colspan="6" style="font-size:1px;text-align:left;background-image:url('. $RootPath . '/' . $_SESSION['LogoFile'] . ');background-repeat: no-repeat;background-position: left;background-size:240px;" >
			<span style="float:right;"><span style="font-weight:normal;font-size:12px">'.$myrowcomp[0].'</br>'.$myrowcomp['regoffice1'].' '.$myrowcomp['regoffice2'].'</br>'.$myrowcomp['regoffice4'].','.$myrowcomp['regoffice6'].' Tel. '.$myrowcomp['telephone'].'</br> www.ceisa.com.mx '.$myrowcomp['email'].'</span></span>
</th>
		</tr>
		<tr style="border-style:hidden">
			<th colspan="6" style="font-size:20px;text-align:center;color:blue"> Orden de Servicio </th>
		</tr>
<tr style="border-style:hidden"><th colspan="6" style="font-size:10px;text-align:left;color:black"></br>Ciudad de México<span style="float:right;text-align:right">N° Orden: 
<span style="font-weight:normal">'.$myrowmaxmin['min'].''.$myrowmaxmin['max'].'</span></span></br> Fecha y hora :  <span style="font-weight:normal">'.$printrow['fechaOS'].'</span>
<span style="float:right;text-align:right">N°Artículos : <span style="font-weight:normal">'.$myrowmaxmin['todos'].' Pz</span></span>
 </br> Código: <span style="font-weight:normal">'.$printrow['debtorno'].'</span></br> Nombre o Razón Social: <span style="font-weight:normal">'.$printrow['contacto'].'</span> </br>
Domicilio: <span style="font-weight:normal">'.$printrow['direccion'].'</span></br>
Tel: <span style="font-weight:normal">'.$printrow['phoneno'].'</span> Correo: <span style="font-weight:normal">'.$printrow['email'].'</span></th></tr>';



	echo	'<tr style="border-bottom:solid black 1px;border-collapse:collapse;border-left:hidden;border-right:hidden;"><th colspan="4" style="font-size:15px;text-align:center;color:blue;border-bottom:solid black 1px;border-collapse:collapse;"></br></th></tr>';

		echo '<tr style="border: solid black 1px">
			<th  style="border: solid black 1px;border-collapse:collapse;">Código</th>
			<th  style="border: solid black 1px;border-collapse:collapse;text-align:center">Descripción</th>
						<th  style="border: solid black 1px;border-collapse:collapse;text-align:center">Cantidad</th>
												<th  style="border: solid black 1px;border-collapse:collapse;text-align:center">Unidad</th>
						<th  style="border: solid black 1px;border-collapse:collapse;text-align:center">Precio unitario</th>
						<th  style="border: solid black 1px;border-collapse:collapse;text-align:center">Importe</th>	
		</tr></thead><tbody>';
		$acum=0;
while($valerow=DB_fetch_array($resultvale)){
if($valerow['estatus']!='reparando'){
$sqlprecio="SELECT * FROM prices WHERE stockid='".$valerow['stockid']."' AND typeabbrev='D'";
$resultprecio=DB_query($sqlprecio);
$precio=DB_fetch_array($resultprecio);
if (isset($precio['price']) AND $precio['price']!=0){
$valerow['materialcost']=$precio['price'];
}
$preciotot=$valerow['materialcost']*$valerow['qtydelivered'];
$acum+=$preciotot;
echo '<tr style="border: solid black 1px;border-collapse:collapse;font-size:10px">
	<td style="border: solid black 1px;border-collapse:collapse;text-align:center;" >'.$valerow['stockid'].'</td>
	<td style="border: solid black 1px;border-collapse:collapse;text-align:justify">'.$valerow['description'].'</td>
		<td style="border: solid black 1px;border-collapse:collapse;text-align:center">'.$valerow['qtydelivered'].'</td>
				<td style="border: solid black 1px;border-collapse:collapse;text-align:center">'.$valerow['uom'].'</td>
		<td style="border: solid black 1px;border-collapse:collapse;text-align:center"> '.locale_number_format($valerow['materialcost'],2).' </td>
		<td style="border: solid black 1px;border-collapse:collapse;text-align:center">'.locale_number_format($preciotot,2).'</td>

		</tr>';	
		}
}
  echo '</tbody> <tfoot>
  <tr style="border: solid black 1px;border-collapse:collapse;">
<td style="border: solid black 1px;border-collapse:collapse;text-align:justify;" colspan="4" ></br></br></br></td><td style="border: solid black 1px;border-collapse:collapse;text-align:center;" colspan="2" >TOTAL S/IVA:  <span style="float:right">'.locale_number_format($acum,2).' MXN</span></td>
		</tr>
   <tr style="border: solid black 1px;border-collapse:collapse;">
<td style="border: solid black 1px;border-collapse:collapse;text-align:left;font-weight:bold" colspan="6" >Destino de la mercancía:</br><span style="font-size:15px;color:black;text-align:center;font-weight:normal">'.$printrow['narrative'].'</span></br></br></td>
		</tr>
<tr style="border: solid black 1px;border-collapse:collapse;">
	<td style="border: solid black 1px;border-collapse:collapse;text-align:justify;color:blue;font-size:11px" colspan="6" >
	Debo y pagaré incondicionalmente a la orden del Titular la cantidad de $'.locale_number_format($acum,2).' MXN mas IVA en caso de que las mercancías mencionadas en este documento no hayan sido devueltas al Titular a la fecha de vencimiento
	de este documento, causando intereses moratorios al tipo de ___________% mensual.
	</br><div style="font-size:15px;color:black;text-align:cente;margin-left:29%">Acepto</div>
	<div style="font-size:15px;color:black;text-align:center">Firma:__________________________________ </br>'.$printrow['brname'].'</div></td>
		</tr></tfoot></table>';
		
}
$sqlvale="SELECT ordenesservicio.*,stockmaster.garantia, stockmaster.description FROM ordenesservicio INNER JOIN stockmaster on stockmaster.stockid=ordenesservicio.stockid WHERE lote='".$_GET['LoteOS']."' and tiporep='2' and lote and estatus='reparando' ORDER BY OS ASC";
$resultvale=DB_query($sqlvale);
if (DB_num_rows($resultvale) !=0){
$sqlmaxmin="SELECT max(OS) as max, min(OS) as min FROM ordenesservicio WHERE lote='".$_GET['LoteOS']."' and tiporep='2' and estatus='reparando' ORDER BY OS ASC";
$resultmaxmin=DB_query($sqlmaxmin);
$myrowmaxmin=DB_fetch_array($resultmaxmin);
if($myrowmaxmin['min']==$myrowmaxmin['max']){
$myrowmaxmin['max']='';
}
else{
$myrowmaxmin['max']='-'.$myrowmaxmin['max'];
}
echo '<table style="border: solid black 1px;border-collapse:collapse;page-break-after: always;margin-left:1%;width:95%" class="centre" ><thead>';
	echo '
		<tr style="border-style:hidden">

			<th colspan="6" style="font-size:1px;text-align:left;background-image:url('. $RootPath . '/' . $_SESSION['LogoFile'] . ');background-repeat: no-repeat;background-position: left;background-size:240px;" >
			<span style="float:right;"><span style="font-weight:normal;font-size:12px">'.$myrowcomp[0].'</br>'.$myrowcomp['regoffice1'].' '.$myrowcomp['regoffice2'].'</br>'.$myrowcomp['regoffice4'].','.$myrowcomp['regoffice6'].' Tel. '.$myrowcomp['telephone'].'</br> www.ceisa.com.mx '.$myrowcomp['email'].'</span></span>
</th>
		</tr>
		<tr style="border-style:hidden">
			<th colspan="6" style="font-size:20px;text-align:center;color:blue"> Cotización de reparación </th>
		</tr>
<tr style="border-style:hidden"><th colspan="6" style="font-size:10px;text-align:left;color:black"></br>Ciudad de México<span style="float:right;text-align:right">N° Orden: 
<span style="font-weight:normal">'.$myrowmaxmin['min'].''.$myrowmaxmin['max'].'</span></span></br> Fecha y hora :  <span style="font-weight:normal">'.$printrow['fechaOS'].'</span>
<span style="float:right;text-align:right">N°Artículos : <span style="font-weight:normal">'.$myrowmaxmin['todos'].' Pz</span></span>
 </br> Código: <span style="font-weight:normal">'.$printrow['debtorno'].'</span></br> Nombre o Razón Social: <span style="font-weight:normal">'.$printrow['contacto'].'</span> </br>
Domicilio: <span style="font-weight:normal">'.$printrow['direccion'].'</span></br>
Tel: <span style="font-weight:normal">'.$printrow['phoneno'].'</span> Correo: <span style="font-weight:normal">'.$printrow['email'].'</span></th></tr>';



	echo	'<tr style="border-bottom:solid black 1px;border-collapse:collapse;border-left:hidden;border-right:hidden;"><th colspan="4" style="font-size:15px;text-align:center;color:blue;border-bottom:solid black 1px;border-collapse:collapse;"></br></th></tr>';

		echo '<tr style="border: solid black 1px">
			<th  style="border: solid black 1px;border-collapse:collapse;">Código</th>
			<th  style="border: solid black 1px;border-collapse:collapse;text-align:center">Descripción</th>
						<th  style="border: solid black 1px;border-collapse:collapse;text-align:center">Costo de reparación</th>
			</tr></thead><tbody>';
		$acum=0;
while($valerow=DB_fetch_array($resultvale)){

$sqlprecio="SELECT * FROM prices WHERE stockid='".$valerow['stockid']."' AND typeabbrev='D'";
$resultprecio=DB_query($sqlprecio);
$precio=DB_fetch_array($resultprecio);
if (isset($precio['price']) AND $precio['price']!=0){
$valerow['materialcost']=$precio['price'];
}
$preciotot=$valerow['materialcost']*$valerow['qtydelivered'];
$acum+=$preciotot;
echo '<tr style="border: solid black 1px;border-collapse:collapse;font-size:10px">
	<td style="border: solid black 1px;border-collapse:collapse;text-align:center;" >'.$valerow['stockid'].'</td>
	<td style="border: solid black 1px;border-collapse:collapse;text-align:justify">'.$valerow['description'].'</td>
		<td style="border: solid black 1px;border-collapse:collapse;text-align:center"></td>
		</tr>';	
		
}
  echo '</tbody> <tfoot>
  <tr style="border: solid black 1px;border-collapse:collapse;">
<td style="border: solid black 1px;border-collapse:collapse;text-align:justify;" colspan="2" ></br></br></br></td><td style="border: solid black 1px;border-collapse:collapse;text-align:center;" colspan="2" >TOTAL S/IVA:  <span style="float:right">'.locale_number_format($acum,2).' MXN</span></td>
		</tr>
   <tr style="border: solid black 1px;border-collapse:collapse;">
<td style="border: solid black 1px;border-collapse:collapse;text-align:left;font-weight:bold" colspan="6" >Destino de la mercancía:</br><span style="font-size:15px;color:black;text-align:center;font-weight:normal">'.$printrow['narrative'].'</span></br></br></td>
		</tr>
<tr style="border: solid black 1px;border-collapse:collapse;">
	<td style="border: solid black 1px;border-collapse:collapse;text-align:justify;color:blue;font-size:11px" colspan="6" >
	Debo y pagaré incondicionalmente a la orden del Titular la cantidad de $'.locale_number_format($acum,2).' MXN mas IVA en caso de que las mercancías mencionadas en este documento no hayan sido devueltas al Titular a la fecha de vencimiento
	de este documento, causando intereses moratorios al tipo de ___________% mensual.
	</br><div style="font-size:15px;color:black;text-align:cente;margin-left:29%">Acepto</div>
	<div style="font-size:15px;color:black;text-align:center">Firma:__________________________________ </br>'.$printrow['brname'].'</div></td>
		</tr></tfoot></table>';
		
}
}
}

/////////////////////IMPRIMIR




include('includes/footer.php');
?>