<?php
include('includes/session.php');



	$Title = _('Lista de consumos promedio');
	$ViewTopic = 'ConsumosPromedio';// Filename in ManualContents.php's TOC.
	$BookMark = 'PrintConsume';// Anchor's id in the manual's html document.
	include('includes/header.php');
	include('includes/SQL_CommonFunctions.inc');




$CurrentPeriod = GetPeriod(Date($_SESSION['DefaultDateFormat']));
$CurrentPeriod=$CurrentPeriod-2;	
$minusperiod=$CurrentPeriod-11;
$sql="SELECT stockmoves.stockid, SUM(CASE WHEN (stockmoves.type=10 OR stockmoves.type=11 OR stockmoves.type=17 OR stockmoves.type=28 OR stockmoves.type=38)

							AND stockmoves.hidemovt=0

						THEN -stockmoves.qty ELSE 0 END)/12 AS qtyused, stockcategory.categorydescription,stockmaster.description

				FROM stockmoves INNER JOIN stockmaster ON stockmaster.stockid=stockmoves.stockid INNER JOIN stockcategory on stockcategory.categoryid=stockmaster.categoryid
				WHERE stockmoves.prd BETWEEN ".$minusperiod." AND ".$CurrentPeriod."

				GROUP BY stockmoves.stockid

				ORDER BY qtyused DESC";
$result=DB_query($sql);					

echo '<table class="selection"><thead>
		<tr>
			<th>' . _('No') . '</th>
		   <th>' . _('StockId') . '</th>
		   <th>' . _('Description') . '</th>
			<th class="ascending">' . _('Uso Promedio 12 meses') . '</th>
			<th class="ascending">' . _('Uso último mes') . '</th>
			<th class="ascending">' . _('T. Orden a Recepción') . '</th>
			<th class="ascending">' . _('Punto Reorden Ceisa') . '</th>
			<th class="ascending">' . _('Reorden Calculado') . '</th>
			<th class="ascending">' . _('Categoría') . '</th>

			</tr></thead><tbody>';
$i=1;
$CurrentPeriod=$CurrentPeriod+1;
while ($myrow = DB_fetch_array($result)) {

$SQL = "SELECT purchorders.orddate, purchorders.orderno
FROM purchorders
INNER JOIN purchorderdetails ON purchorders.orderno = purchorderdetails.orderno
INNER JOIN suppliers ON purchorders.supplierno = suppliers.supplierid
INNER JOIN currencies ON suppliers.currcode = currencies.currabrev
WHERE purchorderdetails.itemcode =  '".$myrow[0]."'
AND purchorders.status =  'Completed'
GROUP BY purchorders.orderno, suppliers.suppname, purchorders.orddate, purchorders.initiator, purchorders.requisitionno, purchorders.allowprint, suppliers.currcode, currencies.decimalplaces
ORDER BY purchorders.orddate DESC ";
$resulting=DB_query($SQL);
$myrowing=DB_fetch_array($resulting);
$fechaorden=strtotime($myrowing[0]);
$SQL = "SELECT trandate from stockmoves where type='25' AND stockid='".$myrow[0]."' and reference like '%".$myrowing[1]."%'";
$resulting=DB_query($SQL);
$myrowing=DB_fetch_array($resulting);
$fecharecep=strtotime($myrowing[0]);
if($tiempoprov>17000){$tiempoprov='-100';}
$tiempoprov=($fecharecep-$fechaorden)/86400;
$tiempoprov=locale_number_format($tiempoprov,0).' días';
if(!isset($myrowing[0])){

$sqlord="SELECT workorders.requiredby,workorders.wo
FROM workorders
INNER JOIN woitems ON woitems.wo = workorders.wo
WHERE workorders.closed =  '1'
AND woitems.stockid =  '".$myrow[0]."'
ORDER BY workorders.requiredby DESC ";
$resultord=DB_query($sqlord);
$myroword=DB_fetch_array($resultord);
$fechaorden=strtotime($myroword[0]);
$sqlord="SELECT trandate from stockmoves where type='26' AND stockid='".$myrow[0]."' and reference like '%".$myroword[1]."%'";
$resultord=DB_query($sqlord);
$myroword=DB_fetch_array($resultord);
$fecharec=strtotime($myroword[0]);
$tiempoprov=($fecharec-$fechaorden)/86400;
if($tiempoprov>17000){$tiempoprov='-100';}
$tiempoprov=locale_number_format($tiempoprov,0).' días';
if(!isset($myroword[0])){$tiempoprov='-100 días';}
}


$sqlre="SELECT reorderlevel FROM locstock where stockid='".$myrow[0]."' and loccode='1'";
$resultre=DB_query($sqlre);
$myrowre=DB_fetch_array($resultre);

$calcul=((7+$tiempoprov+5)/30)*$myrow[1];

$sql="SELECT SUM(CASE WHEN (stockmoves.type=10 OR stockmoves.type=11 OR stockmoves.type=17 OR stockmoves.type=28 OR stockmoves.type=38)

							AND stockmoves.hidemovt=0

						THEN -stockmoves.qty ELSE 0 END) AS qtyused, stockcategory.categorydescription,stockmaster.description

				FROM stockmoves INNER JOIN stockmaster ON stockmaster.stockid=stockmoves.stockid INNER JOIN stockcategory on stockcategory.categoryid=stockmaster.categoryid
				WHERE stockmoves.prd=".$CurrentPeriod." and stockmoves.stockid='".$myrow[0]."'

				GROUP BY stockmoves.prd

				ORDER BY qtyused DESC";
$resultalan=DB_query($sql);					
$myrowalan=DB_fetch_array($resultalan);


echo '<tr class="striped_row">
			<td class="number">'.$i.'</td>
			<td>'.$myrow[0].'</td>
			<td>'.$myrow[3].'</td>
			<td class="number">'.locale_number_format($myrow[1],2).'</td>
			<td class="number">'.locale_number_format($myrowalan[0],2).'</td>
			<td class="number">'.$tiempoprov.'</td>
			<td class="number">'.$myrowre[0].'</td>
			<td class="number">'.locale_number_format($calcul,0).'</td>	
			<td>'.$myrow[2].'</td>		
			</tr>';

$i+=1;
	}
				echo '</tbody></table>';
		
	

	
	include('includes/footer.php');
?>