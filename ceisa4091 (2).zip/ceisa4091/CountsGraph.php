<?php
//la clase session ya contiene la session de usuario SOREA 10/02/2020

include('includes/session.php');
include('includes/phplot/phplot.php');
include('Classes/ClassCountGraph.php');
//con la funcion _ se puede cambiar los titulos de la pestaña del navegador
$Title=_('Grafica de conteos');
$ViewTopic = 'ARInquiries';
$BookMark = 'SalesGraph';
$Cgraph = new ClassCountGraph();
include('includes/header.php');
  // echo '<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">';
  
  //esta funcion se utiliza para dar las instrucciones al usuario para cada pantalla
  echo '<div class="page_help_text">' .
			_('Seleccione el rango de las fechas de las que se desea graficar') . '<br />' .
            _('Agrupe por día o por mes') ;
            echo '</div><br /><form method="post" action="' . htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . '">';
  echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
  echo '<table><tr>';
  //si el campo de la fecha esta vacio se coloca la fecha de hoy menos 7 dias
  if($_POST['FechaInicio']=='')
  {
         
    $_POST['FechaInicio']= date("Y-m-d",strtotime("- 7 days"));
  }
  if($_POST['FechaFin']=='')
  {
         
    $_POST['FechaFin']= date("Y-m-d");
  }
 
  echo '<th><label>Fecha inicio</label><input type="text" class="date" name="FechaInicio" size =10 value = "'.$_POST['FechaInicio'].'" required /></th><th><label>Fecha fin</label><input type="text" size="10" class="date" name="FechaFin" value="'.$_POST['FechaFin'].'" required />';
  if($_POST['radioSelect']=="dia" || !isset($_POST['radioSelect']))
  {
    echo '<input type="radio" name="radioSelect" value="dia" checked required> Agrupar por día';
  }else 
  {
    echo '<input type="radio" name="radioSelect" value="dia" required> Agrupar por día';
  }
  if($_POST['radioSelect']=="mes" )
  {
    echo '<input type="radio" name="radioSelect" value="mes" checked required> Agrupar por mes';
  }else 
  {
    echo '<input type="radio" name="radioSelect" value="mes" required> Agrupar por mes';
  }
      $myrows = $Cgraph->PersonaFiltros();
      echo "<select name = 'Ubicacion'>";
      echo "<option value =''></option>";
      while($myrow=DB_fetch_array($myrows))
      {
          if(strpos($_POST['Ubicacion'],$myrow['loccode'])){
          echo "<option value='".$_POST['ubicacion']."' selected>".$myrow['locationname']."</option>";
        }else{
           echo "<option value='and almacen = ".$myrow['loccode']."'>".$myrow['locationname']."</option>";
          }
      }
      echo "</select>";
      echo "</label> Almacen</label>";
  echo '</th>';
  echo '
			<td>' . _('Tipo de grafica') . '</td>
      <td><select name="GraphType">';
      if($_POST['GraphType']=="bars")
      {
        echo '<option value="bars" selected>' . _('Bar Graph') . '</option>';
      }else {
        echo '<option value="bars">' . _('Bar Graph') . '</option>';
      }if($_POST['GraphType']=="stackedbars"){
      echo '<option value="stackedbars" selected>' . _('Stacked Bar Graph') . '</option>';
      }else {
        echo '<option value="stackedbars">' . _('Stacked Bar Graph') . '</option>';
      }if($_POST['GraphType']=="lines"){
        echo '<option value="lines" selected>' . _('Line Graph') . '</option>';
      }else {
      echo '  <option value="lines">' . _('Line Graph') . '</option>';
      }if($_POST['GraphType']=="linepoints"){
        echo '<option value="linepoints" selected>' . _('Line Point Graph') . '</option>';
      }else{
        echo '<option value="linepoints">' . _('Line Point Graph') . '</option>';
      }if($_POST['GraphType']=="area"){
        echo '<option value="area" selected>' . _('Area Graph') . '</option>';
      }else
      {
        echo '<option value="area">' . _('Area Graph') . '</option>';
      }if($_POST['GraphType']=="points"){
        echo '<option value="points" selected>' . _('Points Graph') . '</option>';
      }else {
        echo '<option value="points">' . _('Points Graph') . '</option>';
      }
      if($_POST['GraphType']=="pie"){
        echo '<option value="pie" selected>' . _('Pie Graph') . '</option>';
       }else{
        echo '<option value="pie">' . _('Pie Graph') . '</option>';
       } if($_POST['GraphType']=="thinbarline"){
        echo '<option value="thinbarline" selected>' . _('Thin Bar Line Graph') . '</option>';
      }else {
        echo '<option value="thinbarline">' . _('Thin Bar Line Graph') . '</option>';
      }if($_POST['GraphType']=="squared"){
         echo '<option value="squared" selected>' . _('Squared Graph') . '</option>';
        }else{
         echo '<option value="squared">' . _('Squared Graph') . '</option>';

        } if($_POST['GraphType']=="stackedarea"){
        echo '<option value="stackedarea" selected>' . _('Stacked Area Graph') . '</option>';
      }else {
        echo '<option value="stackedarea" >' . _('Stacked Area Graph') . '</option>';

      }
				echo '</select></td>';
  echo '<td><th ><input type=submit name=submit value="Graficar"/></th></td></tr>';
  echo '</table></form>';
  if(isset($_POST['submit']))
  {
    //este script manda a llamar una clase llamada  ClassCountGraph que se encuentra dentro de la carpeta de clases para poder graficar
    //$Cgraph = new ClassCountGraph();
    switch ($_POST['radioSelect'])
    {
        case "dia":
           $Cgraph->GraficarPorDia($_POST['Ubicacion'],$_POST['GraphType']);
        break;
        case "mes":
            $Cgraph->GraficarPorMes($_POST['Ubicacion'],$_POST['GraphType']);
        break;
        default:
       // $Cgraph->GraficaGeneral();
       
    break;
    } 
    
  }

  include('includes/footer.php');



?>
