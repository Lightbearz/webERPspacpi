<?php
    include('includes/session.php');
    $Title=_('Subir Horarios de Ceisa/Cisa');
    include('includes/header.php');
    include('Classes/ClassHorarioNomina.php');
   
    
    echo "

    <form method='post' action='" . htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . "' enctype='multipart/form-data'>
    <input type='hidden' name='FormID' value='" . $_SESSION['FormID'] . "' />
            <table> 
            <tr><th> <label for='ceisa'>Horarios Ceisa</label>
            <input type='radio' id='ceisa' name='company' value='ceisa' required></th>
            <td><label for='cisa'>Horarios Cissa</label> 
            <input type='radio' id='cisa' name='company' value='cissa' required></td>  
            <th><label for='myfile'>Seleccione el archivo :</label>
            <input type='file' name='myfile' required></th>
            <td><input type='submit' name='horarios' value='Subir horarios'></td>
            </table>
    </form>";
    if(isset($_POST['horarios'])!="" and isset($_POST['company'])!="")
    {
        $fileName=$_FILES['myfile']['name'];
        $fileTmp=$_FILES['myfile']['tmp_name'];
        $fileSize = $_FILES['myfile']['size']; 
        $fileHandle=fopen($fileTmp,"r") or die("Error al leer el archivo");
        $HorarioNomina = new HorarioNomina();
        //este archivo debe de llamarse asi para que pueda ser leido como ceisa o cissa
        if(($fileName=="6335144401363_attlog.dat"  and $_POST['company']!="cissa") or ($fileName=="6335145200464_attlog.dat"  and $_POST['company']!="ceisa") or ($fileName!="6335145200464_attlog.dat" and $fileName!="6335144401363_attlog.dat"))
        {
            prnMsg ('Se eligio el archivo incorrecto','error');
            include('includes/footer.php');
            exit;
        }
        else
        {
            $bool=false;
            $i=0;
            while($Row = fgetcsv($fileHandle, 10000, "\t"))
            {
                $bool=$HorarioNomina->DataInsert($_POST['company'],$Row[0], $Row[1],$Row[2],$Row[3],$Row[4],$Row[5]);   
                if($bool==true)
                {
                    $i++;
                }
            }
            unset($HorarioNomina); 
            if($i>=1)
            {
                prnMsg ('Se insertaron '.$i.' registros correctamente','success');
            }else{
                prnMsg ('Los datos ya habian sido insertados ','warning');
            }

        }
    }
    
    include('includes/footer.php');
?>