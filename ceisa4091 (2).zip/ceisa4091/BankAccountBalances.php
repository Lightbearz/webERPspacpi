<?php
/* Shows bank accounts authorised for with balances */

include('includes/session.php');
$Title = _('List of bank account balances');
$ViewTopic = 'GeneralLedger';
$BookMark = 'BankAccountBalances';
include('includes/header.php');

echo '<p class="page_title_text" style="font-size:large"><img alt="" src="', $RootPath, '/css/', $Theme,
	'/images/bank.png" title="', // Icon image.
	_('Bank Account Balances'), '" /> ', // Icon title.
	_('Bank Account Balances'), '</p>',// Page title.
	'<table>
		<tr>
			<th>', _('Bank Account'), '</th>
			<th>', _('Account Name'), '</th>
			<th>', _('Saldo en SPACPI'), '</th>
			<th>', _('Saldo en bancos'), '</th>
			<th>', _('Diferencia'), '</th>
			<th>', _('Ingresos por asignar'), '</th>
			<th>', _('Pagos por conciliar'), '</th>
			<th>Faltante neto</th>';
	echo	'</tr>';

$SQL = "SELECT DISTINCT bankaccounts.accountcode,
						currcode,
						bankaccountname
			FROM bankaccounts
			INNER JOIN bankaccountusers
			ON bankaccounts.accountcode=bankaccountusers.accountcode
			AND userid='" . $_SESSION['UserID'] . "' ORDER BY bankaccountname ASC";
$Result = DB_query($SQL);

if (DB_num_rows($Result) == 0) {
	echo _('There are no bank accounts defined that you have authority to see');
} else {
	while ($MyBankRow = DB_fetch_array($Result)) {
	$sqlmean="SELECT * FROM bankedo where bankaccount='".$MyBankRow['accountcode']."'";
	$resultmean=DB_query($sqlmean);
	if(DB_num_rows($resultmean) != 0) {
		$CurrBalanceSQL = "SELECT (SELECT SUM(abono-cargo) FROM bankedo where bankaccount='".$MyBankRow['accountcode']."' and banktransidrel!='' and banktransidrel!='0' and fecha='".date('Y-m-d')."' ), SUM(banktrans.amount) AS balance FROM banktrans WHERE bankact='" . $MyBankRow['accountcode'] . "' AND transdate<'".date('Y-m-d')."'";
		}
		else {
		$CurrBalanceSQL = "SELECT (SELECT SUM(abono-cargo) FROM bankedo where bankaccount='".$MyBankRow['accountcode']."' and banktransidrel!='' and banktransidrel!='0' and fecha='".date('Y-m-d')."' ), SUM(banktrans.amount) AS balance FROM banktrans WHERE bankact='" . $MyBankRow['accountcode'] . "' AND transdate<='".date('Y-m-d')."'";
		}
		$CurrBalanceResult = DB_query($CurrBalanceSQL);
		$CurrBalanceRow = DB_fetch_array($CurrBalanceResult);


		if($MyBankRow['accountcode']=='102101-1'){
		$SQL = "SELECT saldo FROM bankedo WHERE bankaccount='" . $MyBankRow['accountcode'] . "' ORDER BY fecha DESC, idregistro ASC ";
		$Realresult = DB_query($SQL);
		$Realbalancerow = DB_fetch_array($Realresult);
		}
		else{
		$SQL = "SELECT saldo FROM bankedo WHERE bankaccount='" . $MyBankRow['accountcode'] . "' ORDER BY fecha DESC,idregistro DESC ";
		$Realresult = DB_query($SQL);
		$Realbalancerow = DB_fetch_array($Realresult);
		}
/*
		$FuncBalanceSQL = "SELECT SUM(amount) AS balance FROM gltrans WHERE account='" . $MyBankRow['accountcode'] . "'";
		$FuncBalanceResult = DB_query($FuncBalanceSQL);
		$FuncBalanceRow = DB_fetch_array($FuncBalanceResult);*/

		$DecimalPlacesSQL = "SELECT decimalplaces FROM currencies WHERE currabrev='" . $MyBankRow['currcode'] . "'";
		$DecimalPlacesResult = DB_query($DecimalPlacesSQL);
		$DecimalPlacesRow = DB_fetch_array($DecimalPlacesResult);
$CurrBalanceRow['balance']=$CurrBalanceRow['balance']+$CurrBalanceRow[0];
		echo '<tr class="striped_row">
				<td>', $MyBankRow['accountcode'], '</td>
				<td>', $MyBankRow['bankaccountname'], '</td>
				<td class="number">', locale_number_format($CurrBalanceRow['balance'], $DecimalPlacesRow['decimalplaces']), ' ', $MyBankRow['currcode'], '</td>';
				if($Realbalancerow[0]!=''){
			echo 	'<td class="number">', locale_number_format($Realbalancerow[0], $DecimalPlacesRow['decimalplaces']), ' ', $MyBankRow['currcode'], '</td>';
				}
		$dif=locale_number_format(($CurrBalanceRow['balance']-$Realbalancerow[0]),2);
		
		if($Realbalancerow[0]!=''){
		$SQL = "SELECT SUM(abono) as abonos, SUM(cargo) as cargos FROM bankedo WHERE bankaccount='" . $MyBankRow['accountcode'] . "' AND (banktransidrel='' or banktransidrel='0')  ";
		$Resultme = DB_query($SQL);
		$Realmerow = DB_fetch_array($Resultme);
		$green='lightcoral';	
		if(locale_number_format(($CurrBalanceRow['balance']-$Realbalancerow[0]+$Realmerow['abonos']-$Realmerow['cargos']),2)==0){
$green='limegreen';		
		}
			echo	'<td class="number" style="color:blue">', $dif, ' ', $MyBankRow['currcode'], '</td>
			<td class="number" style="color:green">', locale_number_format($Realmerow['abonos'],2), ' ', $MyBankRow['currcode'], '</td>
			<td class="number" style="color:red">', locale_number_format($Realmerow['cargos'],2), ' ', $MyBankRow['currcode'], '</td>
			<td class="number" style="color:black;font-weight:bold;background-color:'.$green.'">', locale_number_format(($CurrBalanceRow['balance']-$Realbalancerow[0]+$Realmerow['abonos']-$Realmerow['cargos']),2), ' ', $MyBankRow['currcode'], '</td>';}
			// echo	'<td class="number">', locale_number_format($FuncBalanceRow['balance'], $_SESSION['CompanyRecord']['decimalplaces']), ' ', $_SESSION['CompanyRecord']['currencydefault'], '</td>
		echo	'</tr>';
	}

	echo '</table>';
}
include('includes/footer.php');
?>