<?php

 $localtime=date('Y-m-d-H-i',(mktime(date('H')-6,date('i'),date('s'),date('m'),date('d'),date('Y'))));

$dbh = 'spacpi.ipowermysql.com';
   $dbu = 'ceisamx';
   $dbp = 'Alge-12';
   
   
   ///RESPALDAR TODO
   
       $dbn= 'ceisamx';
   $backup_file = '../respaldosdbwpceisamx/' . $localtime.$dbn . '.sql.zip';
   $command = "mysqldump --opt -h $dbh -u $dbu -p$dbp ". "ceisamx | gzip > $backup_file";
   system($command);
   $dbu = 'helitron';
      $dbn= '_SPACPI_DB_1_DE_4';
   $backup_file = '../respaldosdbspacpi/' . $localtime.$dbn . '.sql.zip';
   $command = "mysqldump --opt -h $dbh -u $dbu -p$dbp ". "--ignore-table=ceisa4091.gltrans --ignore-table=ceisa4091.audittrail --ignore-table=ceisa4091.stockmoves --ignore-table=ceisa4091.locstock --ignore-table=ceisa4091.debtortrans --ignore-table=ceisa4091.purchorders ceisa4091  | gzip > $backup_file";
   system($command);
 
      $dbn= '_SPACPI_DB_2_DE_4';
   $backup_file = '../respaldosdbspacpi/' . $localtime.$dbn . '.sql.zip';
   $command = "mysqldump --opt -h $dbh -u $dbu -p$dbp ". "ceisa4091 gltrans | gzip > $backup_file";
   system($command);
   
   $dbn= '_SPACPI_DB_3_DE_4';
   $backup_file = '../respaldosdbspacpi/' . $localtime.$dbn . '.sql.zip';
   $command = "mysqldump --opt -h $dbh -u $dbu -p$dbp ". "ceisa4091 audittrail | gzip > $backup_file";
   system($command);
   
    $dbn= '_SPACPI_DB_4_DE_4';
   $backup_file = '../respaldosdbspacpi/' . $localtime.$dbn . '.sql.zip';
   $command = "mysqldump --opt -h $dbh -u $dbu -p$dbp ". "ceisa4091 stockmoves locstock debtortrans purchorders | gzip > $backup_file";
   system($command);
     ///RESPALDAR TODO
   
   
  ///BORRAR RESPALDOS SPACPI
 $localtime=date('Y-m-d',(mktime(date('H')-6,date('i'),date('s'),date('m'),date('d'),date('Y'))));
$path    = '../respaldosdbspacpi/';
$files = scandir($path,1);
$files = array_diff(scandir($path), array('.', '..'));
rsort($files);
foreach($files as $file){
$tiempo=substr($file,0,10);
$lapso=(strtotime($localtime)-strtotime($tiempo))/86400;
if($lapso!=0 and $lapso!=1 and $lapso!=2 and $lapso!=7 and $lapso!=30 and $lapso!=90 ){
unlink($path.$file);
}
}
$path    = '../respaldosdbwpceisamx/';
$files = scandir($path,1);
$files = array_diff(scandir($path), array('.', '..'));
rsort($files);
foreach($files as $file){
$tiempo=substr($file,0,10);
$lapso=(strtotime($localtime)-strtotime($tiempo))/86400;
if($lapso!=0 and $lapso!=1 and $lapso!=2 and $lapso!=7 and $lapso!=30 and $lapso!=90 ){
unlink($path.$file);
}
}
///BORRAR RESPALDOS SPACPI









?>