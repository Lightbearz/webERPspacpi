<?php
include('../includes/session.php');
class ProductionLine
{
    var $linea;
    var $descNew;
    var $id;
    
  
    public function CrearLinea($linea)
    {
        $sql='INSERT into lineasproduccion values(null,"'.$linea.'")';
        $result = DB_query($sql);
        prnMsg(_('Linea agregada con exito'),'succes');
    }
    
    public function EliminarLinea($linea)
    {
        $sql="SELECT count(prodline) from stockmaster where prodline ='".$linea."'";
        
        $result=DB_query($sql);
        $myrow=DB_fetch_array($result);
        if($myrow[0]==null ||$myrow[0]==0)
        {
            $sql="DELETE from lineasproduccion where id='".$linea."'";
            DB_query($sql);
            prnMsg(_('La linea se borró exitosamente'),'success');
        }
        else 
        {
            
            prnMsg(_('Esta linea de produccion no se puede eliminar porque existen '.$myrow[0].' articulos en esa linea'),'error');
        }
    }

    public function ModificarLinea($id,$descNew)
    {
         $sql='UPDATE lineasproduccion set description="'.$descNew.'" where id='.$id.''; 
        DB_query($sql);
        prnMsg(_('La linea se modifico exitosamente'),'success');
    }
  
 
              
}


?>