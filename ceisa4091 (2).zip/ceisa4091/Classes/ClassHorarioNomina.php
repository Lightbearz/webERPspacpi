<?php
include('../includes/session.php');
Class HorarioNomina
{

    public function DataInsert($company,$Row0,$Row1,$Row2,$Row3,$Row4,$Row5)
    {
        $bool=false;
        $row=0;
        $sql="SELECT id from ".$company." where 1 and id=".$Row0." and date='".$Row1."' and `COL 3`=".$Row2." and `COL 4`=".$Row3." and `COL 5`=".$Row4." and `COL 6`=".$Row5."";
        $result=DB_query($sql);
        $row = mysqli_num_rows($result);  
        if($row==0 or $row==null or $row=="")
        {
            $sql="INSERT into ".$company." values("
                   .$Row0.",
                 '".$Row1."',
                 '".$Row2."',
                 '".$Row3."',
                 '".$Row4."',
                 '".$Row5."')";
            DB_query($sql);
            $bool=true;
        }
        return $bool;
    }
    

}
?>