<?php
include('../includes/session.php');
include('../includes/phplot/phplot.php');
class PromedioTiempos
{
   
   
    private function FiltrarMes($fechaInicio,$fechaFin)
    {
        $sql = "SELECT COUNT(date_format(s.orddate,'%Y-%m')) as cantidad, date_format(d.t4,'%Y-%m') as fecha_embarque,AVG(DATEDIFF ( d.inputdate,s.orddate ) ) as facturar,AVG(DATEDIFF ( d.t2,d.inputdate ) ) as surtir,AVG(DATEDIFF ( d.t3,d.t2 ) ) as empacar,AVG(DATEDIFF ( d.t4,d.t3 ) ) as embarcar from debtortrans as d 
        inner join salesorders as s on d.order_=s.orderno 
        WHERE d.estatus>=4 and date_format(d.t4,'%Y-%m-%d') BETWEEN  date_format('".$fechaInicio."','%Y-%m-%d') AND date_format('".$fechaFin."','%Y-%m-%d') AND s.fromstkloc=1
        GROUP BY date_format(d.t4,'%Y-%m') order by d.t4 asc";
      // echo $sql;
       $result = DB_query($sql);
        
         return $result;
             
    }
    private function FiltrarDia($fechaInicio,$fechaFin)
    {
        $sql = "SELECT COUNT(date_format(s.orddate,'%Y-%m-%d')) as cantidad,date_format(d.t4,'%Y-%m-%d') as fecha_embarque ,AVG(DATEDIFF ( d.inputdate,s.orddate ) ) as facturar,AVG(DATEDIFF ( d.t2,d.inputdate ) ) as surtir,AVG(DATEDIFF ( d.t3,d.t2 ) ) as empacar,AVG(DATEDIFF ( d.t4,d.t3 ) ) as embarcar from debtortrans as d 
        inner join salesorders as s on d.order_=s.orderno 
        WHERE d.estatus>=4 and date_format(d.t4,'%Y-%m-%d') BETWEEN  date_format('".$fechaInicio."','%Y-%m-%d') AND date_format('".$fechaFin."','%Y-%m-%d') AND s.fromstkloc=1
        GROUP BY date_format(d.t4,'%Y-%m-%d') order by d.t4 asc";
        //echo $sql;
        $result = DB_query($sql);
        
        return $result;
       
    }
    public function Graficar($fechaInicio,$fechaFin,$agrupar,$tipoGrafica)
    {        
        
            if($agrupar == "1")
            {
                $NombreGrafica = "Filtro por dia";
                $resultSQL=$this->FiltrarDia($fechaInicio,$fechaFin);
            }
            else 
            {

                 $Nombrerafica = "Filtro por mes";
                 $resultSQL=$this->FiltrarMes($fechaInicio,$fechaFin);
            }
            if(DB_num_rows($resultSQL)!=0){ 
                $titulo="Grafica de promedio de tiempos";
                $graph = new PHPlot(950,450);
                $GraphTitle=$NombreGrafica;
                $graph->SetTitle($GraphTitle);
                $graph->SetTitleColor('blue');
                $graph->SetOutputFile('companies/' .$_SESSION['DatabaseName'] .  '/reports/countsgraph.png');
                $graph->SetXTitle(_($titulo));
                $graph->SetYTitle(_("Promedio en dias"));
                $graph->SetXTickPos('none');
                $graph->SetXTickLabelPos('none');
                $graph->SetXLabelAngle(90);
                $graph->SetBackgroundColor('white');
                $graph->SetTitleColor('blue');
                $graph->SetFileFormat('png');
                $graph->SetPlotType($tipoGrafica);
                $graph->SetIsInline('1');
                $graph->SetShading(5);
                $graph->SetDrawYGrid(TRUE);
                $graph->SetDataType('text-data');
                $graph->SetNumberFormat($DecimalPoint, $ThousandsSeparator);
                $graph->SetPrecisionY($_SESSION['CompanyRecord']['decimalplaces']);
                
                $GraphArray = array();
                $i = 0;
                while ($myrow = DB_fetch_array($resultSQL)){
                
                    $GraphArray[$i] = array($myrow['fecha_embarque'].' ('.$myrow['cantidad'].')',$myrow['facturar'],$myrow['surtir'],$myrow['empacar'],$myrow['embarcar']);
                    $i++;
                }
        
                    $graph->SetDataValues($GraphArray);
                    $graph->SetDataColors();
                //$graph->SetLegend(array(_('Actual'));
                //if($_POST['fecha']!=''){
                $graph->SetLegend(array('Tiempo en Facturar','Tiempo en Surtir','Tiempo en Empacar','Tiempo Hasta embarque'));
                //}
            
                //dejar la variable plotin para lograr graficar 
               
                $graph->SetYDataLabelPos('plotin');
        
                //Draw it
                $graph->DrawGraph();
                echo '<table class="selection">
                        <tr>
                            <td><p><img src="companies/' .$_SESSION['DatabaseName'] .  '/reports/countsgraph.png?t='.time().'" alt="Sales Report Graph"></img></p></td>
                        </tr>
                      </table>';
            }
            else { 
                prnMsg('No se encontraron datos para graficar','error');
                
            }  
           
        //include('../includes/footer.php');
    }
}

?>