<?php

$PageSecurity = 29; //hard coded in case database is old and PageSecurity stuff cannot be retrieved

include('includes/session.php');
$Title = _('Backup webERP Database');
include('includes/header.php');
include('includes/SQL_CommonFunctions.inc');

echo '<p class="page_title_text"><img alt="" src="', $RootPath, '/css/', $Theme,
	'/images/transactions.png" title="', // Icon image.
	$Title, '" /> ', // Icon title.
	$Title, '</p>';// Page title.


echo '<form  method="post" action="', htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8'), '">';
echo '<input type="hidden" name="FormID" value="', $_SESSION['FormID'], '" />';

if($_POST['Respaldar']==1){

$dbh = 'spacpi.ipowermysql.com';
   $dbu = 'ceisamx';
   $dbp = 'Alge-12';
   
       $dbn= 'ceisamx';
   $backup_file = '../respaldosdbwpceisamx/' . date("Y-m-d-H-i").$dbn . '.sql.zip';
   $command = "mysqldump --opt -h $dbh -u $dbu -p$dbp ". "ceisamx | gzip > $backup_file";
   system($command);
    $dbu = 'helitron';


      $dbn= '_SPACPI_DB_1_DE_4';
   $backup_file = '../respaldosdbspacpi/' . date("Y-m-d-H-i").$dbn . '.sql.zip';
   $command = "mysqldump --opt -h $dbh -u $dbu -p$dbp ". "--ignore-table=ceisa4091.gltrans --ignore-table=ceisa4091.audittrail --ignore-table=ceisa4091.stockmoves --ignore-table=ceisa4091.locstock --ignore-table=ceisa4091.debtortrans --ignore-table=ceisa4091.purchorders ceisa4091  | gzip > $backup_file";
   system($command);
 
      $dbn= '_SPACPI_DB_2_DE_4';
   $backup_file = '../respaldosdbspacpi/' . date("Y-m-d-H-i").$dbn . '.sql.zip';
   $command = "mysqldump --opt -h $dbh -u $dbu -p$dbp ". "ceisa4091 gltrans | gzip > $backup_file";
   system($command);
   
   $dbn= '_SPACPI_DB_3_DE_4';
   $backup_file = '../respaldosdbspacpi/' . date("Y-m-d-H-i").$dbn . '.sql.zip';
   $command = "mysqldump --opt -h $dbh -u $dbu -p$dbp ". "ceisa4091 audittrail | gzip > $backup_file";
   system($command);
   
    $dbn= '_SPACPI_DB_4_DE_4';
   $backup_file = '../respaldosdbspacpi/' . date("Y-m-d-H-i").$dbn . '.sql.zip';
   $command = "mysqldump --opt -h $dbh -u $dbu -p$dbp ". "ceisa4091 stockmoves locstock debtortrans purchorders | gzip > $backup_file";
   system($command);
   

   
	prnMsg('Se ha dado la instrucción del respaldo correctamente, en breve aparecerá su archivo en la carpeta mencionada en Z_Programador.php ','success');   
   unset($_POST['Respaldar']);
   }

echo '<h1  class="centre"  > Generar nuevo respaldo manual </h1>
<button type="submit" name="Respaldar" value="1" onclick="return confirm(\'¿Está seguro de Generar un respaldo ahora?\');" style="background-color:lightblue;width:150px;height:50px;font-size:medium"> Generar Ahora </button>';  
  
   
echo '</form>';



$path    = '../respaldosdbspacpi/';
$files = scandir($path,1);
$files = array_diff(scandir($path), array('.', '..'));
rsort($files);
$i=4;
echo '<b>Descargar respaldos más recientes:</b></br>';
foreach($files as $file){
if($i>0){
echo '<a  href="../respaldosdbspacpi/'.$file.'" target="_blank"  > '.$file.' </a></br>';
}
if($i==0){
echo '<b>Descargar otros respaldos:</b></br>';
}
if($i<=0){
$tiempo=substr($file,0,10);
$lapso=(strtotime(date('Y-m-d'))-strtotime($tiempo))/86400;

echo '<a  href="../respaldosdbspacpi/'.$file.'" target="_blank"  >  '.$file.' </a></br>';


}
$i--;
}
echo '</br></br>';
$path    = '../ceisa4091/';
$files = scandir($path,1);
$files = array_diff(scandir($path), array('.', '..'));
asort($files);
foreach($files as $file){
	if(strpos($file,'.php')){
	echo '<a  href="BackupDatabase.php?File='.$file.'"   > '.$file.' </a></br>';
	}
}
if(isset($_GET['File'])){

	header("Pragma: public");
	header("Expires: 0"); // set expiration time
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Content-Type: application/force-download");
	header("Content-Type: application/octet-stream");
	header("Content-Type: application/download");
	header("Content-Disposition: attachment; filename=".basename($_GET['File']).";");
	header("Content-Transfer-Encoding: binary");
	header("Content-Length: ".filesize($_GET['File']));
	
	@readfile($filename);
	exit(0);
}

include('includes/footer.php');
?>