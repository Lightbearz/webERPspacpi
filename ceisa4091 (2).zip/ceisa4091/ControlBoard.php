<?php
/* Display outstanding debtors, creditors, etc */
include('includes/session.php');
$Title = _('Panel de supervisión');
$ViewTopic = 'GeneralLedger';// RChacon: You should be in this topic ?
$BookMark = 'Panel de supervisión';
include('includes/header.php');

echo '<p class="page_title_text"><img alt="" src="', $RootPath, '/css/', $Theme,
	'/images/gl.png" title="',// Icon image.
	$Title, '" /> ',// Icon title.
	$Title, '</p>';// Page title.
	
if(in_array(29, $_SESSION['AllowedPageSecurityTokens'])) {
echo '<form  method="post" action="', htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8'), '">';
echo '<input type="hidden" name="FormID" value="', $_SESSION['FormID'], '" />';

if(isset($_POST['AutorizarOrden'])){
$sql="UPDATE salesorders SET autorizada='".$_SESSION['UserID']." ".date('Y-m-d H:i:s')."' WHERE orderno='".$_POST['AutorizarOrden']."'";
$update=DB_query($sql);
prnMsg('La orden '.$_POST['AutorizarOrden'].' fue exitosamente autorizada', 'success');

$EmailSQL="SELECT * 
FROM www_users
INNER JOIN salesman ON salesman.salesmanname = www_users.userid
INNER JOIN salesorders ON salesorders.salesperson = salesman.salesmancode
WHERE orderno =  '".$_POST['AutorizarOrden']."'";
$EmailResult = DB_query($EmailSQL);
		while($myEmail=DB_fetch_array($EmailResult)){
		
					$fp =fopen('LogFiles/'.$myEmail['userid'].'.txt','a');
			$fwrite = fwrite($fp,"\n");
			$fwrite = fwrite($fp,'|0| Tu pedido '.$_POST['AutorizarOrden'].' fue autorizado');
			fclose($fp);

			$ConfirmationText =$myEmail['realname'].' acaban de autorizar tu pedido '.$_POST['AutorizarOrden'];
			$EmailSubject = 'Autorización pedido '.$_POST['AutorizarOrden'];
			 if($_SESSION['SmtpSetting']==0){
			       mail($myEmail['email'],$EmailSubject,$ConfirmationText,'From:CEISA  <ceisa@spacpi.com>');
			}else{
				include('includes/htmlMimeMail.php');
				$mail = new htmlMimeMail();
				$mail->setSubject($EmailSubject);
				$mail->setText($ConfirmationText);
				$result = SendmailBySmtp($mail,array($myEmail['email'],'From:CEISA  <ceisa@spacpi.com>'));
			}
			
			}



}

if(isset($_POST['RechazarOrden'])){
$sql="UPDATE salesorders SET autorizada='rechazada' WHERE orderno='".$_POST['RechazarOrden']."'";
$update=DB_query($sql);
prnMsg('La orden '.$_POST['RechazarOrden'].' fue exitosamente rechazada', 'success');

$EmailSQL="SELECT * 
FROM www_users
INNER JOIN salesman ON salesman.salesmanname = www_users.userid
INNER JOIN salesorders ON salesorders.salesperson = salesman.salesmancode
WHERE orderno =  '".$_POST['RechazarOrden']."'";
$EmailResult = DB_query($EmailSQL);
		while($myEmail=DB_fetch_array($EmailResult)){
		
					$fp =fopen('LogFiles/'.$myEmail['userid'].'.txt','a');
			$fwrite = fwrite($fp,"\n");
			$fwrite = fwrite($fp,'|0| Tu pedido '.$_POST['RechazarOrden'].' fue rechazado');
			fclose($fp);

			$ConfirmationText =$myEmail['realname'].' acaban de rechazar tu pedido '.$_POST['RechazarOrden'];
			$EmailSubject = 'Rechazo de pedido '.$_POST['RechazarOrden'];
			 if($_SESSION['SmtpSetting']==0){
			       mail($myEmail['email'],$EmailSubject,$ConfirmationText,'From:CEISA  <ceisa@spacpi.com>');
			}else{
				include('includes/htmlMimeMail.php');
				$mail = new htmlMimeMail();
				$mail->setSubject($EmailSubject);
				$mail->setText($ConfirmationText);
				$result = SendmailBySmtp($mail,array($myEmail['email'],'From:CEISA  <ceisa@spacpi.com>'));
			}
			
			}
			
				$EmailSQL="SELECT * FROM www_users where fullaccess='8' OR fullaccess='7'";
$EmailResult = DB_query($EmailSQL);
		while($myEmail=DB_fetch_array($EmailResult)){			
$fp =fopen('LogFiles/'.$myEmail['userid'].'.txt','r');
while(!feof($fp)){
$linea = fgets($fp);
$estatus=substr($linea,0,3);
$notificación=substr($linea,3);
$arreglo[]=array($estatus,$notificación);
}	
fclose($fp);
$i=0;
$fp =fopen('LogFiles/'.$myEmail['userid'].'.txt','w');
while($arreglo[$i][0]){
if(strpos($arreglo[$i][1],$_POST['RechazarOrden'])){
$arreglo[$i][0]='|1|';
}
$fwrite = fwrite($fp,$arreglo[$i][0].$arreglo[$i][1]);
$i+=1;
}
fclose($fp);
unset($arreglo);
}		


}


$sql="SELECT COUNT(salesorders.orderno) as num,salesorders.orderno,salesorders.salesperson, salesorders.autorizada, debtorsmaster.name,debtorsmaster.debtorno, custbranch.brname, salesorders.customerref, salesorders.orddate, salesorders.deliverydate, salesorders.deliverto, salesorders.printedpackingslip, salesorders.poplaced, SUM( salesorderdetails.unitprice * ( salesorderdetails.quantity - salesorderdetails.qtyinvoiced ) * ( 1 - salesorderdetails.discountpercent ) / currencies.rate ) AS ordervalue, pickreq.prid,salesorders.deliverydate, debtorsmaster.salestype
FROM salesorders
INNER JOIN salesorderdetails ON salesorders.orderno = salesorderdetails.orderno
INNER JOIN debtorsmaster ON salesorders.debtorno = debtorsmaster.debtorno
INNER JOIN custbranch ON debtorsmaster.debtorno = custbranch.debtorno
AND salesorders.branchcode = custbranch.branchcode
INNER JOIN currencies ON debtorsmaster.currcode = currencies.currabrev
LEFT OUTER JOIN pickreq ON pickreq.orderno = salesorders.orderno
AND pickreq.closed =0
WHERE salesorderdetails.completed =0
AND salesorders.quotation =  '0'
AND (
salesorders.fromstkloc =  '1' or salesorders.fromstkloc =  '5'
)
AND salesorders.autorizada='onwait'
GROUP BY salesorders.orderno, debtorsmaster.name, custbranch.brname, salesorders.customerref, salesorders.orddate, salesorders.deliverydate, salesorders.deliverto, salesorders.printedpackingslip, salesorders.poplaced
ORDER BY salesorders.deliverydate ASC, salesorders.orderno ASC";
$resultautor=DB_query($sql);

if (DB_num_rows($resultautor)!=0){
	echo '<h2> Pedidos que requieren autorización: '.DB_num_rows($resultautor).' </h2>';
while($autor=DB_fetch_array($resultautor)){
	echo	'<table class="selection" style="margin-left:15%;width:70%">
	<tr><th style="background-color:DarkGrey;color:blue"><a href="SelectCustomer.php?Select='.$autor['debtorno'].'" target="_blank">'.$autor['debtorno'].'<a/></th><th style="background-color:DarkGrey">'.$autor['name'].'</th><th style="background-color:DarkGrey"><a href="SelectOrderItems.php?ModifyOrderNumber='.$autor['orderno'].'?&Details=1" target="_blank">No. '.$autor['orderno'].'</a></th><th style="background-color:DarkGrey">Fecha Entrega:</th><th style="background-color:DarkGrey">'.$autor['deliverydate'].' </th><th style="background-color:DarkGrey">Vendedor: </th><th style="background-color:DarkGrey">'.$autor['salesperson'].'</th><th style="background-color:DarkGrey"><button style="background-color:limegreen" type="submit"  name="AutorizarOrden" onclick="return confirm(\'¿Está seguro de AUTORIZAR esta orden?\');" value="'.$autor['orderno'].'" >Autorizar</button></th><th style="background-color:DarkGrey"><button style="background-color:lightcoral" type="submit"  name="RechazarOrden" onclick="return confirm(\'¿Está seguro de RECHAZAR esta orden?\');" value="'.$autor['orderno'].'" >Rechazar</button></th></tr>
			<tr>
				<th>Código</th>
				<th>Descripción</th>
				<th>Ordenado</th>
				<th>Unidad</th>
				<th>Facturado</th>
				<th>Por facturar</th>
				<th>Precio solicitado</th>
				<th>Precio cliente</th>
				<th>Desc. adicional solic.</th>
				<th>Total s/IVA</th>
			</tr>';	
$OrderHeaderSQL = "SELECT stkcode,
								stockmaster.description,
								stockmaster.longdescription,
								stockmaster.controlled,
								stockmaster.serialised,
								stockmaster.volume,
								stockmaster.grossweight,
								stockmaster.units,
								stockmaster.decimalplaces,
								stockmaster.mbflag,
								stockmaster.taxcatid,
								stockmaster.discountcategory,
								salesorderdetails.unitprice,
								salesorderdetails.quantity,
								salesorderdetails.discountpercent,
								salesorderdetails.actualdispatchdate,
								salesorderdetails.qtyinvoiced,
								salesorderdetails.narrative,
								salesorderdetails.orderlineno,
								salesorderdetails.poline,
								salesorderdetails.itemdue,
								stockmaster.materialcost + stockmaster.labourcost + stockmaster.overheadcost AS standardcost
							FROM salesorderdetails INNER JOIN stockmaster
							 	ON salesorderdetails.stkcode = stockmaster.stockid
							WHERE salesorderdetails.orderno ='" . $autor[1] . "'
							AND salesorderdetails.quantity - salesorderdetails.qtyinvoiced >0
							ORDER BY salesorderdetails.orderlineno";
$resultauto=DB_query($OrderHeaderSQL);
while($order=DB_fetch_array($resultauto)){

	$SQL = "SELECT
		currencies.currency,
        salestypes.sales_type,
		prices.price,
		prices.stockid,
		prices.typeabbrev,
		prices.currabrev,
		prices.startdate,
		prices.enddate,
		currencies.decimalplaces AS currdecimalplaces
	FROM prices
	INNER JOIN salestypes
		ON prices.typeabbrev = salestypes.typeabbrev
	INNER JOIN currencies
		ON prices.currabrev=currencies.currabrev
	WHERE prices.stockid='".trim($order[0])."'
	AND prices.debtorno='' AND prices.enddate='9999-12-31'
	ORDER BY prices.startdate DESC,prices.enddate DESC, salestypes.sales_type ASC";
					$priceresult=DB_query($SQL);
					
					
					$title='';
					$correct='sin lista';
					while($pricearray=DB_fetch_array($priceresult)){
					$title.=locale_number_format($pricearray['price'],2).' '.substr($pricearray['sales_type'],2).'&#13;';
					if($autor['salestype']==$pricearray['typeabbrev']){
					$correct=locale_number_format($pricearray['price'],2);
					}
					}
					
echo '<tr class="striped_row">
				<td style="background-color:orange">'.$order[0].'</td>
				<td>'.$order[1].'</td>
				<td style="text-align:center">'.$order['quantity'].'</td>
				<td style="text-align:center" >'.$order['units'].'</td>
				<td style="text-align:center">'.$order['qtyinvoiced'].'</td>
				<td style="text-align:center">'.($order['quantity']-$order['qtyinvoiced']).'</td>
				<td style="background-color:orange;text-align:center" title="'.$title.'">'.locale_number_format($order['unitprice'],2).'</td>
				<td style="background-color:lightblue;text-align:center">'.$correct.'</td>
				<td style="text-align:center">'.($order['discountpercent']*100).' %</td>
				<td style="text-align:center">'.locale_number_format((($order['quantity']-$order['qtyinvoiced'])*$order['unitprice']*(1-$order['discountpercent'])),2).'</td>
			</tr>
			<tr class="striped_row">
				<td style="background-color:lightblue">Detalles</td>
				<td colspan="8">'.$order['narrative'].'</td>
			</tr>';
}
echo '</table></br>';
}
echo '</form>';
	}
	}


echo '<table>'; /////////////INDICADORES
//////////////////////////////////////////////////////////////////////////////SALIDAS Y ENTRADAS
$max=DB_query("SET SQL_BIG_SELECTS=1");

$limit=Date('Y-m-d H:i:s',Mktime(Date('H'),Date('i')-10,Date('s'),Date('m'),Date('d'),Date('Y')));
$SQL="SELECT debtortrans.*,salesorders.fromstkloc, custbranch.brname FROM debtortrans LEFT JOIN salesorders ON salesorders.orderno=debtortrans.order_
LEFT JOIN inoutlocations ON inoutlocations.transno=debtortrans.transno and debtortrans.type=inoutlocations.typeid
LEFT JOIN custbranch on custbranch.branchcode=debtortrans.branchcode WHERE debtortrans.type='10' and (debtortrans.estatus=4 OR (debtortrans.estatus=5 and inoutlocations.ID IS NULL)) AND t4 BETWEEN '2019-10-07' AND '".$limit."' AND salesorders.fromstkloc!=5 ORDER BY t4 ASC";
$result=DB_query($SQL);

echo '<tr><td >		<h2 class="centre"> Material sin comprobar salida </h2>';

if(DB_num_rows($result)!=0){
echo '<table><tr>
<th> Almacén </th>
<th> Remisión </th>
<th> Cliente </th>
<th> Hora </th>
</tr>';
$i=0;
while($mirror=DB_fetch_array($result)){
$i=$i+1;
if($mirror['estatus']==4){
$mirror['estatus']='Embarcado';
}
if($mirror['estatus']==5){
$mirror['estatus']='Enviado';
}
echo '<tr class="striped_row">
<td class="centre" >'.$mirror['fromstkloc'].' - '.$mirror['estatus'].'</td>
<td>'.$mirror['transno'].'</td>
<td>'.$mirror['brname'].'</td>
<td>'.$mirror['t4'].'</td></tr>';
}
echo '</table>';
echo '<div class="centre" style="background-color:lightblue"> '.$i.' Restantes</div>';
}
else
{
echo '<div class="centre" style="background-color:limegreen">Todo las salidas se han comprobado</div>';
}
echo '</td>';
////////////////////////////////////////////////////////////////////////////// TERMINA SALIDAS Y ENTRADAS

//////////////////////////////////////////////////////////////////////////////VENDEDORES
$limit=Date('Y-m-d H:i:s',Mktime(0,0,0,Date('m')-1,Date('d'),Date('Y')));

$SQL=" SELECT salesman.salesmanname,notas.visitas,ventas.facturado FROM salesman LEFT JOIN (SELECT userid,COUNT(noteid) as visitas FROM custnotes WHERE (priority LIKE 'Visita' or priority LIKE 'Llamada') and date>='".$limit."' GROUP BY userid ) as notas
 on notas.userid=salesman.salesmanname
 LEFT JOIN (SELECT salesorders.salesperson,SUM(qtyinvoiced*unitprice*(1-discountpercent)) as facturado FROM salesorderdetails
 INNER JOIN salesorders on salesorders.orderno=salesorderdetails.orderno WHERE salesorders.orddate>='".$limit."' GROUP BY salesorders.salesperson ) as ventas
  ON ventas.salesperson=salesman.salesmancode
  WHERE current=1 order by facturado DESC";
$result=DB_query($SQL,'','',false,false);

echo '<td colspan="2">		<h2 class="centre"> Estatus 30 días Vendedores </h2>';

if(DB_num_rows($result)!=0){
echo '<table><tr>
<th> Vendedor </th>
<th> Pedidos </th>
<th> Visitas </th>
</tr>';

$acum=0;
$acum2=0;
while($mirror=DB_fetch_array($result)){
echo '<tr class="striped_row">
<td>'.$mirror['salesmanname'].'</td>
<td class="centre">$'.locale_number_format($mirror['facturado'],2).'</td>
<td class="centre">'.locale_number_format($mirror['visitas'],0).'</td></tr>';
$acum+=$mirror['facturado'];
$acum2+=$mirror['visitas'];

}
echo '</table>';
echo '<div class="centre" style="background-color:lightblue">Total Pedidos: $'.locale_number_format($acum,2).' </br>Vistas/Llamadas: '.locale_number_format($acum2,0).' </div>';
}

echo '</td></tr>';
////////////////////////////////////////////////////////////////////////////// TERMINA VENDEDORES
//////////////////////////////////////////////////////////////////////////////DEBTORDASH


	echo '<tr><td class="centre">
		<h2> Balance Clientes </h2>
		<table class="selection">
		<thead>
			<tr>
				<th></th>
				<th>', _('Balance'), '</th>
				<th>', _('Current'), '</th>
				<th>', _('Due Now'), '</th>
				<th>', '> ', $_SESSION['PastDueDays1'], ' ', _('Days Over'), '</th>
				<th>', '> ', $_SESSION['PastDueDays2'], ' ', _('Days Over'), '</th>
			</tr>
		</thead><tbody>';
	$j = 1;
	$TotBal = 0;
	$TotCurr = 0;
	$TotDue = 0;
	$TotOD1 = 0;
	$TotOD2 = 0;
	$CurrDecimalPlaces = 2;//By default.

	
	$Sql = "SELECT debtorsmaster.debtorno,
				debtorsmaster.name,
				currencies.currency,
				currencies.decimalplaces,
				paymentterms.terms,
				debtorsmaster.creditlimit,
				holdreasons.dissallowinvoices,
				holdreasons.reasondescription,
				SUM(
					debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc
				) AS balance,
				SUM(
					CASE WHEN (paymentterms.daysbeforedue > 0)
					THEN
						CASE WHEN (TO_DAYS(Now()) - TO_DAYS(debtortrans.trandate)) >= paymentterms.daysbeforedue
						THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc
						ELSE 0 END
					ELSE
						CASE WHEN TO_DAYS(Now()) - TO_DAYS(ADDDATE(last_day(debtortrans.trandate), paymentterms.dayinfollowingmonth)) >= 0
						THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc ELSE 0 END
					END
				) AS due,
				SUM(
					CASE WHEN (paymentterms.daysbeforedue > 0)
					THEN
						CASE WHEN (TO_DAYS(Now()) - TO_DAYS(debtortrans.trandate)) > paymentterms.daysbeforedue AND TO_DAYS(Now()) - TO_DAYS(debtortrans.trandate) >= (paymentterms.daysbeforedue + " . $_SESSION['PastDueDays1'] . ")
						THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc ELSE 0 END
					ELSE
						CASE WHEN TO_DAYS(Now()) - TO_DAYS(ADDDATE(last_day(debtortrans.trandate), paymentterms.dayinfollowingmonth)) >= " . $_SESSION['PastDueDays1'] . "
						THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc
						ELSE 0 END
					END
				) AS overdue1,
				SUM(
					CASE WHEN (paymentterms.daysbeforedue > 0)
					THEN
						CASE WHEN (TO_DAYS(Now()) - TO_DAYS(debtortrans.trandate)) > paymentterms.daysbeforedue AND TO_DAYS(Now()) - TO_DAYS(debtortrans.trandate) >= (paymentterms.daysbeforedue + " . $_SESSION['PastDueDays2'] . ")
						THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc ELSE 0 END
					ELSE
						CASE WHEN TO_DAYS(Now()) - TO_DAYS(ADDDATE(last_day(debtortrans.trandate), paymentterms.dayinfollowingmonth)) >= " . $_SESSION['PastDueDays2'] . "
						THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc
						ELSE 0 END
					END
				) AS overdue2
				FROM debtorsmaster,
					paymentterms,
					holdreasons,
					currencies,
					debtortrans
				WHERE debtorsmaster.paymentterms = paymentterms.termsindicator
					AND debtorsmaster.currcode = currencies.currabrev
					AND debtorsmaster.holdreason = holdreasons.reasoncode
					AND debtorsmaster.debtorno = debtortrans.debtorno
				GROUP BY debtorsmaster.debtorno,
					debtorsmaster.name,
					currencies.currency,
					paymentterms.terms,
					paymentterms.daysbeforedue,
					paymentterms.dayinfollowingmonth,
					debtorsmaster.creditlimit,
					holdreasons.dissallowinvoices,
					holdreasons.reasondescription
				HAVING
					ROUND(ABS(SUM(debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc)),currencies.decimalplaces) > 0
					ORDER BY balance DESC";
	$CustomerResult = DB_query($Sql, '', '', False, False); /*dont trap errors handled below*/

	if(DB_error_no() != 0) {
		prnMsg(_('The customer details could not be retrieved by the SQL because') . ' ' . DB_error_msg(),'error');
		echo '<br /><a href="' . $RootPath . '/index.php">' . _('Back to the menu') . '</a>';
		if($debug==1) {
			echo '<br />', $Sql;
		}
		include('includes/footer.php');
		exit;
	}
$u=0;
	while($AgedAnalysis = DB_fetch_array($CustomerResult)) {
		$CurrDecimalPlaces = $AgedAnalysis['decimalplaces'];
		$DisplayDue = locale_number_format($AgedAnalysis['due']-$AgedAnalysis['overdue1'],$CurrDecimalPlaces);
		$DisplayCurrent = locale_number_format($AgedAnalysis['balance']-$AgedAnalysis['due'],$CurrDecimalPlaces);
		$DisplayBalance = locale_number_format($AgedAnalysis['balance'],$CurrDecimalPlaces);
		$DisplayOverdue1 = locale_number_format($AgedAnalysis['overdue1']-$AgedAnalysis['overdue2'],$CurrDecimalPlaces);
		$DisplayOverdue2 = locale_number_format($AgedAnalysis['overdue2'],$CurrDecimalPlaces);
		if($DisplayDue <> 0 OR $DisplayOverdue1 <> 0 OR $DisplayOverdue2 <> 0) {
			$TotBal += $AgedAnalysis['balance'];
			$TotCurr += ($AgedAnalysis['balance']-$AgedAnalysis['due']);
			$TotDue += ($AgedAnalysis['due']-$AgedAnalysis['overdue1']);
			$TotOD1 += ($AgedAnalysis['overdue1']-$AgedAnalysis['overdue2']);
			$TotOD2 += $AgedAnalysis['overdue2'];
	
			$Sql = "SELECT systypes.typename,
						debtortrans.transno,
						debtortrans.trandate,
						daysbeforedue,
						dayinfollowingmonth,
						(debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc) as balance,
						(CASE WHEN (paymentterms.daysbeforedue > 0)
							THEN
								(CASE WHEN (TO_DAYS(Now()) - TO_DAYS(debtortrans.trandate)) >= paymentterms.daysbeforedue
								THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc
								ELSE 0 END)
							ELSE
								(CASE WHEN TO_DAYS(Now()) - TO_DAYS(ADDDATE(ADDDATE(last_day(debtortrans.trandate), 1), paymentterms.dayinfollowingmonth)) >= 0
								THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc
								ELSE 0 END)
						END) AS due,
						(CASE WHEN (paymentterms.daysbeforedue > 0)
							THEN
								(CASE WHEN TO_DAYS(Now()) - TO_DAYS(debtortrans.trandate) > paymentterms.daysbeforedue AND TO_DAYS(Now()) - TO_DAYS(debtortrans.trandate) >= (paymentterms.daysbeforedue + " . $_SESSION['PastDueDays1'] . ") THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc ELSE 0 END)
							ELSE
								(CASE WHEN (TO_DAYS(Now()) - TO_DAYS(ADDDATE(ADDDATE(last_day(debtortrans.trandate), 1), paymentterms.dayinfollowingmonth)) >= " . $_SESSION['PastDueDays1'] . ")
								THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc
								ELSE 0 END)
						END) AS overdue1,
						(CASE WHEN (paymentterms.daysbeforedue > 0)
							THEN
								(CASE WHEN TO_DAYS(Now()) - TO_DAYS(debtortrans.trandate) > paymentterms.daysbeforedue AND TO_DAYS(Now()) - TO_DAYS(debtortrans.trandate) >= (paymentterms.daysbeforedue + " . $_SESSION['PastDueDays2'] . ")
								THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc
								ELSE 0 END)
							ELSE
								(CASE WHEN (TO_DAYS(Now()) - TO_DAYS(ADDDATE(ADDDATE(last_day(debtortrans.trandate), 1), paymentterms.dayinfollowingmonth)) >= " . $_SESSION['PastDueDays2'] . ")
								THEN debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc
								ELSE 0 END)
						END) AS overdue2
				   FROM debtorsmaster,
						paymentterms,
						debtortrans,
						systypes
				   WHERE systypes.typeid = debtortrans.type
						AND debtorsmaster.paymentterms = paymentterms.termsindicator
						AND debtorsmaster.debtorno = debtortrans.debtorno
						AND debtortrans.debtorno = '" . $AgedAnalysis['debtorno'] . "'
						AND ABS(debtortrans.ovamount + debtortrans.ovgst + debtortrans.ovfreight + debtortrans.ovdiscount - debtortrans.alloc)>0.004
					ORDER BY debtortrans.trandate";

			if($_SESSION['SalesmanLogin'] != '') {
				$Sql .= " AND debtortrans.salesperson='" . $_SESSION['SalesmanLogin'] . "'";
			}

			$DetailResult = DB_query($Sql,'','',False,False);
			if(DB_error_no() !=0) {
				prnMsg(_('The details of outstanding transactions for customer') . ' - ' . $AgedAnalysis['debtorno'] . ' ' . _('could not be retrieved because') . ' - ' . DB_error_msg(),'error');
				echo '<br /><a href="' . $RootPath . '/index.php">' . _('Back to the menu') . '</a>';
				if($debug==1) {
					echo '<br />' . _('The SQL that failed was') . '<br />' . $Sql;
				}
				include('includes/footer.php');
				exit;
			}

			while($DetailTrans = DB_fetch_array($DetailResult)) {
				$DisplayTranDate = ConvertSQLDate($DetailTrans['trandate']);
				$DisplayBalance = locale_number_format($DetailTrans['balance'], $CurrDecimalPlaces);
				$DisplayCurrent = locale_number_format($DetailTrans['balance']-$DetailTrans['due'], $CurrDecimalPlaces);
				$DisplayDue = locale_number_format($DetailTrans['due']-$DetailTrans['overdue1'], $CurrDecimalPlaces);
				$DisplayOverdue1 = locale_number_format($DetailTrans['overdue1']-$DetailTrans['overdue2'], $CurrDecimalPlaces);
				$DisplayOverdue2 = locale_number_format($DetailTrans['overdue2'], $CurrDecimalPlaces);

				$DisplayDueDate = CalcDueDate($DisplayTranDate, $DetailTrans['dayinfollowingmonth'], $DetailTrans['daysbeforedue']);
					
			} //end while there are detail transactions to show
			$u++;
		} //has Due now or overdue
	} //end customer aged analysis while loop

	// Print totals of 'Overdue Customer Balances':
	echo '<tr class="striped_row">
			<td class="text"><b>', _('Totals'), '</b></td>
			<td class="number"><b>', locale_number_format($TotBal, $CurrDecimalPlaces), '</b></td>
			<td class="number"><b>', locale_number_format($TotCurr, $CurrDecimalPlaces), '</b></td>
			<td class="number"><b>', locale_number_format($TotDue, $CurrDecimalPlaces), '</b></td>
			<td class="number" style="color:red;"><b>', locale_number_format($TotOD1, $CurrDecimalPlaces), '</b></td>
			<td class="number" style="color:red;"><b>', locale_number_format($TotOD2, $CurrDecimalPlaces), '</b></td>
		</tr>
		</tbody></table></td>';
//////////////////////////////////////////////////////////////////////////////TERMINA EL DEBTORDASH
//////////////////////////////////////////////////////////////////////////////ORDERDASH
	echo '<td class="centre">
		<h2> Órdenes Pendientes </h2>
		<table class="selection">
		<thead>
			</thead><tbody>';

	$Sql = "SELECT salesorders.orderno,
						debtorsmaster.name,
						custbranch.brname,
						salesorders.customerref,
						salesorders.orddate,
						salesorders.deliverto,
						salesorders.deliverydate,
						salesorders.printedpackingslip,
						salesorders.poplaced,
						SUM(salesorderdetails.unitprice*salesorderdetails.quantity*(1-salesorderdetails.discountpercent)/currencies.rate) AS ordervalue
					FROM salesorders INNER JOIN salesorderdetails
						ON salesorders.orderno = salesorderdetails.orderno
						INNER JOIN debtorsmaster
						ON salesorders.debtorno = debtorsmaster.debtorno
						INNER JOIN custbranch
						ON debtorsmaster.debtorno = custbranch.debtorno
						AND salesorders.branchcode = custbranch.branchcode
						INNER JOIN currencies
						ON debtorsmaster.currcode = currencies.currabrev
					WHERE salesorderdetails.completed=0
					AND salesorders.quotation =0
					GROUP BY salesorders.orderno,
						debtorsmaster.name,
						custbranch.brname,
						salesorders.customerref,
						salesorders.orddate,
						salesorders.deliverto,
						salesorders.deliverydate,
						salesorders.printedpackingslip
					ORDER BY salesorders.orddate ASC, salesorders.orderno";
	$ErrMsg = _('No orders or quotations were returned by the SQL because');
	$SalesOrdersResult = DB_query($Sql,$ErrMsg);

	/*show a table of the orders returned by the SQL */
	if(DB_num_rows($SalesOrdersResult)>0) {
		$OrdersTotal = 0;
		$FontColor = '';

		while($MyRow=DB_fetch_array($SalesOrdersResult)) {
			$OrderDate = ConvertSQLDate($MyRow['orddate']);
			$FormatedDelDate = ConvertSQLDate($MyRow['deliverydate']);
			$FormatedOrderValue = locale_number_format($MyRow['ordervalue'],$_SESSION['CompanyRecord']['decimalplaces']);
			if(DateDiff(Date($_SESSION['DefaultDateFormat']), $OrderDate, 'd') > 5) {
				$FontColor = ' style="color:green; font-weight:bold"';
			}
			$OrdersTotal += $MyRow['ordervalue'];
		}// END while($MyRow=DB_fetch_array($SalesOrdersResult))

		echo	'
		<tr >
					<th ></th>
					<th ><b>Total<br></b></th>
				</tr><tr class="striped_row">
					<td ><b>', _('Total Order(s) Value in'), ' ', $_SESSION['CompanyRecord']['currencydefault'], ' :</b></td>
					<td ><b>', locale_number_format($OrdersTotal,$_SESSION['CompanyRecord']['decimalplaces']), '</b></td>
				</tr>';
	} //rows > 0

	echo '</tbody></table></td>';
////////////////////////////////////////////////////////////////////////////// TEMRINA EL ORDERDASH


//////////////////////////////////////////////////////////////////////////////SUPPLIERDASH

	echo '<td class="centre">
		<h2> Balance Proveedores </h2>
		<table class="selection">
		<thead>
			<tr>
				<th></th>
				<th>', _('Amount Due'), '<br></th>
			</tr>
		</thead><tbody>';
	$SupplierID = '';
	$TotalPayments = 0;
	$TotalAccumDiffOnExch = 0;
	$AccumBalance = 0;

	$Sql = "SELECT suppliers.supplierid,
					currencies.decimalplaces AS currdecimalplaces,
					SUM(supptrans.ovamount + supptrans.ovgst - supptrans.alloc) AS balance
			FROM suppliers INNER JOIN paymentterms
			ON suppliers.paymentterms = paymentterms.termsindicator
			INNER JOIN supptrans
			ON suppliers.supplierid = supptrans.supplierno
			INNER JOIN systypes
			ON systypes.typeid = supptrans.type
			INNER JOIN currencies
			ON suppliers.currcode=currencies.currabrev
			WHERE supptrans.ovamount + supptrans.ovgst - supptrans.alloc !=0
			AND supptrans.hold=0
			GROUP BY suppliers.supplierid,
					currencies.decimalplaces
			HAVING SUM(supptrans.ovamount + supptrans.ovgst - supptrans.alloc) <> 0
			ORDER BY balance ASC, supptrans.duedate, suppliers.supplierid";
	$SuppliersResult = DB_query($Sql);

	while($SuppliersToPay = DB_fetch_array($SuppliersResult)) {
if(locale_number_format($SuppliersToPay['balance'],2)!=0){
		$CurrDecimalPlaces = $SuppliersToPay['currdecimalplaces'];

		$Sql = "SELECT suppliers.supplierid,
						suppliers.suppname,
						systypes.typename,
						paymentterms.terms,
						supptrans.suppreference,
						supptrans.trandate,
						supptrans.rate,
						supptrans.transno,
						supptrans.type,
						supptrans.duedate,
						(supptrans.ovamount + supptrans.ovgst - supptrans.alloc) AS balance,
						(supptrans.ovamount + supptrans.ovgst ) AS trantotal,
						supptrans.diffonexch,
						supptrans.id
				FROM suppliers
				INNER JOIN paymentterms ON suppliers.paymentterms = paymentterms.termsindicator
				INNER JOIN supptrans ON suppliers.supplierid = supptrans.supplierno
				INNER JOIN systypes ON systypes.typeid = supptrans.type
				WHERE supptrans.supplierno = '" . $SuppliersToPay['supplierid'] . "'
					AND supptrans.ovamount + supptrans.ovgst - supptrans.alloc !=0
					AND supptrans.duedate <='" . Date('Y-m-d', mktime(0,0,0, Date('n'),Date('j')+30,date('Y'))) . "'
					AND supptrans.hold = 0
				ORDER BY supptrans.supplierno,
					supptrans.type,
					supptrans.transno";

		$TransResult = DB_query($Sql,'','',false,false);
		if(DB_error_no() !=0) {
			prnMsg(_('The details of supplier invoices due could not be retrieved because') . ' - ' . DB_error_msg(),'error');
			echo '<br /><a href="' . $RootPath . '/index.php">' . _('Back to the menu') . '</a>';
			if($debug==1) {
				echo '<br />' . _('The SQL that failed was') . ' ' . $Sql;
			}
			include('includes/footer.php');
			exit;
		}

		unset($Allocs);
		$Allocs = array();
		$AllocCounter =0;

		while($DetailTrans = DB_fetch_array($TransResult)) {
			if($DetailTrans['supplierid'] != $SupplierID) { /*Need to head up for a new suppliers details */
				$SupplierID = $DetailTrans['supplierid'];
				$SupplierName = $DetailTrans['suppname'];
				//$AccumBalance = 0;
				$AccumDiffOnExch = 0;
				}

			$DisplayFormat = '';
			if((time()-(60*60*24)) > strtotime($DetailTrans['duedate'])) {
				$DisplayFormat = ' style="color:red;"';
			}
			$DislayTranDate = ConvertSQLDate($DetailTrans['trandate']);
			$AccumBalance += $DetailTrans['balance'];
		if(locale_number_format($DetailTrans['balance'], 2)!=0){	
			if($DetailTrans['type'] == 20) {// If Purchase Invoice:

			} else {// If NOT Purchase Invoice (Creditors Payment):

			}
			}
		} /*end while there are detail transactions to show */
		}
	} /* end while there are suppliers to retrieve transactions for */

	echo '<tr class="striped_row">
			<td class="number">', _('Grand Total Payments Due'), '</td>
			<td class="number"><b>', locale_number_format($AccumBalance, $CurrDecimalPlaces), '</b></td>
		</tr>
		</tbody>
		</table></span></td></tr></table>';
//////////////////////////////////////////////////////////////////////////////TERMINA EL SUPPLIERDASH

//////////////////////////////////////////////////////////////////////////////BANKDASH
	echo '<div ><p class="page_title_text" style="font-size:large"><img alt="" src="', $RootPath, '/css/', $Theme,
	'/images/bank.png" title="', // Icon image.
	_('Bank Account Balances'), '" />Balances de Cuentas Bancarias </p>',// Page title.
	'<table>
		<tr>
			<th>', _('Bank Account'), '</th>
			<th>', _('Account Name'), '</th>
			<th>', _('Saldo en SPACPI'), '</th>
			<th>', _('Saldo en bancos'), '</th>
			<th>', _('Diferencia'), '</th>
			<th>', _('Ingresos por asignar'), '</th>
			<th>', _('Pagos por conciliar'), '</th>
			<th>Faltante neto</th>';
	echo	'</tr>';

$SQL = "SELECT DISTINCT bankaccounts.accountcode,
						currcode,
						bankaccountname
			FROM bankaccounts
			INNER JOIN bankaccountusers
			ON bankaccounts.accountcode=bankaccountusers.accountcode
			AND userid='" . $_SESSION['UserID'] . "' ORDER BY bankaccountname ASC";
$Result = DB_query($SQL);

if (DB_num_rows($Result) == 0) {
	echo _('There are no bank accounts defined that you have authority to see');
} else {
	while ($MyBankRow = DB_fetch_array($Result)) {
	$sqlmean="SELECT * FROM bankedo where bankaccount='".$MyBankRow['accountcode']."'";
	$resultmean=DB_query($sqlmean);
	if(DB_num_rows($resultmean) != 0) {
		$CurrBalanceSQL = "SELECT (SELECT SUM(abono-cargo) FROM bankedo where bankaccount='".$MyBankRow['accountcode']."' and banktransidrel!='' and banktransidrel!='0' and fecha='".date('Y-m-d')."' ), SUM(banktrans.amount) AS balance FROM banktrans WHERE bankact='" . $MyBankRow['accountcode'] . "' AND transdate<'".date('Y-m-d')."'";
		}
		else {
		$CurrBalanceSQL = "SELECT (SELECT SUM(abono-cargo) FROM bankedo where bankaccount='".$MyBankRow['accountcode']."' and banktransidrel!='' and banktransidrel!='0' and fecha='".date('Y-m-d')."' ), SUM(banktrans.amount) AS balance FROM banktrans WHERE bankact='" . $MyBankRow['accountcode'] . "' AND transdate<='".date('Y-m-d')."'";
		}	
		$CurrBalanceResult = DB_query($CurrBalanceSQL);
		$CurrBalanceRow = DB_fetch_array($CurrBalanceResult);
		


		if($MyBankRow['accountcode']=='102101-1'){
		$SQL = "SELECT saldo FROM bankedo WHERE bankaccount='" . $MyBankRow['accountcode'] . "' ORDER BY fecha DESC, idregistro ASC ";
		$Realresult = DB_query($SQL);
		$Realbalancerow = DB_fetch_array($Realresult);
		}
		else{
		$SQL = "SELECT saldo FROM bankedo WHERE bankaccount='" . $MyBankRow['accountcode'] . "' ORDER BY fecha DESC,idregistro DESC ";
		$Realresult = DB_query($SQL);
		$Realbalancerow = DB_fetch_array($Realresult);
		}
/*
		$FuncBalanceSQL = "SELECT SUM(amount) AS balance FROM gltrans WHERE account='" . $MyBankRow['accountcode'] . "'";
		$FuncBalanceResult = DB_query($FuncBalanceSQL);
		$FuncBalanceRow = DB_fetch_array($FuncBalanceResult);*/

		$DecimalPlacesSQL = "SELECT decimalplaces FROM currencies WHERE currabrev='" . $MyBankRow['currcode'] . "'";
		$DecimalPlacesResult = DB_query($DecimalPlacesSQL);
		$DecimalPlacesRow = DB_fetch_array($DecimalPlacesResult);
$CurrBalanceRow['balance']=$CurrBalanceRow['balance']+$CurrBalanceRow[0];
		echo '<tr class="striped_row">
				<td>', $MyBankRow['accountcode'], '</td>
				<td>', $MyBankRow['bankaccountname'], '</td>
				<td class="number">', locale_number_format($CurrBalanceRow['balance'], $DecimalPlacesRow['decimalplaces']), ' ', $MyBankRow['currcode'], '</td>';
				if($Realbalancerow[0]!=''){
			echo 	'<td class="number">', locale_number_format($Realbalancerow[0], $DecimalPlacesRow['decimalplaces']), ' ', $MyBankRow['currcode'], '</td>';
				}
		$dif=locale_number_format(($CurrBalanceRow['balance']-$Realbalancerow[0]),2);
		if($Realbalancerow[0]!=''){
		$SQL = "SELECT SUM(abono) as abonos, SUM(cargo) as cargos FROM bankedo WHERE bankaccount='" . $MyBankRow['accountcode'] . "' AND (banktransidrel='' or banktransidrel='0')  ";
		$Resultme = DB_query($SQL);
		$Realmerow = DB_fetch_array($Resultme);
		$green='lightcoral';	
		if(locale_number_format(($CurrBalanceRow['balance']-$Realbalancerow[0]+$Realmerow['abonos']-$Realmerow['cargos']),2)==0){
$green='limegreen';		
		}
			echo	'<td class="number" style="color:blue">', $dif, ' ', $MyBankRow['currcode'], '</td>
			<td class="number" style="color:green">', locale_number_format($Realmerow['abonos'],2), ' ', $MyBankRow['currcode'], '</td>
			<td class="number" style="color:red">', locale_number_format($Realmerow['cargos'],2), ' ', $MyBankRow['currcode'], '</td>
			<td class="number" style="color:black;font-weight:bold;background-color:'.$green.'">', locale_number_format(($CurrBalanceRow['balance']-$Realbalancerow[0]+$Realmerow['abonos']-$Realmerow['cargos']),2), ' ', $MyBankRow['currcode'], '</td>';}
			// echo	'<td class="number">', locale_number_format($FuncBalanceRow['balance'], $_SESSION['CompanyRecord']['decimalplaces']), ' ', $_SESSION['CompanyRecord']['currencydefault'], '</td>
		echo	'</tr>';
	}

	echo '</table></div>';
}

//////////////////////////////////////////////////////////////////////////////TERMINA EL BANKDASH


include('includes/footer.php');
?>